#include "ath9k_wifi.h"

#include <stdio.h>
#include <string.h>

#include "pico/stdlib.h"
#include "storage.h"
#include "tusb.h"
#include "usb_host.h"

#define ATH9K_VID 0x0CF3U
#define ATH9K_FW_PATH "/sd/firmware/ath9k.fw"
#define ATH9K_FW_CHUNK 4096U
#define ATH9K_FW_BASE 0x501000U
#define ATH9K_FW_TEXT 0x903000U
#define ATH9K_MAX_FW (512U * 1024U)

#define HTC_MSG_READY_ID 1
#define HTC_MSG_CONNECT_SERVICE_ID 2
#define HTC_MSG_CONNECT_SERVICE_RESPONSE_ID 3
#define HTC_MSG_SETUP_COMPLETE_ID 4
#define HTC_MSG_CONFIG_PIPE_ID 5

#define HTC_SERVICE_SUCCESS 0
#define WMI_CONTROL_SVC 0x0100U

#define WMI_ECHO_CMDID 0x0001
#define WMI_GET_FW_VERSION 0x0003
#define WMI_ENABLE_INTR_CMDID 0x0005
#define WMI_ATH_INIT_CMDID 0x0006
#define WMI_START_RECV_CMDID 0x000C
#define WMI_SET_MODE_CMDID 0x000F
#define WMI_NODE_CREATE_CMDID 0x0010
#define WMI_VAP_CREATE_CMDID 0x0013
#define WMI_REG_READ_CMDID 0x0014
#define WMI_REG_WRITE_CMDID 0x0015

#define WMI_MGMT_SVC 0x0104U
#define WMI_DATA_BE_SVC 0x0107U

#define HTC_FLAGS_RECV_TRAILER 0x02U
#define ATH_USB_RX_STREAM_MODE_TAG 0x4E00U
#define HTC_RX_STATUS_LEN 40U
#define ATH9K_RX_BUF_SIZE 2048U
#define ATH9K_TX_TIMEOUT_MS 250U

#define AR5416_EEPROM_OFFSET 0x2000U
#define AR5416_EEPROM_S 2U
#define AR_EEPROM_STATUS_DATA 0x407CU
#define AR_EEPROM_STATUS_DATA_BUSY 0x00010000U
#define AR_EEPROM_STATUS_DATA_PROT 0x00040000U
#define AR_EEPROM_MAC_WORD 6U

#define HTC_HDR_LEN 8U
#define WMI_HDR_LEN 4U
#define HTC_MSG_MAX 512U

typedef struct {
    bool present;
    bool mounted;
    uint8_t addr;
    uint16_t vid;
    uint16_t pid;

    bool fw_uploaded;
    bool endpoints_open;
    bool booted;
    bool ready;
    bool rx_started;
    uint32_t fw_size;
    uint16_t fw_major;
    uint16_t fw_minor;

    uint8_t ep_tx;
    uint8_t ep_rx;
    uint8_t ep_reg_in;
    uint8_t ep_reg_out;

    uint8_t wmi_epid;
    uint8_t mgmt_epid;
    uint8_t data_epid;
    uint16_t wmi_seq;
    uint16_t htc_credits;
    uint16_t htc_credit_size;

    bool reg_in_pending;
    volatile bool reg_in_done;
    volatile xfer_result_t reg_in_result;
    volatile uint32_t reg_in_actual;
    uint8_t reg_in_buf[HTC_MSG_MAX] __attribute__((aligned(4)));

    bool rx_ready;
    uint8_t rx_msg[HTC_MSG_MAX] __attribute__((aligned(4)));
    uint16_t rx_len;

    bool mac_valid;
    uint8_t mac[6];

    bool associated;
    bool connected;
    bool secure;
    bool wpa_done;
    uint8_t bssid[6];
    char ssid[ATH9K_WIFI_SSID_MAX + 1];
    int8_t rssi;
    uint8_t channel;

    void (*rx_cb)(const uint8_t *frame, uint16_t len);
    uint32_t rx_frames;
    uint8_t eth_frame[1514] __attribute__((aligned(4)));

    bool rx_bulk_pending;
    volatile bool rx_bulk_done;
    volatile xfer_result_t rx_bulk_result;
    volatile uint32_t rx_bulk_actual;
    uint8_t rx_bulk_buf[ATH9K_RX_BUF_SIZE] __attribute__((aligned(4)));

    bool reg_out_pending;
    volatile bool reg_out_done;
    volatile xfer_result_t reg_out_result;
    uint8_t tx_frame[HTC_MSG_MAX + 8] __attribute__((aligned(4)));

    bool bulk_tx_pending;
    volatile bool bulk_tx_done;
    volatile xfer_result_t bulk_tx_result;
    uint8_t tx_packet[HTC_MSG_MAX + 12] __attribute__((aligned(4)));

    char status[80];
} AthState;

static AthState w;

static uint32_t be32_get(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

static void be16_put(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)v;
}

static void be32_put(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}

static void wifi_set_status(const char *text) {
    snprintf(w.status, sizeof(w.status), "%.79s", text);
}

static void wifi_reset_state(void) {
    uint8_t addr = w.addr;
    bool mounted = w.mounted;
    uint16_t vid = w.vid;
    uint16_t pid = w.pid;
    bool endpoints_open = w.endpoints_open;
    uint8_t ep_tx = w.ep_tx;
    uint8_t ep_rx = w.ep_rx;
    uint8_t ep_reg_in = w.ep_reg_in;
    uint8_t ep_reg_out = w.ep_reg_out;
    void (*rx_cb)(const uint8_t *frame, uint16_t len) = w.rx_cb;
    memset(&w, 0, sizeof(w));
    w.addr = addr;
    w.mounted = mounted;
    w.vid = vid;
    w.pid = pid;
    w.rx_cb = rx_cb;
    w.endpoints_open = endpoints_open;
    w.ep_tx = ep_tx;
    w.ep_rx = ep_rx;
    w.ep_reg_in = ep_reg_in;
    w.ep_reg_out = ep_reg_out;
}

void ath9k_wifi_init(void) {
    memset(&w, 0, sizeof(w));
    wifi_set_status("nenhum adaptador Atheros");
}

void ath9k_wifi_mounted(uint8_t addr, uint16_t vid, uint16_t pid) {
    if (vid != ATH9K_VID) {
        return;
    }
    if (w.mounted && w.addr != addr) {
        ath9k_wifi_unmounted(w.addr);
    }
    wifi_reset_state();
    w.present = true;
    w.mounted = true;
    w.addr = addr;
    w.vid = vid;
    w.pid = pid;
    snprintf(w.status, sizeof(w.status), "AR9271 %04X:%04X pronto para firmware", vid, pid);
}

void ath9k_wifi_unmounted(uint8_t addr) {
    if (w.mounted && w.addr == addr) {
        void (*rx_cb)(const uint8_t *frame, uint16_t len) = w.rx_cb;
        memset(&w, 0, sizeof(w));
        w.rx_cb = rx_cb;
        w.present = false;
        wifi_set_status("adaptador removido");
    }
}

bool ath9k_wifi_present(void) {
    return w.present && w.mounted && w.addr != 0;
}

static bool ath9k_wifi_driver_init(void) {
    return true;
}

static bool ath9k_wifi_driver_deinit(void) {
    return true;
}

static bool ath9k_wifi_driver_open(uint8_t rhport, uint8_t dev_addr,
                                   tusb_desc_interface_t const *itf_desc,
                                   uint16_t max_len) {
    (void)rhport;
    uint16_t vid = 0, pid = 0;
    if (!tuh_vid_pid_get(dev_addr, &vid, &pid)) {
        return false;
    }
    if (vid != ATH9K_VID) {
        return false;
    }
    if (itf_desc->bInterfaceClass != TUSB_CLASS_VENDOR_SPECIFIC) {
        return false;
    }

    uint8_t const *p = (uint8_t const *)itf_desc;
    uint8_t const *end = p + max_len;

    uint8_t ep_tx = 0;
    uint8_t ep_rx = 0;
    uint8_t ep_reg_in = 0;
    uint8_t ep_reg_out = 0;

    tusb_desc_endpoint_t ep_desc_tx;
    tusb_desc_endpoint_t ep_desc_rx;
    tusb_desc_endpoint_t ep_desc_reg_in;
    tusb_desc_endpoint_t ep_desc_reg_out;

    memset(&ep_desc_tx, 0, sizeof(ep_desc_tx));
    memset(&ep_desc_rx, 0, sizeof(ep_desc_rx));
    memset(&ep_desc_reg_in, 0, sizeof(ep_desc_reg_in));
    memset(&ep_desc_reg_out, 0, sizeof(ep_desc_reg_out));

    while (p + 2 <= end) {
        uint8_t blen = p[0];
        uint8_t btype = p[1];
        if (blen < 2 || p + blen > end) {
            break;
        }

        if (btype == TUSB_DESC_ENDPOINT && blen >= sizeof(tusb_desc_endpoint_t)) {
            const tusb_desc_endpoint_t *ep = (const tusb_desc_endpoint_t *)p;
            uint8_t addr = ep->bEndpointAddress;
            uint8_t num = (uint8_t)(addr & 0x0FU);
            bool in = (addr & TUSB_DIR_IN_MASK) != 0;

            if (num == 1 && !in) {
                ep_tx = addr;
                ep_desc_tx = *ep;
            } else if (num == 2 && in) {
                ep_rx = addr;
                ep_desc_rx = *ep;
            } else if (num == 3 && in) {
                ep_reg_in = addr;
                ep_desc_reg_in = *ep;
            } else if (num == 4 && !in) {
                ep_reg_out = addr;
                ep_desc_reg_out = *ep;
            } else if (ep->bmAttributes.xfer == TUSB_XFER_BULK) {
                if (in && ep_rx == 0) {
                    ep_rx = addr;
                    ep_desc_rx = *ep;
                } else if (!in && ep_tx == 0) {
                    ep_tx = addr;
                    ep_desc_tx = *ep;
                }
            } else if (ep->bmAttributes.xfer == TUSB_XFER_INTERRUPT) {
                if (in && ep_reg_in == 0) {
                    ep_reg_in = addr;
                    ep_desc_reg_in = *ep;
                } else if (!in && ep_reg_out == 0) {
                    ep_reg_out = addr;
                    ep_desc_reg_out = *ep;
                }
            }
        }
        p += blen;
    }

    if (ep_tx == 0) ep_tx = 0x01;
    if (ep_rx == 0) ep_rx = 0x82;
    if (ep_reg_in == 0) ep_reg_in = 0x83;
    if (ep_reg_out == 0) ep_reg_out = 0x04;

    tusb_speed_t speed = tuh_speed_get(dev_addr);

    tusb_desc_endpoint_t *eps[4] = { &ep_desc_tx, &ep_desc_rx, &ep_desc_reg_in, &ep_desc_reg_out };
    uint8_t ep_addrs[4] = { ep_tx, ep_rx, ep_reg_in, ep_reg_out };
    uint8_t ep_types[4] = { TUSB_XFER_BULK, TUSB_XFER_BULK, TUSB_XFER_INTERRUPT, TUSB_XFER_INTERRUPT };

    for (int i = 0; i < 4; i++) {
        if (eps[i]->bLength < sizeof(tusb_desc_endpoint_t)) {
            eps[i]->bLength = sizeof(tusb_desc_endpoint_t);
            eps[i]->bDescriptorType = TUSB_DESC_ENDPOINT;
            eps[i]->bEndpointAddress = ep_addrs[i];
            eps[i]->bmAttributes.xfer = ep_types[i];
            eps[i]->wMaxPacketSize = (speed == TUSB_SPEED_HIGH && i < 2) ? 512 : 64;
            eps[i]->bInterval = (i >= 2) ? 1 : 0;
        } else if (speed == TUSB_SPEED_FULL && tu_edpt_packet_size(eps[i]) > 64) {
            eps[i]->wMaxPacketSize = 64;
        }
        if (!tuh_edpt_open(dev_addr, eps[i])) {
            return false;
        }
    }

    w.addr = dev_addr;
    w.vid = vid;
    w.pid = pid;
    w.ep_tx = ep_tx;
    w.ep_rx = ep_rx;
    w.ep_reg_in = ep_reg_in;
    w.ep_reg_out = ep_reg_out;
    w.endpoints_open = true;

    return true;
}

static bool ath9k_wifi_driver_set_config(uint8_t dev_addr, uint8_t itf_num) {
    usbh_driver_set_config_complete(dev_addr, itf_num);
    return true;
}

static bool ath9k_wifi_driver_xfer_cb(uint8_t dev_addr, uint8_t ep_addr, xfer_result_t result, uint32_t xferred_bytes) {
    (void)dev_addr;
    (void)ep_addr;
    (void)result;
    (void)xferred_bytes;
    return true;
}

static void ath9k_wifi_driver_close(uint8_t dev_addr) {
    if (w.addr == dev_addr) {
        w.endpoints_open = false;
    }
}

static const usbh_class_driver_t ath9k_wifi_driver = {
    .name = "ATH9K",
    .init = ath9k_wifi_driver_init,
    .deinit = ath9k_wifi_driver_deinit,
    .open = ath9k_wifi_driver_open,
    .set_config = ath9k_wifi_driver_set_config,
    .xfer_cb = ath9k_wifi_driver_xfer_cb,
    .close = ath9k_wifi_driver_close,
};

usbh_class_driver_t const *ath9k_wifi_get_driver(void) {
    return &ath9k_wifi_driver;
}

static bool wifi_find_endpoints(void) {
    if (w.ep_tx != 0 && w.ep_rx != 0 && w.ep_reg_in != 0 && w.ep_reg_out != 0) {
        return true;
    }

    static uint8_t config[512];
    uint8_t result = tuh_descriptor_get_configuration_sync(w.addr, 0, config, sizeof(config));
    if (result == XFER_RESULT_SUCCESS) {
        uint16_t total = (uint16_t)(config[2] | (config[3] << 8));
        if (total < 9 || total > sizeof(config)) {
            total = sizeof(config);
        }

        uint16_t pos = 0;
        while (pos + 2 <= total) {
            uint8_t blen = config[pos];
            uint8_t btype = config[pos + 1];
            if (blen < 2 || pos + blen > total) {
                break;
            }
            if (btype == TUSB_DESC_ENDPOINT && blen >= sizeof(tusb_desc_endpoint_t)) {
                const tusb_desc_endpoint_t *ep = (const tusb_desc_endpoint_t *)(config + pos);
                uint8_t addr = ep->bEndpointAddress;
                uint8_t num = (uint8_t)(addr & 0x0FU);
                bool in = (addr & TUSB_DIR_IN_MASK) != 0;

                if (num == 1 && !in) {
                    w.ep_tx = addr;
                } else if (num == 2 && in) {
                    w.ep_rx = addr;
                } else if (num == 3 && in) {
                    w.ep_reg_in = addr;
                } else if (num == 4 && !in) {
                    w.ep_reg_out = addr;
                } else if (ep->bmAttributes.xfer == TUSB_XFER_BULK) {
                    if (in && w.ep_rx == 0) {
                        w.ep_rx = addr;
                    } else if (!in && w.ep_tx == 0) {
                        w.ep_tx = addr;
                    }
                } else if (ep->bmAttributes.xfer == TUSB_XFER_INTERRUPT) {
                    if (in && w.ep_reg_in == 0) {
                        w.ep_reg_in = addr;
                    } else if (!in && w.ep_reg_out == 0) {
                        w.ep_reg_out = addr;
                    }
                }
            }
            pos = (uint16_t)(pos + blen);
        }
    }

    if (w.ep_tx == 0) w.ep_tx = 0x01;
    if (w.ep_rx == 0) w.ep_rx = 0x82;
    if (w.ep_reg_in == 0) w.ep_reg_in = 0x83;
    if (w.ep_reg_out == 0) w.ep_reg_out = 0x04;

    return true;
}

static bool wifi_open_endpoints(void) {
    if (w.endpoints_open && w.ep_reg_in != 0 && w.ep_reg_out != 0 && w.ep_tx != 0 && w.ep_rx != 0) {
        return true;
    }
    if (!wifi_find_endpoints()) {
        return false;
    }

    tusb_speed_t speed = tuh_speed_get(w.addr);
    static uint8_t config[512];
    uint8_t result = tuh_descriptor_get_configuration_sync(w.addr, 0, config, sizeof(config));
    if (result == XFER_RESULT_SUCCESS) {
        uint16_t total = (uint16_t)(config[2] | (config[3] << 8));
        if (total < 9 || total > sizeof(config)) {
            total = sizeof(config);
        }

        uint16_t pos = 0;
        while (pos + 2 <= total) {
            uint8_t blen = config[pos];
            uint8_t btype = config[pos + 1];
            if (blen < 2 || pos + blen > total) {
                break;
            }
            if (btype == TUSB_DESC_ENDPOINT && blen >= sizeof(tusb_desc_endpoint_t)) {
                tusb_desc_endpoint_t ep = *(const tusb_desc_endpoint_t *)(config + pos);
                uint8_t addr = ep.bEndpointAddress;
                if (addr == w.ep_tx || addr == w.ep_rx || addr == w.ep_reg_in || addr == w.ep_reg_out) {
                    if (speed == TUSB_SPEED_FULL && tu_edpt_packet_size(&ep) > 64) {
                        ep.wMaxPacketSize = 64;
                    }
                    tuh_edpt_open(w.addr, &ep);
                }
            }
            pos = (uint16_t)(pos + blen);
        }
    }

    uint8_t addrs[4] = { w.ep_tx, w.ep_rx, w.ep_reg_in, w.ep_reg_out };
    uint8_t types[4] = { TUSB_XFER_BULK, TUSB_XFER_BULK, TUSB_XFER_INTERRUPT, TUSB_XFER_INTERRUPT };
    for (int i = 0; i < 4; i++) {
        tusb_desc_endpoint_t ep = {
            .bLength = sizeof(tusb_desc_endpoint_t),
            .bDescriptorType = TUSB_DESC_ENDPOINT,
            .bEndpointAddress = addrs[i],
            .bmAttributes = { .xfer = types[i] },
            .wMaxPacketSize = (speed == TUSB_SPEED_HIGH && i < 2) ? 512 : 64,
            .bInterval = (i >= 2) ? 1 : 0,
        };
        if (!tuh_edpt_open(w.addr, &ep)) {
            return false;
        }
    }

    w.endpoints_open = true;
    return true;
}

static void wifi_reg_in_cb(tuh_xfer_t *xfer) {
    w.reg_in_actual = xfer->actual_len;
    w.reg_in_result = xfer->result;
    w.reg_in_done = true;
    w.reg_in_pending = false;
}

static bool wifi_submit_reg_in(void) {
    if (!w.endpoints_open || w.reg_in_pending || w.rx_ready) {
        return false;
    }
    tuh_xfer_t xfer = {
        .daddr = w.addr,
        .ep_addr = w.ep_reg_in,
        .buffer = w.reg_in_buf,
        .buflen = sizeof(w.reg_in_buf),
        .complete_cb = wifi_reg_in_cb,
    };
    if (!tuh_edpt_xfer(&xfer)) {
        return false;
    }
    w.reg_in_pending = true;
    return true;
}

static void wifi_reg_out_cb(tuh_xfer_t *xfer) {
    w.reg_out_result = xfer->result;
    w.reg_out_done = true;
    w.reg_out_pending = false;
}

static void wifi_bulk_tx_cb(tuh_xfer_t *xfer) {
    w.bulk_tx_result = xfer->result;
    w.bulk_tx_done = true;
    w.bulk_tx_pending = false;
}

static void wifi_bulk_rx_cb(tuh_xfer_t *xfer) {
    w.rx_bulk_result = xfer->result;
    w.rx_bulk_actual = xfer->actual_len;
    w.rx_bulk_done = true;
    w.rx_bulk_pending = false;
}

static bool wifi_wait_transfer(volatile bool *done, uint32_t timeout_ms) {
    uint32_t start = (uint32_t)(time_us_64() / 1000ULL);
    while (!*done) {
        usb_task();
        ath9k_wifi_task();
        if ((uint32_t)(time_us_64() / 1000ULL) - start >= timeout_ms) {
            return false;
        }
        sleep_ms(1);
    }
    return true;
}

static bool wifi_reg_out_send(const uint8_t *data, uint16_t len) {
    if (!w.endpoints_open || w.ep_reg_out == 0 || len == 0 || len > sizeof(w.tx_frame)) {
        return false;
    }
    if (w.reg_out_pending && !wifi_wait_transfer(&w.reg_out_done, ATH9K_TX_TIMEOUT_MS)) {
        return false;
    }
    memcpy(w.tx_frame, data, len);
    w.reg_out_done = false;
    w.reg_out_result = XFER_RESULT_INVALID;
    tuh_xfer_t xfer = {
        .daddr = w.addr,
        .ep_addr = w.ep_reg_out,
        .buffer = w.tx_frame,
        .buflen = len,
        .complete_cb = wifi_reg_out_cb,
    };
    if (!tuh_edpt_xfer(&xfer)) {
        return false;
    }
    w.reg_out_pending = true;
    if (!wifi_wait_transfer(&w.reg_out_done, ATH9K_TX_TIMEOUT_MS)) {
        return false;
    }
    return w.reg_out_result == XFER_RESULT_SUCCESS;
}

static bool wifi_submit_bulk_rx(void) {
    if (!w.endpoints_open || w.ep_rx == 0 || w.rx_bulk_pending) {
        return false;
    }
    w.rx_bulk_done = false;
    w.rx_bulk_result = XFER_RESULT_INVALID;
    tuh_xfer_t xfer = {
        .daddr = w.addr,
        .ep_addr = w.ep_rx,
        .buffer = w.rx_bulk_buf,
        .buflen = sizeof(w.rx_bulk_buf),
        .complete_cb = wifi_bulk_rx_cb,
    };
    if (!tuh_edpt_xfer(&xfer)) {
        return false;
    }
    w.rx_bulk_pending = true;
    return true;
}

static bool wifi_wait_rx(uint32_t timeout_ms) {
    uint32_t start = (uint32_t)(time_us_64() / 1000ULL);
    while (!w.rx_ready) {
        usb_task();
        ath9k_wifi_task();
        if ((uint32_t)(time_us_64() / 1000ULL) - start >= timeout_ms) {
            return false;
        }
        sleep_ms(1);
    }
    return true;
}

static void wifi_drop_rx(void) {
    w.rx_ready = false;
}

static bool wifi_htc_send(uint8_t endpoint, const uint8_t *payload, uint16_t len, bool use_regout) {
    uint8_t frame[HTC_MSG_MAX];
    if (len + HTC_HDR_LEN > sizeof(frame)) {
        return false;
    }
    frame[0] = endpoint;
    frame[1] = 0;
    be16_put(&frame[2], len);
    memset(&frame[4], 0, 4);
    if (len > 0 && payload != NULL) {
        memcpy(&frame[HTC_HDR_LEN], payload, len);
    }
    if (use_regout) {
        return wifi_reg_out_send(frame, (uint16_t)(len + HTC_HDR_LEN));
    }
    if (!w.endpoints_open || w.ep_tx == 0) {
        return false;
    }
    uint16_t total = (uint16_t)(len + HTC_HDR_LEN);
    if ((uint32_t)total + 4U > sizeof(w.tx_packet)) {
        return false;
    }
    if (w.bulk_tx_pending && !wifi_wait_transfer(&w.bulk_tx_done, ATH9K_TX_TIMEOUT_MS)) {
        return false;
    }
    be16_put(&w.tx_packet[0], total);
    be16_put(&w.tx_packet[2], 0x697E);
    memcpy(&w.tx_packet[4], frame, total);
    w.bulk_tx_done = false;
    w.bulk_tx_result = XFER_RESULT_INVALID;
    tuh_xfer_t xfer = {
        .daddr = w.addr,
        .ep_addr = w.ep_tx,
        .buffer = w.tx_packet,
        .buflen = (uint32_t)(total + 4),
        .complete_cb = wifi_bulk_tx_cb,
    };
    if (!tuh_edpt_xfer(&xfer)) {
        return false;
    }
    w.bulk_tx_pending = true;
    if (!wifi_wait_transfer(&w.bulk_tx_done, ATH9K_TX_TIMEOUT_MS)) {
        return false;
    }
    return w.bulk_tx_result == XFER_RESULT_SUCCESS;
}

static bool wifi_htc_control(const uint8_t *payload, uint16_t len) {
    return wifi_htc_send(0, payload, len, true);
}

static bool wifi_wait_htc_message(uint16_t msg_id, uint32_t timeout_ms) {
    uint32_t start = (uint32_t)(time_us_64() / 1000ULL);
    for (;;) {
        if (!w.rx_ready && !w.reg_in_pending) {
            wifi_submit_reg_in();
        }
        if (!wifi_wait_rx(timeout_ms)) {
            return false;
        }
        if (w.rx_len >= HTC_HDR_LEN) {
            uint16_t payload_len = (uint16_t)((w.rx_msg[2] << 8) | w.rx_msg[3]);
            if (payload_len >= 2 && HTC_HDR_LEN + payload_len <= w.rx_len) {
                uint16_t id = (uint16_t)((w.rx_msg[HTC_HDR_LEN] << 8) | w.rx_msg[HTC_HDR_LEN + 1]);
                if (id == msg_id) {
                    return true;
                }
            }
        }
        wifi_drop_rx();
        if ((uint32_t)(time_us_64() / 1000ULL) - start >= timeout_ms) {
            return false;
        }
        wifi_submit_reg_in();
    }
}

static bool wifi_wmi_command(uint16_t cmd, const uint8_t *body, uint16_t body_len,
                             uint8_t *resp, uint16_t resp_size, uint16_t *resp_len,
                             uint32_t timeout_ms) {
    if (!w.ready || w.wmi_epid == 0) {
        return false;
    }
    if (body_len + WMI_HDR_LEN > HTC_MSG_MAX) {
        return false;
    }

    uint8_t payload[HTC_MSG_MAX];
    uint16_t seq = ++w.wmi_seq;
    be16_put(&payload[0], cmd);
    be16_put(&payload[2], seq);
    if (body_len > 0 && body != NULL) {
        memcpy(&payload[WMI_HDR_LEN], body, body_len);
    }

    if (!wifi_htc_send(w.wmi_epid, payload, (uint16_t)(WMI_HDR_LEN + body_len), true)) {
        return false;
    }

    uint32_t start = (uint32_t)(time_us_64() / 1000ULL);
    for (;;) {
        if (!wifi_wait_rx(timeout_ms)) {
            return false;
        }
        uint16_t hlen = (uint16_t)((w.rx_msg[2] << 8) | w.rx_msg[3]);
        if (w.rx_len >= HTC_HDR_LEN + WMI_HDR_LEN &&
            w.rx_msg[0] == w.wmi_epid &&
            hlen >= WMI_HDR_LEN &&
            HTC_HDR_LEN + hlen <= w.rx_len) {
            uint8_t *wp = &w.rx_msg[HTC_HDR_LEN];
            uint16_t rid = (uint16_t)((wp[0] << 8) | wp[1]);
            uint16_t rseq = (uint16_t)((wp[2] << 8) | wp[3]);
            if (rid == cmd && rseq == seq) {
                uint16_t rlen = (uint16_t)(hlen - WMI_HDR_LEN);
                if (rlen > resp_size) {
                    rlen = resp_size;
                }
                if (rlen > 0 && resp != NULL) {
                    memcpy(resp, &wp[WMI_HDR_LEN], rlen);
                }
                if (resp_len != NULL) {
                    *resp_len = rlen;
                }
                wifi_drop_rx();
                wifi_submit_reg_in();
                return true;
            }
        }
        wifi_drop_rx();
        if ((uint32_t)(time_us_64() / 1000ULL) - start >= timeout_ms) {
            return false;
        }
        wifi_submit_reg_in();
    }
}

static bool wifi_reg_read(uint32_t reg, uint32_t *value) {
    uint8_t body[4];
    uint8_t resp[4];
    uint16_t len = 0;
    be32_put(body, reg);
    if (!wifi_wmi_command(WMI_REG_READ_CMDID, body, sizeof(body), resp, sizeof(resp), &len, 200) ||
        len < sizeof(resp)) {
        return false;
    }
    *value = be32_get(resp);
    return true;
}

static bool wifi_read_eeprom_word(uint32_t off, uint16_t *value) {
    uint32_t dummy = 0;
    if (!wifi_reg_read(AR5416_EEPROM_OFFSET + (off << AR5416_EEPROM_S), &dummy)) {
        return false;
    }
    for (int i = 0; i < 20; ++i) {
        uint32_t status = 0;
        if (!wifi_reg_read(AR_EEPROM_STATUS_DATA, &status)) {
            return false;
        }
        if ((status & (AR_EEPROM_STATUS_DATA_BUSY | AR_EEPROM_STATUS_DATA_PROT)) == 0) {
            *value = (uint16_t)(status & 0xFFFFU);
            return true;
        }
        sleep_ms(1);
    }
    return false;
}

static bool wifi_read_mac(void) {
    uint16_t words[3];
    for (uint8_t i = 0; i < 3; ++i) {
        if (!wifi_read_eeprom_word(AR_EEPROM_MAC_WORD + i, &words[i])) {
            return false;
        }
    }
    uint8_t mac[6];
    mac[0] = (uint8_t)(words[0] & 0xFF);
    mac[1] = (uint8_t)(words[0] >> 8);
    mac[2] = (uint8_t)(words[1] & 0xFF);
    mac[3] = (uint8_t)(words[1] >> 8);
    mac[4] = (uint8_t)(words[2] & 0xFF);
    mac[5] = (uint8_t)(words[2] >> 8);

    bool all_zero = true;
    bool all_ff = true;
    for (int i = 0; i < 6; ++i) {
        if (mac[i] != 0x00) all_zero = false;
        if (mac[i] != 0xFF) all_ff = false;
    }
    if (all_zero || all_ff || (mac[0] & 0x01)) {
        return false;
    }
    memcpy(w.mac, mac, 6);
    w.mac_valid = true;
    return true;
}

static bool wifi_upload_firmware(char *out, size_t out_size) {
    if (!storage_mounted(VFS_SD)) {
        snprintf(out, out_size, "cartao SD ausente (esperado %s)", ATH9K_FW_PATH);
        return false;
    }
    VfsEntry entry;
    if (!vfs_stat(ATH9K_FW_PATH, &entry) || entry.is_dir || entry.size == 0) {
        snprintf(out, out_size, "arquivo %s nao encontrado", ATH9K_FW_PATH);
        return false;
    }
    if (entry.size > ATH9K_MAX_FW) {
        snprintf(out, out_size, "firmware grande demais (%lu bytes)", (unsigned long)entry.size);
        return false;
    }

    static uint8_t chunk[ATH9K_FW_CHUNK] __attribute__((aligned(4)));
    uint32_t offset = 0;
    uint32_t addr = ATH9K_FW_BASE;
    while (offset < entry.size) {
        size_t want = entry.size - offset;
        if (want > sizeof(chunk)) {
            want = sizeof(chunk);
        }
        size_t got = 0;
        if (!vfs_read_file_at(ATH9K_FW_PATH, offset, (char *)chunk, want, &got) || got == 0) {
            snprintf(out, out_size, "falha lendo firmware no offset %lu", (unsigned long)offset);
            return false;
        }

        tusb_control_request_t req = {
            .bmRequestType = 0x40,
            .bRequest = 0x30,
            .wValue = (uint16_t)(addr >> 8),
            .wIndex = 0,
            .wLength = (uint16_t)got,
        };
        tuh_xfer_t xfer = {
            .daddr = w.addr,
            .ep_addr = 0,
            .setup = &req,
            .buffer = chunk,
        };
        if (!tuh_control_xfer(&xfer) || xfer.result != XFER_RESULT_SUCCESS) {
            snprintf(out, out_size, "falha no upload em 0x%06lX", (unsigned long)addr);
            return false;
        }

        offset += (uint32_t)got;
        addr += (uint32_t)got;
    }

    tusb_control_request_t done = {
        .bmRequestType = 0x40,
        .bRequest = 0x31,
        .wValue = (uint16_t)(ATH9K_FW_TEXT >> 8),
        .wIndex = 0,
        .wLength = 0,
    };
    tuh_xfer_t xfer = {
        .daddr = w.addr,
        .ep_addr = 0,
        .setup = &done,
    };
    if (!tuh_control_xfer(&xfer) || xfer.result != XFER_RESULT_SUCCESS) {
        snprintf(out, out_size, "falha no comando de boot 0x31");
        return false;
    }

    w.fw_uploaded = true;
    w.fw_size = entry.size;
    sleep_ms(250);
    return true;
}

static bool wifi_connect_service(uint16_t service, uint8_t dl_pipe, uint8_t ul_pipe,
                                 uint8_t *epid, char *out, size_t out_size) {
    uint8_t conn[10];
    be16_put(&conn[0], HTC_MSG_CONNECT_SERVICE_ID);
    be16_put(&conn[2], service);
    be16_put(&conn[4], 0);
    conn[6] = dl_pipe;
    conn[7] = ul_pipe;
    conn[8] = 0;
    conn[9] = 0;
    if (!wifi_htc_control(conn, sizeof(conn))) {
        snprintf(out, out_size, "AR9271: envio do servico %04X falhou", service);
        return false;
    }
    if (!wifi_wait_htc_message(HTC_MSG_CONNECT_SERVICE_RESPONSE_ID, 1500)) {
        snprintf(out, out_size, "AR9271: resposta do servico %04X ausente", service);
        return false;
    }

    uint16_t hlen = (uint16_t)((w.rx_msg[2] << 8) | w.rx_msg[3]);
    uint8_t *p = &w.rx_msg[HTC_HDR_LEN];
    uint16_t rsp_service = (uint16_t)((p[2] << 8) | p[3]);
    if (hlen < 8 || rsp_service != service || p[4] != HTC_SERVICE_SUCCESS) {
        wifi_drop_rx();
        snprintf(out, out_size, "AR9271: servico %04X recusado", service);
        return false;
    }
    *epid = p[5];
    wifi_drop_rx();
    return true;
}

static bool wifi_wmi_set_mode(void) {
    uint8_t mode[2];
    be16_put(mode, 1);
    return wifi_wmi_command(WMI_SET_MODE_CMDID, mode, sizeof(mode), NULL, 0, NULL, 500);
}

static bool wifi_wmi_vap_create(void) {
    uint8_t body[12];
    memset(body, 0, sizeof(body));
    body[0] = 0;
    body[1] = 1;
    if (w.mac_valid) {
        memcpy(&body[2], w.mac, 6);
    }
    be16_put(&body[9], 2304);
    return wifi_wmi_command(WMI_VAP_CREATE_CMDID, body, sizeof(body), NULL, 0, NULL, 500);
}

static bool wifi_wmi_node_create(void) {
    uint8_t body[22];
    memset(body, 0, sizeof(body));
    if (w.mac_valid) {
        memcpy(&body[0], w.mac, 6);
    }
    body[12] = 0;
    body[13] = 0;
    body[14] = 1;
    be16_put(&body[19], 0xFFFF);
    return wifi_wmi_command(WMI_NODE_CREATE_CMDID, body, sizeof(body), NULL, 0, NULL, 500);
}

static bool wifi_htc_start(char *out, size_t out_size) {
    if (!wifi_open_endpoints()) {
        snprintf(out, out_size, "AR9271: endpoints HTC nao encontrados");
        return false;
    }

    wifi_drop_rx();
    w.reg_in_done = false;
    wifi_submit_reg_in();

    if (!wifi_wait_htc_message(HTC_MSG_READY_ID, 2500)) {
        snprintf(out, out_size, "AR9271: HTC ready nao recebido");
        return false;
    }
    uint16_t hlen = (uint16_t)((w.rx_msg[2] << 8) | w.rx_msg[3]);
    if (hlen >= 8) {
        uint8_t *p = &w.rx_msg[HTC_HDR_LEN];
        w.htc_credits = (uint16_t)((p[2] << 8) | p[3]);
        w.htc_credit_size = (uint16_t)((p[4] << 8) | p[5]);
    }
    wifi_drop_rx();

    w.wmi_epid = 0;
    w.mgmt_epid = 0;
    w.data_epid = 0;
    if (!wifi_connect_service(WMI_CONTROL_SVC, 3, 4, &w.wmi_epid, out, out_size)) {
        return false;
    }
    if (!wifi_connect_service(WMI_MGMT_SVC, 2, 1, &w.mgmt_epid, out, out_size)) {
        return false;
    }
    if (!wifi_connect_service(WMI_DATA_BE_SVC, 2, 1, &w.data_epid, out, out_size)) {
        return false;
    }

    uint8_t cfg[4];
    be16_put(&cfg[0], HTC_MSG_CONFIG_PIPE_ID);
    cfg[2] = 1;
    cfg[3] = 33;
    if (!wifi_htc_control(cfg, sizeof(cfg))) {
        snprintf(out, out_size, "AR9271: HTC config pipe falhou");
        return false;
    }

    uint8_t setup[2];
    be16_put(setup, HTC_MSG_SETUP_COMPLETE_ID);
    if (!wifi_htc_control(setup, sizeof(setup))) {
        snprintf(out, out_size, "AR9271: HTC setup complete falhou");
        return false;
    }

    w.ready = true;
    w.wmi_seq = 0;

    uint8_t ver[8];
    uint16_t vlen = 0;
    if (wifi_wmi_command(WMI_GET_FW_VERSION, NULL, 0, ver, sizeof(ver), &vlen, 800) && vlen >= 4) {
        w.fw_major = (uint16_t)((ver[0] << 8) | ver[1]);
        w.fw_minor = (uint16_t)((ver[2] << 8) | ver[3]);
    }

    wifi_read_mac();
    bool rx_ok = wifi_wmi_set_mode();
    rx_ok = wifi_wmi_command(WMI_ATH_INIT_CMDID, NULL, 0, NULL, 0, NULL, 1500) && rx_ok;
    rx_ok = wifi_wmi_command(WMI_START_RECV_CMDID, NULL, 0, NULL, 0, NULL, 1000) && rx_ok;
    wifi_wmi_vap_create();
    wifi_wmi_node_create();
    wifi_wmi_command(WMI_ENABLE_INTR_CMDID, NULL, 0, NULL, 0, NULL, 500);

    w.rx_started = rx_ok;
    w.booted = true;
    return true;
}

bool ath9k_wifi_boot(char *out, size_t out_size) {
    if (out == NULL || out_size == 0) {
        return false;
    }
    out[0] = '\0';
    if (!ath9k_wifi_present()) {
        snprintf(out, out_size, "nenhum adaptador Atheros conectado");
        return false;
    }
    if (w.ready) {
        snprintf(out, out_size, "AR9271 pronto (fw %u.%u, mac %02X:%02X:%02X:%02X:%02X:%02X)",
                 w.fw_major, w.fw_minor,
                 w.mac[0], w.mac[1], w.mac[2], w.mac[3], w.mac[4], w.mac[5]);
        return true;
    }

    char step[96];
    if (!w.fw_uploaded) {
        if (!wifi_upload_firmware(step, sizeof(step))) {
            wifi_set_status(step);
            snprintf(out, out_size, "%s", step);
            return false;
        }
    }

    if (!wifi_htc_start(step, sizeof(step))) {
        wifi_set_status(step);
        snprintf(out, out_size, "%s", step);
        return false;
    }

    if (w.mac_valid) {
        snprintf(w.status, sizeof(w.status), "AR9271 online%s, MAC %02X:%02X:%02X:%02X:%02X:%02X",
                 w.rx_started ? "" : " (RX parcial)",
                 w.mac[0], w.mac[1], w.mac[2], w.mac[3], w.mac[4], w.mac[5]);
    } else {
        snprintf(w.status, sizeof(w.status), "AR9271 online%s (MAC indisponivel)",
                 w.rx_started ? "" : " (RX parcial)");
    }
    snprintf(out, out_size, "%s, fw %u.%u", w.status, w.fw_major, w.fw_minor);
    return true;
}

static uint16_t wifi_frame_to_eth(const uint8_t *frame, uint16_t len, uint8_t *out, uint16_t out_size) {
    if (len < 24 || out_size < 14) {
        return 0;
    }
    uint16_t fc = (uint16_t)(frame[0] | (frame[1] << 8));
    if (((fc >> 2) & 0x3U) != 2U || (fc & 0x4000U) != 0) {
        return 0;
    }

    uint16_t hdr = 24;
    bool to_ds = (fc & 0x0100U) != 0;
    bool from_ds = (fc & 0x0200U) != 0;
    if (to_ds && from_ds) {
        hdr = (uint16_t)(hdr + 6);
    }
    if ((fc & 0x0080U) != 0) {
        hdr = (uint16_t)(hdr + 2);
    }
    if ((fc & 0x8000U) != 0) {
        hdr = (uint16_t)(hdr + 4);
    }

    uint16_t end = len >= 4 ? (uint16_t)(len - 4) : 0;
    uint16_t pad = hdr & 3U;
    uint16_t payload = hdr;
    if (pad != 0 && end >= hdr + pad) {
        payload = (uint16_t)(hdr + pad);
    }
    if (end < payload + 8U) {
        return 0;
    }

    const uint8_t *llc = frame + payload;
    if (llc[0] != 0xAA || llc[1] != 0xAA || llc[2] != 0x03 ||
        llc[3] != 0x00 || llc[4] != 0x00 || llc[5] != 0x00) {
        return 0;
    }

    uint16_t data_len = (uint16_t)(end - payload - 8U);
    if ((uint32_t)data_len + 14U > out_size) {
        return 0;
    }

    const uint8_t *dst;
    const uint8_t *src;
    if (to_ds && !from_ds) {
        dst = frame + 16;
        src = frame + 10;
    } else if (!to_ds && from_ds) {
        dst = frame + 4;
        src = frame + 16;
    } else if (!to_ds && !from_ds) {
        dst = frame + 4;
        src = frame + 10;
    } else {
        dst = frame + 16;
        src = frame + 24;
    }

    memcpy(out, dst, 6);
    memcpy(out + 6, src, 6);
    out[12] = llc[6];
    out[13] = llc[7];
    if (data_len > 0) {
        memcpy(out + 14, llc + 8, data_len);
    }
    return (uint16_t)(14U + data_len);
}

static void wifi_handle_htc_frame(const uint8_t *msg, uint16_t len) {
    if (len < HTC_HDR_LEN) {
        return;
    }
    uint8_t epid = msg[0];
    uint8_t flags = msg[1];
    uint16_t plen = (uint16_t)((msg[2] << 8) | msg[3]);
    if (plen > len - HTC_HDR_LEN) {
        return;
    }
    const uint8_t *payload = msg + HTC_HDR_LEN;
    if ((flags & HTC_FLAGS_RECV_TRAILER) != 0) {
        uint8_t trim = msg[4];
        if (trim > plen) {
            return;
        }
        plen = (uint16_t)(plen - trim);
    }
    if (epid == 0x99) {
        wifi_set_status("AR9271 firmware panic");
        return;
    }
    if (epid == 0 || w.data_epid == 0 || epid != w.data_epid || plen <= HTC_RX_STATUS_LEN) {
        return;
    }

    uint8_t rx_status = payload[10];
    if ((rx_status & 0x3FU) != 0) {
        return;
    }
    w.rssi = (int8_t)payload[12];

    uint16_t datalen = (uint16_t)((payload[8] << 8) | payload[9]);
    uint16_t avail = (uint16_t)(plen - HTC_RX_STATUS_LEN);
    if (datalen > avail) {
        datalen = avail;
    }
    uint16_t eth_len = wifi_frame_to_eth(payload + HTC_RX_STATUS_LEN, datalen,
                                         w.eth_frame, sizeof(w.eth_frame));
    if (eth_len > 0 && w.rx_cb != NULL) {
        w.rx_frames++;
        w.rx_cb(w.eth_frame, eth_len);
    }
}

static void wifi_process_stream(const uint8_t *buf, uint16_t len) {
    uint16_t index = 0;
    while (index + 4U <= len) {
        uint16_t pkt_len = (uint16_t)(buf[index] | (buf[index + 1] << 8));
        uint16_t tag = (uint16_t)(buf[index + 2] | (buf[index + 3] << 8));
        if (tag != ATH_USB_RX_STREAM_MODE_TAG || pkt_len < HTC_HDR_LEN || pkt_len > ATH9K_RX_BUF_SIZE) {
            break;
        }
        uint16_t pad = (uint16_t)(4U - (pkt_len & 3U));
        if (pad == 4U) {
            pad = 0;
        }
        if ((uint32_t)index + 4U + pkt_len > len) {
            break;
        }
        wifi_handle_htc_frame(&buf[index + 4U], pkt_len);
        index = (uint16_t)(index + 4U + pkt_len + pad);
    }
}

void ath9k_wifi_task(void) {
    if (w.reg_in_done) {
        w.reg_in_done = false;
        uint32_t len = w.reg_in_actual;
        if (w.reg_in_result == XFER_RESULT_SUCCESS && len >= HTC_HDR_LEN && len <= sizeof(w.rx_msg) && !w.rx_ready) {
            memcpy(w.rx_msg, w.reg_in_buf, len);
            w.rx_len = (uint16_t)len;
            w.rx_ready = true;
        }
    }
    if (w.rx_bulk_done) {
        w.rx_bulk_done = false;
        if (w.rx_bulk_result == XFER_RESULT_SUCCESS && w.rx_bulk_actual >= 4) {
            wifi_process_stream(w.rx_bulk_buf, (uint16_t)w.rx_bulk_actual);
        }
    }
    if (w.endpoints_open && !w.rx_ready && !w.reg_in_pending) {
        wifi_submit_reg_in();
    }
    if (w.booted && w.data_epid != 0 && !w.rx_bulk_pending) {
        wifi_submit_bulk_rx();
    }
}

void ath9k_wifi_set_rx_cb(void (*cb)(const uint8_t *frame, uint16_t len)) {
    w.rx_cb = cb;
    if (w.booted) {
        wifi_submit_bulk_rx();
    }
}

bool ath9k_wifi_scan(AthWifiNetwork *out, int max, int *count, char *msg, size_t msg_size) {
    (void)out;
    (void)max;
    if (count != NULL) {
        *count = 0;
    }
    if (msg != NULL && msg_size > 0) {
        msg[0] = '\0';
    }
    if (!w.ready) {
        if (msg != NULL) {
            snprintf(msg, msg_size, "AR9271 sem firmware: use wifi load");
        }
        return false;
    }

    uint8_t echo[4] = {0x52, 0x50, 0x4F, 0x53};
    uint8_t rsp[4];
    uint16_t rlen = 0;
    if (!wifi_wmi_command(WMI_ECHO_CMDID, echo, sizeof(echo), rsp, sizeof(rsp), &rlen, 300)) {
        if (msg != NULL) {
            snprintf(msg, msg_size, "WMI sem resposta do AR9271");
        }
        return false;
    }

    if (msg != NULL) {
        snprintf(msg, msg_size,
                 "AR9271 e SoftMAC: o WMI do firmware nao expoe scan/assoc; "
                 "necessario driver 802.11 completo");
    }
    return false;
}

bool ath9k_wifi_connect(const char *ssid, const char *password, char *out, size_t out_size) {
    (void)password;
    if (out == NULL || out_size == 0) {
        return false;
    }
    if (!w.ready) {
        snprintf(out, out_size, "AR9271 sem firmware: use wifi load");
        return false;
    }
    if (ssid == NULL || ssid[0] == '\0') {
        snprintf(out, out_size, "SSID vazio");
        return false;
    }
    snprintf(out, out_size,
             "AR9271 e SoftMAC: associacao WPA2 de %s requer driver 802.11/mac80211",
             ssid);
    return false;
}

bool ath9k_wifi_disconnect(char *out, size_t out_size) {
    if (out == NULL || out_size == 0) {
        return false;
    }
    if (!w.ready) {
        snprintf(out, out_size, "AR9271 sem firmware: use wifi load");
        return false;
    }

    bool was_connected = w.connected || w.associated;
    w.connected = false;
    w.associated = false;
    w.wpa_done = false;
    w.secure = false;
    memset(w.bssid, 0, sizeof(w.bssid));
    memset(w.ssid, 0, sizeof(w.ssid));
    w.rssi = 0;
    w.channel = 0;
    wifi_set_status(was_connected ? "AR9271 desconectado" : "AR9271 sem conexao");
    snprintf(out, out_size, "%s", w.status);
    return true;
}

bool ath9k_wifi_send(const uint8_t *frame, uint16_t len) {
    (void)frame;
    (void)len;
    return false;
}

void ath9k_wifi_info(AthWifiInfo *info) {
    if (info == NULL) {
        return;
    }
    memset(info, 0, sizeof(*info));
    info->present = w.present;
    info->booted = w.booted;
    info->ready = w.ready;
    info->mac_valid = w.mac_valid;
    memcpy(info->mac, w.mac, 6);
    info->fw_major = w.fw_major;
    info->fw_minor = w.fw_minor;
    info->fw_size = w.fw_size;
    info->associated = w.associated;
    info->connected = w.connected;
    info->secure = w.secure;
    info->wpa_done = w.wpa_done;
    memcpy(info->bssid, w.bssid, 6);
    snprintf(info->ssid, sizeof(info->ssid), "%s", w.ssid);
    info->rssi = w.rssi;
    info->channel = w.channel;
    snprintf(info->status, sizeof(info->status), "%s", w.status);
}
