#ifndef RP_OS_NET_STACK_H
#define RP_OS_NET_STACK_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint16_t vid, pid;
    uint8_t addr;
} NetUsbDev;

typedef struct {
    char ssid[33];
    int8_t rssi;
    uint8_t channel;
    bool secure;
} NetWifiNetwork;

typedef struct {
    bool link_up;
    bool dhcp_running;
    bool dhcp_bound;
    char ifname[8];
    char ip[20];
    char mask[20];
    char gw[20];
    uint8_t mac[6];
    uint32_t rx_frames;
    uint32_t tx_frames;
    bool wifi_present;
    bool wifi_booted;
    bool wifi_connected;
    bool wifi_mac_valid;
    uint8_t wifi_addr;
    uint16_t wifi_vid;
    uint16_t wifi_pid;
    uint8_t wifi_mac[6];
    char wifi_ssid[33];
    char wifi_status[72];
    bool fw_loaded;
    uint32_t fw_size;
    NetUsbDev usb_devs[8];
    int usb_dev_count;
} NetStatus;

void net_stack_init(void);
void net_stack_task(void);
void net_status_get(NetStatus *status);

bool net_ping(const char *target, int count, char *out, size_t out_size);
void net_dhcp_restart(void);

void net_usb_link_up(const uint8_t mac[6]);
void net_usb_link_down(void);
void net_usb_input(const uint8_t *frame, uint16_t len);

void net_wifi_usb_mounted(uint8_t addr, uint16_t vid, uint16_t pid);
void net_wifi_usb_unmounted(uint8_t addr);
bool net_wifi_load_firmware(char *out, size_t out_size);
bool net_wifi_upload_test(char *out, size_t out_size);
bool net_wifi_scan(NetWifiNetwork *out, int max, int *count, char *msg, size_t msg_size);
bool net_wifi_connect(const char *ssid, const char *password, char *out, size_t out_size);
void net_wifi_link_up(const uint8_t mac[6], const char *ssid);
void net_wifi_link_down(void);
void net_wifi_input(const uint8_t *frame, uint16_t len);

#endif
