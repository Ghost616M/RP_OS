#include "hw.h"

#include "hardware/clocks.h"
#include "hardware/gpio.h"
#include "hardware/pwm.h"
#include "pico/stdlib.h"

static HwMode pin_modes[HW_PIN_COUNT];

static int pin_index(int pin) {
    if (pin < HW_PIN_FIRST || pin > HW_PIN_LAST) {
        return -1;
    }
    return pin - HW_PIN_FIRST;
}

void hw_init(void) {
    for (int pin = HW_PIN_FIRST; pin <= HW_PIN_LAST; ++pin) {
        gpio_init((uint)pin);
        gpio_set_dir((uint)pin, GPIO_IN);
        gpio_disable_pulls((uint)pin);
        pin_modes[pin] = HW_MODE_UNUSED;
    }
}

bool hw_pin_valid(int pin) {
    return pin_index(pin) >= 0;
}

HwMode hw_pin_mode(int pin) {
    int idx = pin_index(pin);
    return idx < 0 ? HW_MODE_UNUSED : pin_modes[idx];
}

const char *hw_mode_name(HwMode mode) {
    switch (mode) {
        case HW_MODE_INPUT: return "IN";
        case HW_MODE_OUTPUT: return "OUT";
        case HW_MODE_PWM: return "PWM";
        default: return "--";
    }
}

static void pwm_release(int pin) {
    if (pin >= 0) {
        uint slice = pwm_gpio_to_slice_num((uint)pin);
        uint channel = pwm_gpio_to_channel((uint)pin);
        pwm_set_chan_level(slice, channel, 0);
    }
}

void hw_pin_set_mode(int pin, HwMode mode) {
    int idx = pin_index(pin);
    if (idx < 0) {
        return;
    }

    if (pin_modes[idx] == HW_MODE_PWM) {
        pwm_release(pin);
    }

    switch (mode) {
        case HW_MODE_INPUT:
            gpio_init((uint)pin);
            gpio_set_dir((uint)pin, GPIO_IN);
            gpio_pull_down((uint)pin);
            break;
        case HW_MODE_OUTPUT:
            gpio_init((uint)pin);
            gpio_put((uint)pin, 0);
            gpio_set_dir((uint)pin, GPIO_OUT);
            break;
        case HW_MODE_PWM:
            hw_pin_pwm(pin, 1000, 50);
            return;
        default:
            gpio_init((uint)pin);
            gpio_set_dir((uint)pin, GPIO_IN);
            gpio_disable_pulls((uint)pin);
            break;
    }
    pin_modes[idx] = mode;
}

bool hw_pin_get(int pin) {
    int idx = pin_index(pin);
    if (idx < 0) {
        return false;
    }
    return gpio_get((uint)pin);
}

void hw_pin_write(int pin, bool level) {
    int idx = pin_index(pin);
    if (idx < 0 || pin_modes[idx] != HW_MODE_OUTPUT) {
        return;
    }
    gpio_put((uint)pin, level);
}

void hw_pin_toggle(int pin) {
    int idx = pin_index(pin);
    if (idx < 0 || pin_modes[idx] != HW_MODE_OUTPUT) {
        return;
    }
    gpio_xor_mask(1u << (uint)pin);
}

void hw_pin_pwm(int pin, uint32_t freq_hz, uint8_t duty_percent) {
    int idx = pin_index(pin);
    if (idx < 0 || freq_hz == 0 || duty_percent > 100) {
        return;
    }

    uint32_t sys_hz = clock_get_hz(clk_sys);
    if (freq_hz > sys_hz / 2) {
        return;
    }

    uint32_t wrap;
    float divider;
    if (sys_hz / freq_hz <= 65536U) {
        divider = 1.0f;
        wrap = sys_hz / freq_hz;
        if (wrap == 0) wrap = 1;
        wrap -= 1;
    } else {
        divider = (float)sys_hz / ((float)freq_hz * 65536.0f);
        wrap = 65535;
    }

    uint slice = pwm_gpio_to_slice_num((uint)pin);
    uint channel = pwm_gpio_to_channel((uint)pin);

    gpio_set_function((uint)pin, GPIO_FUNC_PWM);
    pwm_set_clkdiv(slice, divider);
    pwm_set_wrap(slice, (uint16_t)wrap);
    uint32_t level = ((uint32_t)wrap + 1U) * duty_percent / 100U;
    pwm_set_chan_level(slice, channel, (uint16_t)level);
    pwm_set_enabled(slice, true);

    pin_modes[idx] = HW_MODE_PWM;
}

void hw_pin_pwm_off(int pin) {
    int idx = pin_index(pin);
    if (idx < 0) {
        return;
    }
    if (pin_modes[idx] == HW_MODE_PWM) {
        pwm_release(pin);
    }
    gpio_init((uint)pin);
    gpio_put((uint)pin, 0);
    gpio_set_dir((uint)pin, GPIO_OUT);
    pin_modes[idx] = HW_MODE_OUTPUT;
}

static void i2c_delay(void) {
    busy_wait_us_32(3);
}

static void i2c_sda_low(uint8_t sda) {
    gpio_set_dir(sda, GPIO_OUT);
    gpio_put(sda, 0);
}

static void i2c_sda_release(uint8_t sda) {
    gpio_set_dir(sda, GPIO_IN);
    gpio_pull_up(sda);
}

static void i2c_scl_low(uint8_t scl) {
    gpio_set_dir(scl, GPIO_OUT);
    gpio_put(scl, 0);
}

static void i2c_scl_release(uint8_t scl) {
    gpio_set_dir(scl, GPIO_IN);
    gpio_pull_up(scl);
}

static bool i2c_sda_read(uint8_t sda) {
    return gpio_get(sda);
}

static void i2c_start(uint8_t sda, uint8_t scl) {
    i2c_sda_release(sda);
    i2c_scl_release(scl);
    i2c_delay();
    i2c_sda_low(sda);
    i2c_delay();
    i2c_scl_low(scl);
    i2c_delay();
}

static void i2c_stop(uint8_t sda, uint8_t scl) {
    i2c_sda_low(sda);
    i2c_delay();
    i2c_scl_release(scl);
    i2c_delay();
    i2c_sda_release(sda);
    i2c_delay();
}

static bool i2c_write_byte(uint8_t sda, uint8_t scl, uint8_t value) {
    for (int bit = 7; bit >= 0; --bit) {
        if (value & (1U << bit)) {
            i2c_sda_release(sda);
        } else {
            i2c_sda_low(sda);
        }
        i2c_delay();
        i2c_scl_release(scl);
        i2c_delay();
        i2c_scl_low(scl);
        i2c_delay();
    }

    i2c_sda_release(sda);
    i2c_delay();
    i2c_scl_release(scl);
    i2c_delay();
    bool ack = !i2c_sda_read(sda);
    i2c_scl_low(scl);
    i2c_delay();
    return ack;
}

int hw_i2c_scan(uint8_t sda, uint8_t scl, uint8_t *found, int max_found) {
    if (!hw_pin_valid(sda) || !hw_pin_valid(scl) || sda == scl || found == NULL || max_found <= 0) {
        return 0;
    }

    gpio_init(sda);
    gpio_init(scl);
    gpio_set_dir(sda, GPIO_IN);
    gpio_set_dir(scl, GPIO_IN);
    gpio_pull_up(sda);
    gpio_pull_up(scl);
    i2c_delay();

    int count = 0;
    for (uint8_t addr = 0x08; addr <= 0x77; ++addr) {
        i2c_start(sda, scl);
        bool ack = i2c_write_byte(sda, scl, (uint8_t)(addr << 1));
        i2c_stop(sda, scl);
        if (ack) {
            if (count < max_found) {
                found[count] = addr;
            }
            count++;
        }
    }

    gpio_init(sda);
    gpio_init(scl);
    gpio_set_dir(sda, GPIO_IN);
    gpio_set_dir(scl, GPIO_IN);
    gpio_disable_pulls(sda);
    gpio_disable_pulls(scl);

    return count > max_found ? max_found : count;
}
