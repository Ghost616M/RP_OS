#include "flash_disk.h"

#include <string.h>

#include "hardware/flash.h"
#include "hardware/address_mapped.h"
#include "pico/flash.h"
#include "pico/stdlib.h"

#define FLASH_DISK_BLOCK_SIZE 4096U
#define FLASH_BLOCK_COUNT (FLASH_FS_SIZE / FLASH_DISK_BLOCK_SIZE)
#define SECTORS_PER_BLOCK (FLASH_DISK_BLOCK_SIZE / FLASH_FS_SECTOR_SIZE)

static uint8_t block_cache[FLASH_DISK_BLOCK_SIZE] __attribute__((aligned(4)));
static uint32_t cached_block = UINT32_MAX;
static bool cache_dirty;

typedef struct {
    uint32_t offset;
    const uint8_t *data;
} FlashJob;

static void __no_inline_not_in_flash_func(flash_erase_program)(void *param) {
    FlashJob *job = (FlashJob *)param;
    flash_range_erase(job->offset, FLASH_DISK_BLOCK_SIZE);
    flash_range_program(job->offset, job->data, FLASH_DISK_BLOCK_SIZE);
}

bool flash_disk_flush(void) {
    if (!cache_dirty || cached_block == UINT32_MAX) {
        return true;
    }

    FlashJob job = {
        .offset = FLASH_FS_OFFSET + cached_block * FLASH_DISK_BLOCK_SIZE,
        .data = block_cache,
    };

    int rc = flash_safe_execute(flash_erase_program, &job, 5000);
    if (rc != 0) {
        return false;
    }

    cache_dirty = false;
    return true;
}

static bool load_block(uint32_t block) {
    if (block >= FLASH_BLOCK_COUNT) {
        return false;
    }
    if (block == cached_block) {
        return true;
    }
    if (!flash_disk_flush()) {
        return false;
    }

    const uint8_t *src = (const uint8_t *)(XIP_BASE + FLASH_FS_OFFSET + block * FLASH_DISK_BLOCK_SIZE);
    memcpy(block_cache, src, FLASH_DISK_BLOCK_SIZE);
    cached_block = block;
    cache_dirty = false;
    return true;
}

void flash_disk_init(void) {
    cached_block = UINT32_MAX;
    cache_dirty = false;
}

bool flash_disk_has_fs(void) {
    const uint8_t *boot = (const uint8_t *)(XIP_BASE + FLASH_FS_OFFSET);
    if (boot[510] != 0x55 || boot[511] != 0xAA) {
        return false;
    }
    return boot[0] == 0xEB || boot[0] == 0xE9;
}

bool flash_disk_read(uint32_t lba, uint8_t *buffer, uint32_t count) {
    if (buffer == NULL || lba + count > FLASH_FS_SECTOR_COUNT) {
        return false;
    }

    for (uint32_t i = 0; i < count; ++i) {
        uint32_t sector = lba + i;
        uint32_t block = sector / SECTORS_PER_BLOCK;
        uint32_t offset = (sector % SECTORS_PER_BLOCK) * FLASH_FS_SECTOR_SIZE;
        if (!load_block(block)) {
            return false;
        }
        memcpy(buffer + i * FLASH_FS_SECTOR_SIZE, block_cache + offset, FLASH_FS_SECTOR_SIZE);
    }
    return true;
}

bool flash_disk_write(uint32_t lba, const uint8_t *buffer, uint32_t count) {
    if (buffer == NULL || lba + count > FLASH_FS_SECTOR_COUNT) {
        return false;
    }

    for (uint32_t i = 0; i < count; ++i) {
        uint32_t sector = lba + i;
        uint32_t block = sector / SECTORS_PER_BLOCK;
        uint32_t offset = (sector % SECTORS_PER_BLOCK) * FLASH_FS_SECTOR_SIZE;
        if (!load_block(block)) {
            return false;
        }
        memcpy(block_cache + offset, buffer + i * FLASH_FS_SECTOR_SIZE, FLASH_FS_SECTOR_SIZE);
        cache_dirty = true;
    }
    return true;
}

uint32_t flash_disk_sector_count(void) {
    return FLASH_FS_SECTOR_COUNT;
}
