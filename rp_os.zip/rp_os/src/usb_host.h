#ifndef RP_OS_USB_HOST_H
#define RP_OS_USB_HOST_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#define USB_KIND_KEYBOARD 0x01
#define USB_KIND_MOUSE 0x02
#define USB_KIND_MSC 0x04
#define USB_KIND_OTHER 0x08
#define USB_KIND_WIFI 0x10
#define USB_KIND_NET 0x20
#define USB_KIND_HUB 0x40

typedef struct {
    uint8_t addr;
    uint16_t vid;
    uint16_t pid;
    uint8_t kind;
    char name[24];
} UsbDeviceInfo;

void usb_init(void);
void usb_task(void);

bool usb_cdc_connected(void);
void usb_cdc_write(const char *text);

bool usb_msc_ready(void);
bool usb_msc_probe(void);
uint32_t usb_msc_block_count(void);
uint32_t usb_msc_block_size(void);
bool usb_msc_read(uint32_t lba, uint8_t *buffer, uint32_t count);
bool usb_msc_write(uint32_t lba, const uint8_t *buffer, uint32_t count);

uint8_t usb_keyboard_count(void);
uint8_t usb_mouse_count(void);
int usb_devices(UsbDeviceInfo *out, int max_devices);
const char *usb_device_kind_name(uint8_t kind);
const char *usb_chip_hint(uint16_t vid, uint16_t pid);

bool usb_wifi_fw_test(const uint8_t *data, size_t len, char *out, size_t out_size);

#endif
