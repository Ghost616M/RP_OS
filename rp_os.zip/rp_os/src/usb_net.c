#include "usb_net.h"

#include <string.h>

#include "tusb.h"
#include "host/usbh_pvt.h"
#include "class/cdc/cdc.h"
#include "pico/unique_id.h"
#include "net_stack.h"

#define ECM_MAX_DEV (CFG_TUH_DEVICE_MAX + CFG_TUH_HUB + 1)
#define ECM_FRAME_MAX 1600

typedef struct {
    bool used;
    bool ctrl_present;
    bool data_present;
    bool filter_sent;
    bool rx_started;
    bool rx_pending;
    bool link_reported;
    uint8_t daddr;
    uint8_t rhport;
    uint8_t itf_ctrl;
    uint8_t itf_data;
    uint8_t i_mac;
    uint8_t ep_in;
    uint8_t ep_out;
    uint8_t mac[6];
} EcmState;

static EcmState ecm_dev[ECM_MAX_DEV];
static uint8_t rx_buffer[ECM_FRAME_MAX] __attribute__((aligned(4)));
static uint8_t tx_buffer[ECM_FRAME_MAX] __attribute__((aligned(4)));
static bool tx_busy;

static EcmState *ecm_get(uint8_t daddr) {
    if (daddr == 0 || daddr >= ECM_MAX_DEV) {
        return NULL;
    }
    return &ecm_dev[daddr];
}

static void ecm_fallback_mac(uint8_t mac[6]) {
    pico_unique_board_id_t id;
    pico_get_unique_board_id(&id);
    mac[0] = 0x02;
    mac[1] = id.id[0];
    mac[2] = id.id[1];
    mac[3] = id.id[2];
    mac[4] = id.id[3];
    mac[5] = id.id[4];
}

static void ecm_read_mac(EcmState *st) {
    if (st->i_mac == 0) {
        ecm_fallback_mac(st->mac);
        return;
    }

    uint8_t buf[128];
    tusb_control_request_t req = {
        .bmRequestType = 0x80,
        .bRequest = TUSB_REQ_GET_DESCRIPTOR,
        .wValue = (uint16_t)((TUSB_DESC_STRING << 8) | st->i_mac),
        .wIndex = 0x0409,
        .wLength = sizeof(buf),
    };
    tuh_xfer_t xfer = {
        .daddr = st->daddr,
        .ep_addr = 0,
        .setup = &req,
        .buffer = buf,
    };
    if (!tuh_control_xfer(&xfer) || xfer.result != XFER_RESULT_SUCCESS || xfer.actual_len < 14) {
        ecm_fallback_mac(st->mac);
        return;
    }

    uint8_t mac[6];
    int nibbles = 0;
    bool valid = true;
    memset(mac, 0, sizeof(mac));
    for (uint32_t i = 2; i + 1 < xfer.actual_len && nibbles < 12; i += 2) {
        char c = (char)buf[i];
        int v;
        if (c >= '0' && c <= '9') v = c - '0';
        else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') v = c - 'A' + 10;
        else { valid = false; break; }
        mac[nibbles / 2] = (uint8_t)((mac[nibbles / 2] << 4) | v);
        nibbles++;
    }
    if (!valid || nibbles != 12) {
        ecm_fallback_mac(st->mac);
        return;
    }
    memcpy(st->mac, mac, 6);
}

static void ecm_submit_rx(EcmState *st) {
    if (!st->rx_started || st->rx_pending || st->ep_in == 0) {
        return;
    }
    tuh_xfer_t xfer = {
        .daddr = st->daddr,
        .ep_addr = st->ep_in,
        .buffer = rx_buffer,
        .buflen = sizeof(rx_buffer),
    };
    if (tuh_edpt_xfer(&xfer)) {
        st->rx_pending = true;
    }
}

static void ecm_send_filter(EcmState *st) {
    tusb_control_request_t req = {
        .bmRequestType = 0x21,
        .bRequest = CDC_REQUEST_SET_ETHERNET_PACKET_FILTER,
        .wValue = 0x000C,
        .wIndex = st->itf_ctrl,
        .wLength = 0,
    };
    tuh_xfer_t xfer = {
        .daddr = st->daddr,
        .ep_addr = 0,
        .setup = &req,
    };
    tuh_control_xfer(&xfer);
}

static bool ecm_scan_descriptors(EcmState *st, const tusb_desc_interface_t *itf_desc, uint16_t max_len) {
    const uint8_t *p = (const uint8_t *)itf_desc;
    const uint8_t *end = p + max_len;
    uint8_t cur_class = itf_desc->bInterfaceClass;

    while (p + 2 <= end) {
        uint8_t blen = p[0];
        uint8_t btype = p[1];
        if (blen < 2 || p + blen > end) {
            break;
        }

        if (btype == TUSB_DESC_INTERFACE) {
            const tusb_desc_interface_t *itf = (const tusb_desc_interface_t *)p;
            cur_class = itf->bInterfaceClass;
            if (cur_class == TUSB_CLASS_CDC_DATA) {
                st->data_present = true;
                st->itf_data = itf->bInterfaceNumber;
            }
        } else if (btype == TUSB_DESC_CS_INTERFACE && blen >= 4 &&
                   p[2] == CDC_FUNC_DESC_ETHERNET_NETWORKING) {
            st->i_mac = p[3];
        } else if (btype == TUSB_DESC_ENDPOINT) {
            const tusb_desc_endpoint_t *ep = (const tusb_desc_endpoint_t *)p;
            if (cur_class == TUSB_CLASS_CDC_DATA && ep->bmAttributes.xfer == TUSB_XFER_BULK) {
                bool in = (ep->bEndpointAddress & 0x80) != 0;
                if (in && st->ep_in == 0) {
                    if (!tuh_edpt_open(st->daddr, ep)) {
                        return false;
                    }
                    st->ep_in = ep->bEndpointAddress;
                } else if (!in && st->ep_out == 0) {
                    if (!tuh_edpt_open(st->daddr, ep)) {
                        return false;
                    }
                    st->ep_out = ep->bEndpointAddress;
                }
            }
        }
        p += blen;
    }
    return true;
}

static bool ecm_open(uint8_t rhport, uint8_t daddr, const tusb_desc_interface_t *itf_desc, uint16_t max_len) {
    EcmState *st = ecm_get(daddr);
    if (st == NULL) {
        return false;
    }

    bool is_ctrl = itf_desc->bInterfaceClass == TUSB_CLASS_CDC &&
                   itf_desc->bInterfaceSubClass == CDC_COMM_SUBCLASS_ETHERNET_CONTROL_MODEL;
    bool is_data = itf_desc->bInterfaceClass == TUSB_CLASS_CDC_DATA;

    if (is_ctrl) {
        memset(st, 0, sizeof(*st));
        st->used = true;
        st->daddr = daddr;
        st->rhport = rhport;
        st->itf_ctrl = itf_desc->bInterfaceNumber;
        st->ctrl_present = true;
    } else if (is_data && st->used && st->ctrl_present) {
        st->data_present = true;
        st->itf_data = itf_desc->bInterfaceNumber;
    } else {
        return false;
    }

    if (!ecm_scan_descriptors(st, itf_desc, max_len)) {
        memset(st, 0, sizeof(*st));
        return false;
    }
    return st->ctrl_present;
}

static bool ecm_set_config(uint8_t daddr, uint8_t itf_num) {
    EcmState *st = ecm_get(daddr);
    if (st == NULL || !st->used) {
        return false;
    }

    if (itf_num == st->itf_ctrl) {
        if (!st->filter_sent) {
            st->filter_sent = true;
            ecm_read_mac(st);
            ecm_send_filter(st);
        }
    } else if (itf_num == st->itf_data) {
        if (!st->rx_started && st->ep_in != 0 && st->ep_out != 0) {
            st->rx_started = true;
            ecm_submit_rx(st);
            if (!st->link_reported) {
                st->link_reported = true;
                net_usb_link_up(st->mac);
            }
        }
    }

    usbh_driver_set_config_complete(daddr, itf_num);
    return true;
}

static bool ecm_xfer_cb(uint8_t daddr, uint8_t ep_addr, xfer_result_t result, uint32_t xferred_bytes) {
    EcmState *st = ecm_get(daddr);
    if (st == NULL || !st->used) {
        return true;
    }

    if (ep_addr == st->ep_in) {
        st->rx_pending = false;
        if (result == XFER_RESULT_SUCCESS && xferred_bytes > 0 && xferred_bytes <= sizeof(rx_buffer)) {
            net_usb_input(rx_buffer, (uint16_t)xferred_bytes);
        }
        ecm_submit_rx(st);
    } else if (ep_addr == st->ep_out) {
        tx_busy = false;
    }
    return true;
}

static void ecm_close(uint8_t daddr) {
    EcmState *st = ecm_get(daddr);
    if (st == NULL || !st->used) {
        return;
    }
    if (st->link_reported) {
        net_usb_link_down();
    }
    memset(st, 0, sizeof(*st));
    tx_busy = false;
}

static bool ecm_init(void) {
    memset(ecm_dev, 0, sizeof(ecm_dev));
    tx_busy = false;
    return true;
}

static bool ecm_deinit(void) {
    memset(ecm_dev, 0, sizeof(ecm_dev));
    tx_busy = false;
    return true;
}

static const usbh_class_driver_t ecm_driver = {
    .name = "ECM",
    .init = ecm_init,
    .deinit = ecm_deinit,
    .open = ecm_open,
    .set_config = ecm_set_config,
    .xfer_cb = ecm_xfer_cb,
    .close = ecm_close,
};

usbh_class_driver_t const *usb_net_get_driver(void) {
    return &ecm_driver;
}

void usb_net_task(void) {
    for (int i = 1; i < ECM_MAX_DEV; ++i) {
        EcmState *st = &ecm_dev[i];
        if (st->used && st->rx_started && !st->rx_pending) {
            ecm_submit_rx(st);
        }
    }
}

bool usb_net_send(const uint8_t *frame, uint16_t len) {
    if (frame == NULL || len == 0 || len > 1514) {
        return false;
    }
    for (int i = 1; i < ECM_MAX_DEV; ++i) {
        EcmState *st = &ecm_dev[i];
        if (!st->used || !st->rx_started || st->ep_out == 0) {
            continue;
        }
        if (tx_busy) {
            return false;
        }
        memcpy(tx_buffer, frame, len);
        tx_busy = true;
        tuh_xfer_t xfer = {
            .daddr = st->daddr,
            .ep_addr = st->ep_out,
            .buffer = tx_buffer,
            .buflen = len,
        };
        if (!tuh_edpt_xfer(&xfer)) {
            tx_busy = false;
            return false;
        }
        return true;
    }
    return false;
}

bool usb_net_present(void) {
    for (int i = 1; i < ECM_MAX_DEV; ++i) {
        if (ecm_dev[i].used && ecm_dev[i].link_reported) {
            return true;
        }
    }
    return false;
}
