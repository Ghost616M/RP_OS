#ifndef RP_OS_SHELL_H
#define RP_OS_SHELL_H

#include <stddef.h>

#define SHELL_LINE_WIDTH 39

typedef void (*ShellWriteFn)(void *ctx, const char *text);

typedef struct {
    char cwd[128];
    ShellWriteFn write;
    void *ctx;
} Shell;

void shell_init(Shell *shell, ShellWriteFn write, void *ctx);
void shell_set_cwd(Shell *shell, const char *path);
void shell_prompt(Shell *shell, char *out, size_t out_size);
void shell_execute(Shell *shell, const char *line);

#endif
