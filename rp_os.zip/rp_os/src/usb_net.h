#ifndef RP_OS_USB_NET_H
#define RP_OS_USB_NET_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "tusb.h"
#include "host/usbh_pvt.h"

usbh_class_driver_t const *usb_net_get_driver(void);
bool usb_net_send(const uint8_t *frame, uint16_t len);
bool usb_net_present(void);
void usb_net_task(void);

#endif
