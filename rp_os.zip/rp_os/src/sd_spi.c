#include "sd_spi.h"

#include <string.h>

#include "hardware/gpio.h"
#include "hardware/spi.h"
#include "pico/stdlib.h"

#define SD_INIT_HZ 400000
#define SD_FAST_HZ 12000000
#define SD_TOKEN_START_BLOCK 0xFE

typedef struct {
    spi_inst_t *spi;
    uint sck;
    uint mosi;
    uint miso;
    uint cs;
} SdPins;

static spi_inst_t *SD_SPI = spi1;
static uint8_t ff_block[512];

static int g_cs = -1;
static bool g_ready;
static bool g_sdhc;
static uint32_t g_sectors;

static uint8_t spi_xfer(uint8_t data);

static void cs_select(void) {
    gpio_put((uint)g_cs, 0);
}

static void cs_deselect(void) {
    if (g_cs < 0) {
        return;
    }
    gpio_put((uint)g_cs, 1);
    spi_xfer(0xFF);
}

static uint8_t spi_xfer(uint8_t data) {
    uint8_t rx;
    spi_write_read_blocking(SD_SPI, &data, &rx, 1);
    return rx;
}

static bool wait_ready(uint32_t timeout_ms) {
    uint64_t deadline = time_us_64() + (uint64_t)timeout_ms * 1000ULL;
    do {
        if (spi_xfer(0xFF) == 0xFF) {
            return true;
        }
    } while (time_us_64() < deadline);
    return false;
}

static uint8_t cmd_raw(uint8_t cmd, uint32_t arg) {
    uint8_t frame[6];
    frame[0] = (uint8_t)(0x40 | cmd);
    frame[1] = (uint8_t)(arg >> 24);
    frame[2] = (uint8_t)(arg >> 16);
    frame[3] = (uint8_t)(arg >> 8);
    frame[4] = (uint8_t)arg;
    frame[5] = 0x01;
    if (cmd == 0) frame[5] = 0x95;
    if (cmd == 8) frame[5] = 0x87;

    spi_xfer(0xFF);
    spi_write_blocking(SD_SPI, frame, sizeof(frame));

    uint8_t response = 0xFF;
    for (int i = 0; i < 16; ++i) {
        response = spi_xfer(0xFF);
        if ((response & 0x80) == 0) {
            break;
        }
    }
    return response;
}

static uint8_t cmd(uint8_t cmd_id, uint32_t arg, bool keep_selected) {
    cs_select();
    uint8_t response = cmd_raw(cmd_id, arg);
    if (!keep_selected) {
        cs_deselect();
    }
    return response;
}

static bool read_csd(void) {
    uint8_t csd[16];
    cs_select();
    if (cmd_raw(9, 0) != 0) {
        cs_deselect();
        return false;
    }

    uint64_t deadline = time_us_64() + 200000ULL;
    uint8_t token = 0xFF;
    while (time_us_64() < deadline) {
        token = spi_xfer(0xFF);
        if (token == SD_TOKEN_START_BLOCK) break;
    }
    if (token != SD_TOKEN_START_BLOCK) {
        cs_deselect();
        return false;
    }

    spi_write_read_blocking(SD_SPI, ff_block, csd, sizeof(csd));
    spi_xfer(0xFF);
    spi_xfer(0xFF);
    cs_deselect();

    uint8_t csd_structure = (csd[0] >> 6) & 0x03;
    if (csd_structure == 1) {
        uint32_t c_size = ((uint32_t)(csd[7] & 0x3F) << 16) | ((uint32_t)csd[8] << 8) | csd[9];
        g_sectors = (c_size + 1U) * 1024U;
    } else {
        uint32_t c_size = ((uint32_t)(csd[6] & 0x03) << 10) | ((uint32_t)csd[7] << 2) | ((csd[8] >> 6) & 0x03);
        uint8_t c_size_mult = ((csd[9] & 0x03) << 1) | ((csd[10] >> 7) & 0x01);
        uint8_t read_bl_len = csd[5] & 0x0F;
        uint32_t mult = 1U << (c_size_mult + 2U);
        uint32_t blocknr = (c_size + 1U) * mult;
        uint64_t bytes = (uint64_t)blocknr << read_bl_len;
        g_sectors = (uint32_t)(bytes / 512U);
    }
    return g_sectors != 0;
}

static bool sd_try_pins(const SdPins *pins) {
    SD_SPI = pins->spi;
    g_cs = (int)pins->cs;

    gpio_init(pins->cs);
    gpio_pull_up(pins->cs);
    gpio_put(pins->cs, 1);
    gpio_set_dir(pins->cs, GPIO_OUT);

    gpio_set_function(pins->sck, GPIO_FUNC_SPI);
    gpio_set_function(pins->mosi, GPIO_FUNC_SPI);
    gpio_set_function(pins->miso, GPIO_FUNC_SPI);
    gpio_pull_up(pins->miso);

    spi_init(SD_SPI, SD_INIT_HZ);
    spi_set_format(SD_SPI, 8, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);

    cs_deselect();
    for (int i = 0; i < 20; ++i) {
        spi_xfer(0xFF);
    }

    bool cmd0_ok = false;
    for (int retry = 0; retry < 10; ++retry) {
        if (cmd(0, 0, false) == 0x01) {
            cmd0_ok = true;
            break;
        }
        sleep_ms(10);
    }
    if (!cmd0_ok) {
        return false;
    }

    bool v2 = false;
    cs_select();
    if (cmd_raw(8, 0x1AA) == 0x01) {
        uint8_t r7[4];
        spi_write_read_blocking(SD_SPI, ff_block, r7, sizeof(r7));
        v2 = (r7[2] == 0x01 && r7[3] == 0xAA);
    }
    cs_deselect();

    uint32_t acmd_arg = v2 ? 0x40000000UL : 0;
    bool initialized = false;
    for (int attempt = 0; attempt < 250; ++attempt) {
        cs_select();
        uint8_t r55 = cmd_raw(55, 0);
        uint8_t r41 = 0xFF;
        if ((r55 & 0xFE) == 0) {
            r41 = cmd_raw(41, acmd_arg);
        }
        cs_deselect();
        if (r41 == 0x00) {
            initialized = true;
            break;
        }
        sleep_ms(10);
    }
    if (!initialized) {
        return false;
    }

    g_sdhc = false;
    cs_select();
    if (cmd_raw(58, 0) == 0x00) {
        uint8_t ocr[4];
        spi_write_read_blocking(SD_SPI, ff_block, ocr, sizeof(ocr));
        g_sdhc = (ocr[0] & 0x40) != 0;
    }
    cs_deselect();

    if (!g_sdhc) {
        if (cmd(16, 512, false) != 0x00) {
            return false;
        }
    }

    if (!wait_ready(500)) {
        return false;
    }
    spi_set_baudrate(SD_SPI, SD_FAST_HZ);
    if (!read_csd()) {
        return false;
    }

    g_ready = true;
    return true;
}

bool sd_init(void) {
    static const SdPins board_pins = {spi1, 30, 31, 40, 43};
    static const SdPins spec_pins = {spi0, 34, 35, 36, 39};

    g_ready = false;
    g_sdhc = false;
    g_sectors = 0;
    g_cs = -1;
    memset(ff_block, 0xFF, sizeof(ff_block));

    if (sd_try_pins(&board_pins)) {
        return true;
    }
    spi_deinit(board_pins.spi);

    if (sd_try_pins(&spec_pins)) {
        return true;
    }
    spi_deinit(spec_pins.spi);

    g_cs = -1;
    return false;
}

bool sd_ready(void) {
    return g_ready;
}

uint32_t sd_sector_count(void) {
    return g_sectors;
}

bool sd_read_blocks(uint32_t lba, uint8_t *buffer, uint32_t count) {
    if (!g_ready || buffer == NULL) {
        return false;
    }

    for (uint32_t block = 0; block < count; ++block) {
        cs_select();
        uint32_t addr = g_sdhc ? (lba + block) : ((lba + block) * 512U);
        if (cmd_raw(17, addr) != 0x00) {
            cs_deselect();
            return false;
        }

        uint64_t deadline = time_us_64() + 200000ULL;
        uint8_t token = 0xFF;
        while (time_us_64() < deadline) {
            token = spi_xfer(0xFF);
            if (token == SD_TOKEN_START_BLOCK) break;
        }
        if (token != SD_TOKEN_START_BLOCK) {
            cs_deselect();
            return false;
        }

        spi_write_read_blocking(SD_SPI, ff_block, buffer + block * 512U, 512);
        spi_xfer(0xFF);
        spi_xfer(0xFF);
        cs_deselect();
    }
    return true;
}

bool sd_write_blocks(uint32_t lba, const uint8_t *buffer, uint32_t count) {
    if (!g_ready || buffer == NULL) {
        return false;
    }

    for (uint32_t block = 0; block < count; ++block) {
        cs_select();
        uint32_t addr = g_sdhc ? (lba + block) : ((lba + block) * 512U);
        if (cmd_raw(24, addr) != 0x00) {
            cs_deselect();
            return false;
        }
        if (!wait_ready(500)) {
            cs_deselect();
            return false;
        }

        spi_xfer(SD_TOKEN_START_BLOCK);
        spi_write_blocking(SD_SPI, buffer + block * 512U, 512);
        spi_xfer(0xFF);
        spi_xfer(0xFF);

        uint8_t response = spi_xfer(0xFF);
        if ((response & 0x1F) != 0x05) {
            cs_deselect();
            return false;
        }

        if (!wait_ready(500)) {
            cs_deselect();
            return false;
        }
        cs_deselect();
        sleep_ms(1);
    }
    return true;
}
