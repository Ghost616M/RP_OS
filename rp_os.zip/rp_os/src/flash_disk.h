#ifndef RP_OS_FLASH_DISK_H
#define RP_OS_FLASH_DISK_H

#include <stdbool.h>
#include <stdint.h>

#define FLASH_FS_SIZE (1024U * 1024U)
#define FLASH_FS_OFFSET (PICO_FLASH_SIZE_BYTES - FLASH_FS_SIZE)
#define FLASH_FS_SECTOR_SIZE 512U
#define FLASH_FS_SECTOR_COUNT (FLASH_FS_SIZE / FLASH_FS_SECTOR_SIZE)

void flash_disk_init(void);
bool flash_disk_has_fs(void);
bool flash_disk_read(uint32_t lba, uint8_t *buffer, uint32_t count);
bool flash_disk_write(uint32_t lba, const uint8_t *buffer, uint32_t count);
bool flash_disk_flush(void);
uint32_t flash_disk_sector_count(void);

#endif
