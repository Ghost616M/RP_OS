#include "display.h"

#include <string.h>

#include "common_dvi_pin_configs.h"
#include "dvi.h"
#include "dvi_serialiser.h"
#include "hardware/dma.h"
#include "hardware/irq.h"
#include "hardware/pio.h"
#include "hardware/structs/bus_ctrl.h"
#include "pico/flash.h"
#include "pico/multicore.h"
#include "pico/sem.h"
#include "pico/stdlib.h"
#include "pico/sync.h"

#define FB_COUNT 2

static uint16_t framebuffers[FB_COUNT][DISPLAY_WIDTH * DISPLAY_HEIGHT] __attribute__((aligned(4)));
static struct dvi_inst dvi0;
static struct semaphore dvi_start_sem;

static volatile int front_index;
static volatile int flip_target;
static volatile bool flip_pending;
static volatile uint32_t frame_counter;

static void __not_in_flash_func(display_scanline_callback)(void) {
    static uint scanline;
    uint16_t *ptr;

    if (scanline == 0 && flip_pending) {
        front_index = flip_target;
        flip_pending = false;
        frame_counter++;
        __dmb();
    }

    while (queue_try_remove_u32(&dvi0.q_colour_free, &ptr)) {
    }

    ptr = &framebuffers[front_index][scanline * DISPLAY_WIDTH];
    queue_add_blocking_u32(&dvi0.q_colour_valid, &ptr);

    scanline++;
    if (scanline >= DISPLAY_HEIGHT) {
        scanline = 0;
    }
}

static void display_core1_main(void) {
    flash_safe_execute_core_init();
    dvi_register_irqs_this_core(&dvi0, DMA_IRQ_0);
    sem_acquire_blocking(&dvi_start_sem);
    dvi_start(&dvi0);
    dvi_scanbuf_main_16bpp(&dvi0);
}

bool display_init(void) {
    for (int b = 0; b < FB_COUNT; ++b) {
        for (int i = 0; i < DISPLAY_WIDTH * DISPLAY_HEIGHT; ++i) {
            framebuffers[b][i] = 0;
        }
    }

#if PICO_PIO_USE_GPIO_BASE
    pio_set_gpio_base(pio0, 16);
#endif

    dvi0.timing = &dvi_timing_640x480p_60hz;
    dvi0.ser_cfg = DVI_DEFAULT_SERIAL_CONFIG;
    dvi0.scanline_callback = display_scanline_callback;
    dvi_init(&dvi0, next_striped_spin_lock_num(), next_striped_spin_lock_num());

    for (int scanline = 0; scanline < 2; ++scanline) {
        uint16_t *ptr = &framebuffers[0][scanline * DISPLAY_WIDTH];
        queue_add_blocking_u32(&dvi0.q_colour_valid, &ptr);
    }

    front_index = 0;
    flip_target = 0;
    flip_pending = false;
    frame_counter = 0;

    sem_init(&dvi_start_sem, 0, 1);
    hw_set_bits(&bus_ctrl_hw->priority, BUSCTRL_BUS_PRIORITY_PROC1_BITS);
    multicore_launch_core1(display_core1_main);
    sem_release(&dvi_start_sem);

    return true;
}

uint16_t *display_backbuffer(void) {
    return framebuffers[front_index ^ 1];
}

uint16_t *display_frontbuffer(void) {
    return framebuffers[front_index];
}

void display_present(void) {
    flip_target = front_index ^ 1;
    __dmb();
    flip_pending = true;
    __dmb();

    uint64_t deadline = time_us_64() + 200000ULL;
    while (flip_pending) {
        tight_loop_contents();
        if (time_us_64() > deadline) {
            front_index = flip_target;
            flip_pending = false;
            break;
        }
    }
}

uint32_t display_frame_count(void) {
    return frame_counter;
}
