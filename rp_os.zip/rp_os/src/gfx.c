#include "gfx.h"

#include <string.h>

#include "font_8x8.h"

#define FONT_CHAR_W 8
#define FONT_CHAR_H 8
#define FONT_N_CHARS 95
#define FONT_FIRST_ASCII 32

static uint16_t *fb_target;
static int fb_w;
static int fb_h;
static GfxRect clip_rect;

void gfx_init(uint16_t *buffer, int width, int height) {
    gfx_set_target(buffer, width, height);
}

void gfx_set_target(uint16_t *buffer, int width, int height) {
    fb_target = buffer;
    fb_w = width;
    fb_h = height;
    gfx_reset_clip();
}

void gfx_reset_clip(void) {
    clip_rect.x = 0;
    clip_rect.y = 0;
    clip_rect.w = fb_w;
    clip_rect.h = fb_h;
}

void gfx_set_clip(int x, int y, int w, int h) {
    int x0 = x < 0 ? 0 : x;
    int y0 = y < 0 ? 0 : y;
    int x1 = x + w;
    int y1 = y + h;
    if (x1 > fb_w) x1 = fb_w;
    if (y1 > fb_h) y1 = fb_h;
    if (x1 < x0) x1 = x0;
    if (y1 < y0) y1 = y0;
    clip_rect.x = x0;
    clip_rect.y = y0;
    clip_rect.w = x1 - x0;
    clip_rect.h = y1 - y0;
}

uint16_t *gfx_target(void) {
    return fb_target;
}

void gfx_clear(uint16_t color) {
    if (fb_target == NULL) return;
    for (int i = 0; i < fb_w * fb_h; ++i) {
        fb_target[i] = color;
    }
}

void gfx_pixel(int x, int y, uint16_t color) {
    if (x < clip_rect.x || y < clip_rect.y || x >= clip_rect.x + clip_rect.w || y >= clip_rect.y + clip_rect.h) {
        return;
    }
    fb_target[y * fb_w + x] = color;
}

void gfx_hline(int x, int y, int w, uint16_t color) {
    if (w <= 0) return;
    int x0 = x;
    int x1 = x + w;
    if (x0 < clip_rect.x) x0 = clip_rect.x;
    if (x1 > clip_rect.x + clip_rect.w) x1 = clip_rect.x + clip_rect.w;
    if (y < clip_rect.y || y >= clip_rect.y + clip_rect.h || x1 <= x0) return;
    uint16_t *dst = &fb_target[y * fb_w + x0];
    for (int i = 0; i < x1 - x0; ++i) {
        dst[i] = color;
    }
}

void gfx_vline(int x, int y, int h, uint16_t color) {
    if (h <= 0) return;
    int y0 = y;
    int y1 = y + h;
    if (y0 < clip_rect.y) y0 = clip_rect.y;
    if (y1 > clip_rect.y + clip_rect.h) y1 = clip_rect.y + clip_rect.h;
    if (x < clip_rect.x || x >= clip_rect.x + clip_rect.w || y1 <= y0) return;
    for (int py = y0; py < y1; ++py) {
        fb_target[py * fb_w + x] = color;
    }
}

void gfx_fill(int x, int y, int w, int h, uint16_t color) {
    if (w <= 0 || h <= 0) return;
    int y0 = y;
    int y1 = y + h;
    if (y0 < clip_rect.y) y0 = clip_rect.y;
    if (y1 > clip_rect.y + clip_rect.h) y1 = clip_rect.y + clip_rect.h;
    if (y1 <= y0) return;
    int x0 = x;
    int x1 = x + w;
    if (x0 < clip_rect.x) x0 = clip_rect.x;
    if (x1 > clip_rect.x + clip_rect.w) x1 = clip_rect.x + clip_rect.w;
    if (x1 <= x0) return;
    for (int py = y0; py < y1; ++py) {
        uint16_t *dst = &fb_target[py * fb_w + x0];
        for (int px = 0; px < x1 - x0; ++px) {
            dst[px] = color;
        }
    }
}

void gfx_rect_outline(int x, int y, int w, int h, uint16_t color) {
    if (w <= 0 || h <= 0) return;
    gfx_hline(x, y, w, color);
    gfx_hline(x, y + h - 1, w, color);
    gfx_vline(x, y, h, color);
    gfx_vline(x + w - 1, y, h, color);
}

void gfx_line(int x0, int y0, int x1, int y1, uint16_t color) {
    int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    int sx = x0 < x1 ? 1 : -1;
    int dy = y1 > y0 ? y0 - y1 : y1 - y0;
    int sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;

    while (true) {
        gfx_pixel(x0, y0, color);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) {
            err += dy;
            x0 += sx;
        }
        if (e2 <= dx) {
            err += dx;
            y0 += sy;
        }
    }
}

static void gfx_glyph(int x, int y, char ch, uint16_t fg, uint16_t bg, bool opaque) {
    if (ch < FONT_FIRST_ASCII || ch >= FONT_FIRST_ASCII + FONT_N_CHARS) {
        ch = '?';
    }
    int glyph = ch - FONT_FIRST_ASCII;

    if (x + FONT_CHAR_W <= clip_rect.x || x >= clip_rect.x + clip_rect.w ||
        y + FONT_CHAR_H <= clip_rect.y || y >= clip_rect.y + clip_rect.h) {
        return;
    }

    for (int row = 0; row < FONT_CHAR_H; ++row) {
        uint8_t bits = (uint8_t)font_8x8[glyph + row * FONT_N_CHARS];
        int py = y + row;
        if (py < clip_rect.y || py >= clip_rect.y + clip_rect.h) {
            continue;
        }
        for (int col = 0; col < FONT_CHAR_W; ++col) {
            int px = x + col;
            if (px < clip_rect.x || px >= clip_rect.x + clip_rect.w) {
                continue;
            }
            bool on = (bits & (1U << col)) != 0;
            if (on) {
                fb_target[py * fb_w + px] = fg;
            } else if (opaque) {
                fb_target[py * fb_w + px] = bg;
            }
        }
    }
}

void gfx_char(int x, int y, char ch, uint16_t fg, uint16_t bg, bool opaque) {
    gfx_glyph(x, y, ch, fg, bg, opaque);
}

void gfx_text(int x, int y, const char *text, uint16_t fg, uint16_t bg, bool opaque) {
    if (text == NULL) return;
    while (*text) {
        gfx_glyph(x, y, *text++, fg, bg, opaque);
        x += FONT_CHAR_W;
    }
}

void gfx_text_clip(int x, int y, int max_width, const char *text, uint16_t fg, uint16_t bg, bool opaque) {
    if (text == NULL) return;
    int limit = x + max_width;
    while (*text && x + FONT_CHAR_W <= limit) {
        gfx_glyph(x, y, *text++, fg, bg, opaque);
        x += FONT_CHAR_W;
    }
}

void gfx_text_right(int x_right, int y, const char *text, uint16_t fg, uint16_t bg, bool opaque) {
    int w = gfx_text_width(text);
    gfx_text(x_right - w, y, text, fg, bg, opaque);
}

int gfx_text_width(const char *text) {
    if (text == NULL) return 0;
    return (int)strlen(text) * FONT_CHAR_W;
}
