#include "theme.h"

#include <string.h>

#include "gfx.h"

static const ThemePalette palette_blue = {
    .bg = RGB565(16, 18, 26),
    .bg_band = RGB565(21, 24, 34),
    .bg_glow = RGB565(28, 34, 50),
    .panel = RGB565(30, 34, 46),
    .panel_alt = RGB565(36, 41, 56),
    .panel_hi = RGB565(46, 53, 72),
    .border = RGB565(62, 70, 92),
    .border_hi = RGB565(90, 102, 132),
    .text = RGB565(228, 233, 244),
    .text_dim = RGB565(148, 157, 178),
    .text_faint = RGB565(100, 109, 130),
    .accent = RGB565(84, 158, 255),
    .accent_dark = RGB565(38, 78, 140),
    .accent2 = RGB565(96, 220, 180),
    .warn = RGB565(255, 190, 80),
    .err = RGB565(255, 96, 96),
    .ok = RGB565(110, 220, 130),
    .taskbar = RGB565(20, 23, 32),
    .taskbar_hi = RGB565(32, 38, 52),
    .title = RGB565(38, 44, 60),
    .title_focus = RGB565(40, 66, 108),
    .sel = RGB565(42, 78, 130),
    .sel_soft = RGB565(34, 52, 78),
    .shadow = RGB565(8, 9, 14),
    .desk_icon_bg = RGB565(25, 29, 40),
    .desk_icon_sel = RGB565(36, 46, 66),
    .term_bg = RGB565(12, 13, 18),
    .term_green = RGB565(130, 230, 150),
    .term_cyan = RGB565(110, 210, 240),
    .term_yellow = RGB565(240, 210, 120),
    .term_red = RGB565(250, 110, 110),
    .term_dim = RGB565(130, 138, 158),
};

static const ThemePalette palette_cyber = {
    .bg = RGB565(8, 6, 18),
    .bg_band = RGB565(14, 10, 28),
    .bg_glow = RGB565(24, 14, 44),
    .panel = RGB565(20, 14, 36),
    .panel_alt = RGB565(28, 20, 48),
    .panel_hi = RGB565(40, 28, 64),
    .border = RGB565(60, 40, 90),
    .border_hi = RGB565(100, 70, 140),
    .text = RGB565(235, 225, 255),
    .text_dim = RGB565(160, 145, 190),
    .text_faint = RGB565(110, 95, 140),
    .accent = RGB565(0, 220, 255),
    .accent_dark = RGB565(0, 90, 120),
    .accent2 = RGB565(255, 60, 200),
    .warn = RGB565(255, 200, 60),
    .err = RGB565(255, 70, 90),
    .ok = RGB565(90, 255, 170),
    .taskbar = RGB565(10, 8, 20),
    .taskbar_hi = RGB565(26, 18, 44),
    .title = RGB565(30, 20, 50),
    .title_focus = RGB565(0, 70, 100),
    .sel = RGB565(20, 90, 120),
    .sel_soft = RGB565(26, 44, 66),
    .shadow = RGB565(2, 1, 8),
    .desk_icon_bg = RGB565(16, 12, 28),
    .desk_icon_sel = RGB565(30, 40, 70),
    .term_bg = RGB565(4, 3, 10),
    .term_green = RGB565(0, 255, 180),
    .term_cyan = RGB565(0, 220, 255),
    .term_yellow = RGB565(255, 200, 60),
    .term_red = RGB565(255, 70, 90),
    .term_dim = RGB565(120, 100, 150),
};

static const ThemePalette palette_matrix = {
    .bg = RGB565(2, 8, 2),
    .bg_band = RGB565(4, 16, 6),
    .bg_glow = RGB565(8, 30, 10),
    .panel = RGB565(6, 20, 8),
    .panel_alt = RGB565(10, 30, 12),
    .panel_hi = RGB565(16, 44, 18),
    .border = RGB565(30, 80, 34),
    .border_hi = RGB565(60, 150, 66),
    .text = RGB565(150, 255, 160),
    .text_dim = RGB565(90, 180, 96),
    .text_faint = RGB565(60, 120, 64),
    .accent = RGB565(80, 255, 100),
    .accent_dark = RGB565(20, 100, 30),
    .accent2 = RGB565(180, 255, 120),
    .warn = RGB565(240, 240, 80),
    .err = RGB565(255, 90, 70),
    .ok = RGB565(100, 255, 120),
    .taskbar = RGB565(3, 12, 4),
    .taskbar_hi = RGB565(10, 35, 12),
    .title = RGB565(8, 28, 10),
    .title_focus = RGB565(20, 70, 24),
    .sel = RGB565(20, 80, 26),
    .sel_soft = RGB565(14, 44, 16),
    .shadow = RGB565(0, 0, 0),
    .desk_icon_bg = RGB565(4, 14, 6),
    .desk_icon_sel = RGB565(14, 50, 18),
    .term_bg = RGB565(1, 5, 1),
    .term_green = RGB565(100, 255, 120),
    .term_cyan = RGB565(120, 255, 200),
    .term_yellow = RGB565(220, 255, 100),
    .term_red = RGB565(255, 120, 90),
    .term_dim = RGB565(70, 140, 74),
};

static const ThemePalette palette_retro = {
    .bg = RGB565(150, 150, 145),
    .bg_band = RGB565(166, 166, 160),
    .bg_glow = RGB565(130, 130, 126),
    .panel = RGB565(190, 190, 184),
    .panel_alt = RGB565(178, 178, 172),
    .panel_hi = RGB565(205, 205, 198),
    .border = RGB565(90, 90, 86),
    .border_hi = RGB565(60, 60, 58),
    .text = RGB565(24, 24, 26),
    .text_dim = RGB565(60, 60, 64),
    .text_faint = RGB565(95, 95, 98),
    .accent = RGB565(40, 80, 160),
    .accent_dark = RGB565(25, 45, 90),
    .accent2 = RGB565(20, 120, 100),
    .warn = RGB565(170, 100, 0),
    .err = RGB565(180, 30, 30),
    .ok = RGB565(20, 120, 50),
    .taskbar = RGB565(120, 120, 116),
    .taskbar_hi = RGB565(150, 150, 146),
    .title = RGB565(170, 170, 164),
    .title_focus = RGB565(70, 95, 140),
    .sel = RGB565(100, 130, 180),
    .sel_soft = RGB565(140, 150, 165),
    .shadow = RGB565(40, 40, 40),
    .desk_icon_bg = RGB565(160, 160, 154),
    .desk_icon_sel = RGB565(180, 180, 174),
    .term_bg = RGB565(30, 30, 32),
    .term_green = RGB565(150, 230, 160),
    .term_cyan = RGB565(140, 210, 210),
    .term_yellow = RGB565(230, 210, 130),
    .term_red = RGB565(230, 120, 120),
    .term_dim = RGB565(160, 160, 160),
};

ThemePalette g_theme;

static ThemeId current_theme = THEME_BLUE_CLASSIC;

void theme_init(void) {
    theme_set(THEME_BLUE_CLASSIC);
}

void theme_set(ThemeId id) {
    if (id >= THEME_COUNT) {
        id = THEME_BLUE_CLASSIC;
    }
    current_theme = id;
    switch (id) {
        case THEME_DARK_CYBER:
            g_theme = palette_cyber;
            break;
        case THEME_MATRIX:
            g_theme = palette_matrix;
            break;
        case THEME_RETRO:
            g_theme = palette_retro;
            break;
        case THEME_BLUE_CLASSIC:
        default:
            g_theme = palette_blue;
            break;
    }
}

ThemeId theme_get(void) {
    return current_theme;
}

const char *theme_name(ThemeId id) {
    switch (id) {
        case THEME_DARK_CYBER:
            return "Dark Cyber";
        case THEME_MATRIX:
            return "Matrix Verde";
        case THEME_RETRO:
            return "Cinza Retro";
        case THEME_BLUE_CLASSIC:
        default:
            return "Azul Classico";
    }
}
