#include "shell.h"

#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "board.h"
#include "hw.h"
#include "storage.h"
#include "usb_host.h"
#include "net_stack.h"

#define MAX_ARGS 10
#define ARG_LEN 64

static void sh_write(Shell *shell, const char *fmt, ...) {
    char buffer[256];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);
    if (shell->write != NULL) {
        shell->write(shell->ctx, buffer);
    }
}

void shell_init(Shell *shell, ShellWriteFn write, void *ctx) {
    memset(shell, 0, sizeof(*shell));
    shell->write = write;
    shell->ctx = ctx;
    snprintf(shell->cwd, sizeof(shell->cwd), "%s",
             storage_mounted(VFS_FLASH) ? "/flash" : "/");
}

void shell_set_cwd(Shell *shell, const char *path) {
    if (path != NULL) {
        snprintf(shell->cwd, sizeof(shell->cwd), "%.127s", path);
    }
}

void shell_prompt(Shell *shell, char *out, size_t out_size) {
    char short_path[48];
    const char *cwd = shell->cwd;

    if (strcmp(cwd, "/") == 0) {
        snprintf(short_path, sizeof(short_path), "/");
    } else if (strncmp(cwd, "/flash", 6) == 0 && (cwd[6] == '\0' || cwd[6] == '/')) {
        snprintf(short_path, sizeof(short_path), "~%s", cwd + 6);
    } else {
        snprintf(short_path, sizeof(short_path), "%.47s", cwd);
    }

    if (strlen(short_path) > 22) {
        char tail[24];
        snprintf(tail, sizeof(tail), "..%s", short_path + strlen(short_path) - 18);
        snprintf(short_path, sizeof(short_path), "%s", tail);
    }

    snprintf(out, out_size, "rp_os:%s$ ", short_path);
}

static int tokenize(const char *line, char args[][ARG_LEN], char *argv[], int max_args) {
    int argc = 0;
    const char *p = line;

    while (*p && argc < max_args) {
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\0') break;

        char quote = 0;
        size_t n = 0;
        char *out = args[argc];

        while (*p) {
            if (quote != 0) {
                if (*p == quote) {
                    quote = 0;
                    p++;
                } else {
                    if (n + 1 < ARG_LEN) out[n++] = *p;
                    p++;
                }
            } else if (*p == '"' || *p == '\'') {
                quote = *p++;
            } else if (*p == ' ' || *p == '\t') {
                break;
            } else {
                if (n + 1 < ARG_LEN) out[n++] = *p;
                p++;
            }
        }
        out[n] = '\0';
        argv[argc++] = out;
    }
    return argc;
}

static void format_size(uint32_t kb, char *out, size_t out_size) {
    if (kb < 1024U) {
        snprintf(out, out_size, "%luK", (unsigned long)kb);
    } else if (kb < 1024U * 1024U) {
        snprintf(out, out_size, "%.1fM", (double)kb / 1024.0);
    } else {
        snprintf(out, out_size, "%.2fG", (double)kb / (1024.0 * 1024.0));
    }
}

static void format_uptime(uint32_t seconds, char *out, size_t out_size) {
    uint32_t days = seconds / 86400U;
    uint32_t hours = (seconds / 3600U) % 24U;
    uint32_t mins = (seconds / 60U) % 60U;
    uint32_t secs = seconds % 60U;
    snprintf(out, out_size, "%lud %02lu:%02lu:%02lu",
             (unsigned long)days, (unsigned long)hours, (unsigned long)mins, (unsigned long)secs);
}

static bool resolve(Shell *shell, const char *arg, char *out, size_t out_size) {
    return vfs_normalize(shell->cwd, arg, out, out_size);
}

static bool is_protected_path(const char *path) {
    return strcmp(path, "/") == 0 || strcmp(path, "/flash") == 0 ||
           strcmp(path, "/sd") == 0 || strcmp(path, "/usb") == 0;
}

static void cmd_help(Shell *shell) {
    sh_write(shell,
             "rp_os shell - comandos\n"
             " help clear pwd cd ls cat\n"
             " mkdir rm cp mv touch echo\n"
             " df mount lsusb sysinfo free\n"
             " gpio i2cscan date uname\n"
             " ifconfig ping wifi\n"
             " reboot bootsel\n"
             "gpio help para detalhes.\n");
}

static void cmd_clear(Shell *shell) {
    if (shell->write != NULL) {
        shell->write(shell->ctx, "\f");
    }
}

static void cmd_pwd(Shell *shell) {
    sh_write(shell, "%s\n", shell->cwd);
}

static void cmd_cd(Shell *shell, int argc, char **argv) {
    const char *target = argc > 1 ? argv[1] : NULL;
    if (target == NULL) {
        target = storage_mounted(VFS_FLASH) ? "/flash" : "/";
    }

    char path[200];
    if (!resolve(shell, target, path, sizeof(path))) {
        sh_write(shell, "cd: caminho invalido\n");
        return;
    }
    if (!vfs_is_dir(path)) {
        sh_write(shell, "cd: nao e um diretorio: %s\n", path);
        return;
    }
    snprintf(shell->cwd, sizeof(shell->cwd), "%.127s", path);
}

static void cmd_ls(Shell *shell, int argc, char **argv) {
    char path[200];
    if (!resolve(shell, argc > 1 ? argv[1] : NULL, path, sizeof(path))) {
        sh_write(shell, "ls: caminho invalido\n");
        return;
    }

    VfsEntry entry;
    if (!vfs_stat(path, &entry)) {
        sh_write(shell, "ls: nao encontrado: %s\n", path);
        return;
    }

    if (!entry.is_dir) {
        char size[12];
        format_size(entry.size / 1024U, size, sizeof(size));
        sh_write(shell, "- %8s %s\n", size, entry.name);
        return;
    }

    static VfsEntry entries[48];
    int count = vfs_list(path, entries, 48);
    if (count < 0) {
        sh_write(shell, "ls: nao foi possivel abrir: %s\n", path);
        return;
    }
    if (count == 0) {
        sh_write(shell, "(vazio)\n");
        return;
    }

    for (int i = 0; i < count; ++i) {
        if (entries[i].is_dir) {
            sh_write(shell, "d %8s %s/\n", "<DIR>", entries[i].name);
        } else {
            char size[12];
            format_size(entries[i].size / 1024U, size, sizeof(size));
            sh_write(shell, "- %8s %s\n", size, entries[i].name);
        }
    }
}

static void cmd_cat(Shell *shell, int argc, char **argv) {
    if (argc < 2) {
        sh_write(shell, "uso: cat <arquivo>\n");
        return;
    }

    char path[200];
    if (!resolve(shell, argv[1], path, sizeof(path))) {
        sh_write(shell, "cat: caminho invalido\n");
        return;
    }

    static char content[2048];
    size_t got = 0;
    if (!vfs_read_file(path, content, sizeof(content), &got)) {
        sh_write(shell, "cat: nao foi possivel ler: %s\n", path);
        return;
    }
    if (got == sizeof(content) - 1) {
        sh_write(shell, "(cat: arquivo truncado)\n");
    }
    if (shell->write != NULL) {
        shell->write(shell->ctx, content);
    }
    if (got > 0 && content[got - 1] != '\n') {
        sh_write(shell, "\n");
    }
}

static void cmd_mkdir(Shell *shell, int argc, char **argv) {
    if (argc < 2) {
        sh_write(shell, "uso: mkdir <pasta>\n");
        return;
    }
    char path[200];
    resolve(shell, argv[1], path, sizeof(path));
    if (!vfs_mkdir(path)) {
        sh_write(shell, "mkdir: falhou: %s\n", path);
    }
}

static void cmd_rm(Shell *shell, int argc, char **argv) {
    bool recursive = false;
    int index = 1;
    if (argc > 1 && (strcmp(argv[1], "-r") == 0 || strcmp(argv[1], "-rf") == 0)) {
        recursive = true;
        index = 2;
    }
    if (argc <= index) {
        sh_write(shell, "uso: rm [-r] <alvo>\n");
        return;
    }

    char path[200];
    resolve(shell, argv[index], path, sizeof(path));
    if (is_protected_path(path)) {
        sh_write(shell, "rm: caminho protegido\n");
        return;
    }

    if (vfs_is_dir(path)) {
        if (!recursive) {
            sh_write(shell, "rm: %s e um diretorio (use -r)\n", path);
            return;
        }
        if (!vfs_remove_recursive(path)) {
            sh_write(shell, "rm: falhou: %s\n", path);
        }
        return;
    }

    if (!vfs_remove(path)) {
        sh_write(shell, "rm: falhou: %s\n", path);
    }
}

static void join_destination(const char *dst, const char *src, char *out, size_t out_size) {
    VfsEntry entry;
    if (vfs_stat(dst, &entry) && entry.is_dir) {
        char base[64];
        vfs_basename(src, base, sizeof(base));
        size_t len = strlen(dst);
        snprintf(out, out_size, "%s%s%s", dst, len > 0 && dst[len - 1] == '/' ? "" : "/", base);
    } else {
        snprintf(out, out_size, "%s", dst);
    }
}

static void cmd_cp(Shell *shell, int argc, char **argv) {
    if (argc < 3) {
        sh_write(shell, "uso: cp <origem> <destino>\n");
        return;
    }

    char from[200];
    char to[200];
    char final[220];
    resolve(shell, argv[1], from, sizeof(from));
    resolve(shell, argv[2], to, sizeof(to));
    join_destination(to, from, final, sizeof(final));

    if (!vfs_copy_file(from, final)) {
        sh_write(shell, "cp: falhou\n");
    }
}

static void cmd_mv(Shell *shell, int argc, char **argv) {
    if (argc < 3) {
        sh_write(shell, "uso: mv <origem> <destino>\n");
        return;
    }

    char from[200];
    char to[200];
    char final[220];
    resolve(shell, argv[1], from, sizeof(from));
    resolve(shell, argv[2], to, sizeof(to));
    join_destination(to, from, final, sizeof(final));

    if (vfs_rename(from, final)) {
        return;
    }
    if (vfs_copy_file(from, final) && vfs_remove(from)) {
        return;
    }
    sh_write(shell, "mv: falhou\n");
}

static void cmd_touch(Shell *shell, int argc, char **argv) {
    if (argc < 2) {
        sh_write(shell, "uso: touch <arquivo>\n");
        return;
    }
    char path[200];
    resolve(shell, argv[1], path, sizeof(path));
    if (vfs_exists(path)) {
        return;
    }
    if (!vfs_write_file(path, "", 0)) {
        sh_write(shell, "touch: falhou: %s\n", path);
    }
}

static void cmd_df(Shell *shell) {
    sh_write(shell, "FS    Total   Livre  Uso\n");
    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        VfsDrive drive = (VfsDrive)i;
        const char *name = i == VFS_FLASH ? "flash" : (i == VFS_SD ? "sd" : "usb");
        uint32_t total = 0;
        uint32_t free_kb = 0;
        if (!vfs_df(drive, &total, &free_kb)) {
            sh_write(shell, "%-5s %7s\n", name, "off");
            continue;
        }
        char total_str[12];
        char free_str[12];
        format_size(total, total_str, sizeof(total_str));
        format_size(free_kb, free_str, sizeof(free_str));
        unsigned use = 0;
        if (total > 0) {
            uint32_t used = free_kb < total ? total - free_kb : 0;
            use = (unsigned)(used * 100U / total);
        }
        sh_write(shell, "%-5s %7s %7s %3u%%\n", name, total_str, free_str, use);
    }
}

static void cmd_mount(Shell *shell) {
    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        sh_write(shell, "%-6s %-6s %s\n", storage_drive_name((VfsDrive)i),
                 storage_mount_path((VfsDrive)i), storage_drive_status((VfsDrive)i));
    }
}

static void cmd_lsusb(Shell *shell) {
    UsbDeviceInfo devices[8];
    int count = usb_devices(devices, 8);
    if (count == 0) {
        sh_write(shell, "Nenhum dispositivo USB.\n");
        return;
    }

    for (int i = 0; i < count; ++i) {
        const char *kind = "dispositivo";
        if (devices[i].kind & USB_KIND_KEYBOARD) kind = "teclado";
        else if (devices[i].kind & USB_KIND_MOUSE) kind = "mouse";
        else if (devices[i].kind & USB_KIND_MSC) kind = "pendrive";
        sh_write(shell, "1-%u %04x:%04x %s\n", devices[i].addr,
                 devices[i].vid, devices[i].pid, kind);
    }
}

static void cmd_sysinfo(Shell *shell) {
    char uptime[24];
    format_uptime(board_uptime_s(), uptime, sizeof(uptime));
    char temp[16];
    snprintf(temp, sizeof(temp), "%.1f C", (double)board_temp_c());

    sh_write(shell, "rp_os v%s\n", board_version());
    sh_write(shell, "Placa: %s\n", board_name());
    sh_write(shell, "CPU: %lu MHz x2\n", (unsigned long)board_cpu_mhz());
    sh_write(shell, "RAM livre: %lu KB\n", (unsigned long)(board_heap_free() / 1024U));
    sh_write(shell, "Temp: %s\n", temp);
    sh_write(shell, "Uptime: %s\n", uptime);
    sh_write(shell, "USB: kbd %u mouse %u\n", usb_keyboard_count(), usb_mouse_count());
    sh_write(shell, "Flash %s | SD %s | USB %s\n",
             storage_mounted(VFS_FLASH) ? "on" : "off",
             storage_mounted(VFS_SD) ? "on" : "off",
             storage_mounted(VFS_USB) ? "on" : "off");
}

static void cmd_gpio(Shell *shell, int argc, char **argv) {
    if (argc < 2 || strcmp(argv[1], "list") == 0) {
        for (int pin = 0; pin < HW_PIN_COUNT; pin += 2) {
            for (int c = 0; c < 2; ++c) {
                int p = pin + c;
                if (p >= HW_PIN_COUNT) break;
                sh_write(shell, "P%02d %-3s %d  ", p, hw_mode_name(hw_pin_mode(p)),
                         hw_pin_get(p) ? 1 : 0);
            }
            sh_write(shell, "\n");
        }
        return;
    }

    if (strcmp(argv[1], "help") == 0) {
        sh_write(shell,
                 "gpio list\n"
                 "gpio read <pino>\n"
                 "gpio mode <pino> in|out\n"
                 "gpio write <pino> 0|1\n"
                 "gpio pwm <pino> <hz> <duty>\n"
                 "gpio pwmoff <pino>\n");
        return;
    }

    if (argc < 3) {
        sh_write(shell, "gpio: falta o pino\n");
        return;
    }

    int pin = (int)strtol(argv[2], NULL, 0);
    if (!hw_pin_valid(pin)) {
        sh_write(shell, "gpio: pino invalido\n");
        return;
    }

    if (strcmp(argv[1], "read") == 0) {
        sh_write(shell, "GPIO%d = %d\n", pin, hw_pin_get(pin) ? 1 : 0);
    } else if (strcmp(argv[1], "mode") == 0) {
        if (argc < 4) {
            sh_write(shell, "gpio mode <pino> in|out\n");
            return;
        }
        if (strcmp(argv[3], "in") == 0) {
            hw_pin_set_mode(pin, HW_MODE_INPUT);
        } else if (strcmp(argv[3], "out") == 0) {
            hw_pin_set_mode(pin, HW_MODE_OUTPUT);
        } else {
            sh_write(shell, "gpio: modo invalido\n");
        }
    } else if (strcmp(argv[1], "write") == 0) {
        if (argc < 4) {
            sh_write(shell, "gpio write <pino> 0|1\n");
            return;
        }
        hw_pin_write(pin, strcmp(argv[3], "0") != 0);
    } else if (strcmp(argv[1], "pwm") == 0) {
        if (argc < 5) {
            sh_write(shell, "gpio pwm <pino> <hz> <duty>\n");
            return;
        }
        int freq = (int)strtol(argv[3], NULL, 0);
        int duty = (int)strtol(argv[4], NULL, 0);
        hw_pin_pwm(pin, (uint32_t)freq, (uint8_t)duty);
        sh_write(shell, "PWM GPIO%d %d Hz %d%%\n", pin, freq, duty);
    } else if (strcmp(argv[1], "pwmoff") == 0) {
        hw_pin_pwm_off(pin);
    } else {
        sh_write(shell, "gpio: subcomando desconhecido\n");
    }
}

static void cmd_i2cscan(Shell *shell, int argc, char **argv) {
    int sda = argc > 1 ? (int)strtol(argv[1], NULL, 0) : 6;
    int scl = argc > 2 ? (int)strtol(argv[2], NULL, 0) : 7;
    uint8_t found[16];
    int count = hw_i2c_scan((uint8_t)sda, (uint8_t)scl, found, 16);

    if (count == 0) {
        sh_write(shell, "I2C %d/%d: nenhum dispositivo\n", sda, scl);
        return;
    }

    sh_write(shell, "I2C %d/%d: %d dispositivo(s)\n", sda, scl, count);
    for (int i = 0; i < count && i < 16; ++i) {
        sh_write(shell, " 0x%02X", found[i]);
    }
    sh_write(shell, "\n");
}

static void cmd_reboot(Shell *shell, bool bootsel) {
    sh_write(shell, bootsel ? "entrando em BOOTSEL...\n" : "reiniciando...\n");
    board_schedule_reset(400, bootsel);
}

static void cmd_echo(Shell *shell, int argc, char **argv) {
    for (int i = 1; i < argc; ++i) {
        sh_write(shell, "%s%s", i > 1 ? " " : "", argv[i]);
    }
    sh_write(shell, "\n");
}

static void cmd_free(Shell *shell) {
    sh_write(shell, "RAM livre: %lu bytes\n", (unsigned long)board_heap_free());
}

static void cmd_uname(Shell *shell) {
    sh_write(shell, "rp_os %s armv8m\n", board_version());
}

static void cmd_ifconfig(Shell *shell) {
    NetStatus st;
    net_status_get(&st);
    sh_write(shell, "ecm0  link:%s  mac:%02X:%02X:%02X:%02X:%02X:%02X\n",
             st.link_up ? "up" : "down",
             st.mac[0], st.mac[1], st.mac[2], st.mac[3], st.mac[4], st.mac[5]);
    sh_write(shell, "      ip:%s  mask:%s  gw:%s\n", st.ip, st.mask, st.gw);
    sh_write(shell, "      dhcp:%s  rx:%lu  tx:%lu\n",
             st.dhcp_bound ? "bound" : (st.dhcp_running ? "running" : "stopped"),
             (unsigned long)st.rx_frames, (unsigned long)st.tx_frames);
    if (st.wifi_present) {
        sh_write(shell, "wlan0 usb:%04X:%04X  fw:%s\n",
                 st.wifi_vid, st.wifi_pid, st.wifi_status);
    } else {
        sh_write(shell, "wlan0 indisponivel (adaptador Atheros nao encontrado)\n");
    }
}

static void cmd_ping(Shell *shell, int argc, char **argv) {
    if (argc < 2) {
        sh_write(shell, "uso: ping <ip> [repeticoes]\n");
        return;
    }
    int count = 4;
    if (argc >= 3) {
        count = atoi(argv[2]);
        if (count < 1) count = 1;
        if (count > 10) count = 10;
    }
    char out[512];
    net_ping(argv[1], count, out, sizeof(out));
    sh_write(shell, "%s", out);
}

static void cmd_wifi(Shell *shell, int argc, char **argv) {
    if (argc >= 2 && strcmp(argv[1], "load") == 0) {
        char out[160];
        bool ok = net_wifi_load_firmware(out, sizeof(out));
        sh_write(shell, "%s\n", out);
        if (ok) {
            sh_write(shell, "aviso: firmware validado, upload USB ainda nao implementado\n");
        }
        return;
    }
    NetStatus st;
    net_status_get(&st);
    if (st.wifi_present) {
        sh_write(shell, "Atheros %04X:%04X presente\n", st.wifi_vid, st.wifi_pid);
    } else {
        sh_write(shell, "nenhum adaptador Atheros USB detectado\n");
    }
    sh_write(shell, "firmware: %s\n", st.wifi_status);
    sh_write(shell, "uso: wifi load (le /sd/firmware/ath9k.fw)\n");
}

static void cmd_date(Shell *shell) {
    char uptime[24];
    format_uptime(board_uptime_s(), uptime, sizeof(uptime));
    sh_write(shell, "uptime %s\n", uptime);
}

void shell_execute(Shell *shell, const char *line) {
    char args[MAX_ARGS][ARG_LEN];
    char *argv[MAX_ARGS];
    int argc = tokenize(line, args, argv, MAX_ARGS);
    if (argc == 0) {
        return;
    }

    const char *cmd = argv[0];
    if (strcmp(cmd, "help") == 0) {
        cmd_help(shell);
    } else if (strcmp(cmd, "clear") == 0) {
        cmd_clear(shell);
    } else if (strcmp(cmd, "pwd") == 0) {
        cmd_pwd(shell);
    } else if (strcmp(cmd, "cd") == 0) {
        cmd_cd(shell, argc, argv);
    } else if (strcmp(cmd, "ls") == 0 || strcmp(cmd, "dir") == 0) {
        cmd_ls(shell, argc, argv);
    } else if (strcmp(cmd, "cat") == 0) {
        cmd_cat(shell, argc, argv);
    } else if (strcmp(cmd, "mkdir") == 0) {
        cmd_mkdir(shell, argc, argv);
    } else if (strcmp(cmd, "rm") == 0) {
        cmd_rm(shell, argc, argv);
    } else if (strcmp(cmd, "cp") == 0) {
        cmd_cp(shell, argc, argv);
    } else if (strcmp(cmd, "mv") == 0) {
        cmd_mv(shell, argc, argv);
    } else if (strcmp(cmd, "touch") == 0) {
        cmd_touch(shell, argc, argv);
    } else if (strcmp(cmd, "df") == 0) {
        cmd_df(shell);
    } else if (strcmp(cmd, "mount") == 0) {
        cmd_mount(shell);
    } else if (strcmp(cmd, "lsusb") == 0) {
        cmd_lsusb(shell);
    } else if (strcmp(cmd, "sysinfo") == 0) {
        cmd_sysinfo(shell);
    } else if (strcmp(cmd, "gpio") == 0) {
        cmd_gpio(shell, argc, argv);
    } else if (strcmp(cmd, "i2cscan") == 0) {
        cmd_i2cscan(shell, argc, argv);
    } else if (strcmp(cmd, "reboot") == 0) {
        cmd_reboot(shell, false);
    } else if (strcmp(cmd, "bootsel") == 0) {
        cmd_reboot(shell, true);
    } else if (strcmp(cmd, "echo") == 0) {
        cmd_echo(shell, argc, argv);
    } else if (strcmp(cmd, "free") == 0) {
        cmd_free(shell);
    } else if (strcmp(cmd, "uname") == 0) {
        cmd_uname(shell);
    } else if (strcmp(cmd, "date") == 0) {
        cmd_date(shell);
    } else if (strcmp(cmd, "ifconfig") == 0) {
        cmd_ifconfig(shell);
    } else if (strcmp(cmd, "ping") == 0) {
        cmd_ping(shell, argc, argv);
    } else if (strcmp(cmd, "wifi") == 0) {
        cmd_wifi(shell, argc, argv);
    } else {
        sh_write(shell, "%s: comando nao encontrado\n", cmd);
    }
}
