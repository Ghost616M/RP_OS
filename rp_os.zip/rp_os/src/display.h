#ifndef RP_OS_DISPLAY_H
#define RP_OS_DISPLAY_H

#include <stdbool.h>
#include <stdint.h>

#define DISPLAY_WIDTH 320
#define DISPLAY_HEIGHT 240

bool display_init(void);
uint16_t *display_backbuffer(void);
uint16_t *display_frontbuffer(void);
void display_present(void);
uint32_t display_frame_count(void);

#endif
