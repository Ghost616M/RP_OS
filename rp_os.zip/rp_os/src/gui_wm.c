#include "app.h"

#include <stdio.h>
#include <string.h>

#include "theme.h"

#define DESKTOP_W 320
#define DESKTOP_H (240 - WM_TASKBAR_H)

static GuiWindow windows[WM_MAX_WINDOWS];
static GuiWindow *z_order[WM_MAX_WINDOWS];
static int z_count;

#define MIN_WINDOW_W 128
#define MIN_WINDOW_H 64

static void clamp_window(GuiWindow *w) {
    if (w->w < MIN_WINDOW_W) w->w = MIN_WINDOW_W;
    if (w->h < MIN_WINDOW_H) w->h = MIN_WINDOW_H;
    if (w->w > DESKTOP_W) w->w = DESKTOP_W;
    if (w->h > DESKTOP_H) w->h = DESKTOP_H;

    if (w->x > DESKTOP_W - w->w) w->x = DESKTOP_W - w->w;
    if (w->y > DESKTOP_H - w->h) w->y = DESKTOP_H - w->h;
    if (w->x < 0) w->x = 0;
    if (w->y < 0) w->y = 0;
}

static void z_remove(GuiWindow *w) {
    for (int i = 0; i < z_count; ++i) {
        if (z_order[i] == w) {
            for (int j = i; j < z_count - 1; ++j) {
                z_order[j] = z_order[j + 1];
            }
            z_count--;
            return;
        }
    }
}

static void z_add(GuiWindow *w) {
    if (z_count >= WM_MAX_WINDOWS) {
        return;
    }
    z_order[z_count++] = w;
}

GuiWindow *gui_wm_find(AppId id) {
    for (int i = 0; i < WM_MAX_WINDOWS; ++i) {
        if (windows[i].open && windows[i].app_id == (int)id) {
            return &windows[i];
        }
    }
    return NULL;
}

GuiWindow *gui_wm_create(AppId id, const char *arg) {
    GuiWindow *existing = gui_wm_find(id);
    if (existing != NULL) {
        const AppOps *ops = app_ops(id);
        gui_wm_restore(existing);
        gui_wm_raise(existing);
        if (ops != NULL && ops->open_arg != NULL && arg != NULL) {
            ops->open_arg(existing, arg);
        }
        return existing;
    }

    const AppOps *ops = app_ops(id);
    if (ops == NULL) {
        return NULL;
    }

    GuiWindow *w = NULL;
    for (int i = 0; i < WM_MAX_WINDOWS; ++i) {
        if (!windows[i].open) {
            w = &windows[i];
            break;
        }
    }
    if (w == NULL) {
        return NULL;
    }

    memset(w, 0, sizeof(*w));
    w->open = true;
    w->minimized = false;
    w->app_id = (int)id;
    snprintf(w->title, sizeof(w->title), "%s", ops->name);
    w->w = ops->width;
    w->h = ops->height;

    int index = gui_wm_open_count();
    w->x = 4 + index * 14;
    w->y = 4 + index * 12;
    clamp_window(w);

    if (ops->create != NULL) {
        ops->create(w, arg);
    }

    z_add(w);
    return w;
}

GuiWindow *app_open(AppId id, const char *arg) {
    return gui_wm_create(id, arg);
}

void gui_wm_focus(GuiWindow *w) {
    if (w == NULL || !w->open) {
        return;
    }
    w->minimized = false;
    z_remove(w);
    z_add(w);
}

void gui_wm_raise(GuiWindow *w) {
    gui_wm_focus(w);
}

void gui_wm_restore(GuiWindow *w) {
    if (w == NULL) {
        return;
    }
    w->minimized = false;
}

void gui_wm_close(GuiWindow *w) {
    if (w == NULL || !w->open) {
        return;
    }
    const AppOps *ops = app_ops((AppId)w->app_id);
    if (ops != NULL && ops->destroy != NULL) {
        ops->destroy(w);
    }
    z_remove(w);
    w->open = false;
    w->minimized = false;
    w->state = NULL;
}

void gui_wm_minimize(GuiWindow *w) {
    if (w == NULL || !w->open) {
        return;
    }
    w->minimized = true;
    z_remove(w);
}

void gui_wm_begin_drag(GuiWindow *w, int mouse_x, int mouse_y) {
    if (w == NULL) {
        return;
    }
    w->dragging = true;
    w->resizing = false;
    w->drag_dx = w->x - mouse_x;
    w->drag_dy = w->y - mouse_y;
    gui_wm_raise(w);
}

void gui_wm_drag_to(GuiWindow *w, int mouse_x, int mouse_y) {
    if (w == NULL || !w->dragging) {
        return;
    }
    w->x = mouse_x + w->drag_dx;
    w->y = mouse_y + w->drag_dy;
    if (w->x > DESKTOP_W - w->w) w->x = DESKTOP_W - w->w;
    if (w->y > DESKTOP_H - w->h) w->y = DESKTOP_H - w->h;
    if (w->x < 0) w->x = 0;
    if (w->y < 0) w->y = 0;
}

void gui_wm_begin_resize(GuiWindow *w, int mouse_x, int mouse_y) {
    if (w == NULL) {
        return;
    }
    w->resizing = true;
    w->dragging = false;
    w->drag_dx = (w->x + w->w) - mouse_x;
    w->drag_dy = (w->y + w->h) - mouse_y;
    gui_wm_raise(w);
}

void gui_wm_resize_to(GuiWindow *w, int mouse_x, int mouse_y) {
    if (w == NULL || !w->resizing) {
        return;
    }
    w->w = mouse_x + w->drag_dx - w->x;
    w->h = mouse_y + w->drag_dy - w->y;
    clamp_window(w);
}

void gui_wm_resize(GuiWindow *w, int width, int height) {
    if (w == NULL) {
        return;
    }
    w->w = width;
    w->h = height;
    clamp_window(w);
}

void gui_wm_move(GuiWindow *w, int x, int y) {
    if (w == NULL) {
        return;
    }
    w->x = x;
    w->y = y;
    clamp_window(w);
}

void gui_wm_content_rect(GuiWindow *w, int *cx, int *cy, int *cw, int *ch) {
    if (w == NULL) {
        if (cx) *cx = 0;
        if (cy) *cy = 0;
        if (cw) *cw = 0;
        if (ch) *ch = 0;
        return;
    }
    if (cx) *cx = w->x + WM_BORDER;
    if (cy) *cy = w->y + WM_TITLE_H;
    if (cw) *cw = w->w - 2 * WM_BORDER;
    if (ch) *ch = w->h - WM_TITLE_H - WM_BORDER;
}

GuiWindow *gui_wm_top(void) {
    for (int i = z_count - 1; i >= 0; --i) {
        if (z_order[i]->open && !z_order[i]->minimized) {
            return z_order[i];
        }
    }
    return NULL;
}

GuiWindow *gui_wm_z_at(int index) {
    if (index < 0 || index >= z_count) {
        return NULL;
    }
    return z_order[index];
}

int gui_wm_z_count(void) {
    return z_count;
}

int gui_wm_open_count(void) {
    int count = 0;
    for (int i = 0; i < WM_MAX_WINDOWS; ++i) {
        if (windows[i].open) {
            count++;
        }
    }
    return count;
}

int gui_wm_window_count(void) {
    return WM_MAX_WINDOWS;
}

GuiWindow *gui_wm_window_at(int index) {
    if (index < 0 || index >= WM_MAX_WINDOWS) {
        return NULL;
    }
    return &windows[index];
}
