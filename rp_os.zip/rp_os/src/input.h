#ifndef RP_OS_INPUT_H
#define RP_OS_INPUT_H

#include <stdbool.h>
#include <stdint.h>

#define INPUT_KEY_ESC 0x1B
#define INPUT_KEY_ENTER '\r'
#define INPUT_KEY_TAB '\t'
#define INPUT_KEY_BACKSPACE '\b'
#define INPUT_KEY_DELETE 0x7F
#define INPUT_KEY_UP 0x100
#define INPUT_KEY_DOWN 0x101
#define INPUT_KEY_LEFT 0x102
#define INPUT_KEY_RIGHT 0x103
#define INPUT_KEY_HOME 0x104
#define INPUT_KEY_END 0x105
#define INPUT_KEY_PAGEUP 0x106
#define INPUT_KEY_PAGEDOWN 0x107
#define INPUT_KEY_F1 0x110
#define INPUT_KEY_F2 0x111
#define INPUT_KEY_F5 0x114
#define INPUT_KEY_F10 0x119
#define INPUT_KEY_F12 0x11B

#define INPUT_MOD_CTRL 0x01
#define INPUT_MOD_SHIFT 0x02
#define INPUT_MOD_ALT 0x04

typedef enum {
    INPUT_EV_KEY,
    INPUT_EV_MOUSE_BUTTON,
    INPUT_EV_WHEEL,
} InputEventType;

typedef struct {
    InputEventType type;
    uint16_t key;
    uint8_t mods;
    bool pressed;
    bool repeat;
    int x;
    int y;
    uint8_t buttons;
    int8_t wheel;
} InputEvent;

void input_init(void);
void input_task(void);
bool input_poll(InputEvent *event);
bool input_take_moved(void);

void input_mouse_move(int dx, int dy);
void input_mouse_buttons(uint8_t buttons);
void input_mouse_wheel(int8_t wheel);
void input_get_mouse(int *x, int *y, uint8_t *buttons);
void input_set_mouse_limits(int width, int height);

#define INPUT_MOUSE_SPEED_COUNT 4
uint8_t input_mouse_speed_get(void);
void input_mouse_speed_set(uint8_t index);
const char *input_mouse_speed_label(void);
bool input_mouse_invert_get(void);
void input_mouse_invert_set(bool invert);

void input_key(uint16_t key, uint8_t mods, bool pressed);

#endif
