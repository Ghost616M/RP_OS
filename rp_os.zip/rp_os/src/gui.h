#ifndef RP_OS_GUI_H
#define RP_OS_GUI_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    GUI_EV_NONE = 0,
    GUI_EV_MOUSE_DOWN,
    GUI_EV_MOUSE_UP,
    GUI_EV_MOUSE_MOVE,
    GUI_EV_WHEEL,
    GUI_EV_KEY,
} GuiEventType;

typedef struct {
    GuiEventType type;
    int x;
    int y;
    uint8_t button;
    int8_t wheel;
    uint16_t key;
    uint8_t mods;
    bool pressed;
    bool repeat;
} GuiEvent;

typedef struct GuiWindow {
    bool open;
    bool minimized;
    int app_id;
    char title[40];
    int x;
    int y;
    int w;
    int h;
    void *state;
    bool dragging;
    bool resizing;
    int drag_dx;
    int drag_dy;
} GuiWindow;

void gui_init(void);
void gui_task(void);
void gui_invalidate(void);
void gui_close_start_menu(void);
void gui_mouse_get(int *x, int *y);

#endif
