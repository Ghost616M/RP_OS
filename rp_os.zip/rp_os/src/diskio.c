#include "ff.h"
#include "diskio.h"

#include "flash_disk.h"
#include "sd_spi.h"
#include "usb_host.h"

DSTATUS disk_initialize(BYTE pdrv) {
    switch (pdrv) {
        case 0:
            return 0;
        case 1:
            return sd_ready() ? 0 : (STA_NOINIT | STA_NODISK);
        case 2:
            return usb_msc_ready() ? 0 : (STA_NOINIT | STA_NODISK);
        default:
            return STA_NOINIT;
    }
}

DSTATUS disk_status(BYTE pdrv) {
    return disk_initialize(pdrv);
}

DRESULT disk_read(BYTE pdrv, BYTE *buff, LBA_t sector, UINT count) {
    if (count == 0) {
        return RES_OK;
    }
    switch (pdrv) {
        case 0:
            return flash_disk_read((uint32_t)sector, buff, count) ? RES_OK : RES_ERROR;
        case 1:
            return sd_read_blocks((uint32_t)sector, buff, count) ? RES_OK : RES_ERROR;
        case 2:
            return usb_msc_read((uint32_t)sector, buff, count) ? RES_OK : RES_ERROR;
        default:
            return RES_PARERR;
    }
}

DRESULT disk_write(BYTE pdrv, const BYTE *buff, LBA_t sector, UINT count) {
    if (count == 0) {
        return RES_OK;
    }
    switch (pdrv) {
        case 0:
            return flash_disk_write((uint32_t)sector, buff, count) ? RES_OK : RES_ERROR;
        case 1:
            return sd_write_blocks((uint32_t)sector, buff, count) ? RES_OK : RES_ERROR;
        case 2:
            return usb_msc_write((uint32_t)sector, buff, count) ? RES_OK : RES_ERROR;
        default:
            return RES_PARERR;
    }
}

DRESULT disk_ioctl(BYTE pdrv, BYTE cmd, void *buff) {
    switch (cmd) {
        case CTRL_SYNC:
            if (pdrv == 0) {
                return flash_disk_flush() ? RES_OK : RES_ERROR;
            }
            return RES_OK;

        case GET_SECTOR_COUNT: {
            DWORD count = 0;
            switch (pdrv) {
                case 0: count = flash_disk_sector_count(); break;
                case 1: count = sd_sector_count(); break;
                case 2: count = usb_msc_block_count(); break;
                default: return RES_PARERR;
            }
            if (count == 0) {
                return RES_ERROR;
            }
            *(DWORD *)buff = count;
            return RES_OK;
        }

        case GET_SECTOR_SIZE:
            *(WORD *)buff = 512;
            return RES_OK;

        case GET_BLOCK_SIZE:
            *(DWORD *)buff = pdrv == 0 ? 8 : 1;
            return RES_OK;

        default:
            return RES_PARERR;
    }
}
