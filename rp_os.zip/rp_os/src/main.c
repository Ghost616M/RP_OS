#include "pico/stdlib.h"

#include "board.h"
#include "display.h"
#include "gfx.h"
#include "gui.h"
#include "hw.h"
#include "input.h"
#include "net_stack.h"
#include "storage.h"
#include "theme.h"
#include "usb_host.h"

int main(void) {
    board_init();
    theme_init();
    hw_init();
    input_init();
    usb_init();
    storage_init();
    net_stack_init();

    display_init();
    gfx_init(display_backbuffer(), DISPLAY_WIDTH, DISPLAY_HEIGHT);
    gui_init();

    while (true) {
        storage_task();
        usb_task();
        net_stack_task();
        gui_task();
        board_poll_reset();
        tight_loop_contents();
    }
}
