#include "app.h"

#include <stdio.h>
#include <string.h>

#include "gfx.h"
#include "hw.h"
#include "input.h"
#include "theme.h"
#include "ui.h"

#define GPIO_HEADER_H 14
#define GPIO_ROW_H 12
#define GPIO_ROWS 14
#define GPIO_CELL_W 154

typedef struct {
    uint8_t i2c_found[16];
    int i2c_count;
    bool i2c_ran;
    uint32_t input_bits;
} GpioState;

static GpioState gpio;

static void gpio_format_i2c(GpioState *st, char *out, size_t out_size) {
    if (!st->i2c_ran) {
        snprintf(out, out_size, "I2C 6/7: ?");
        return;
    }
    int pos = snprintf(out, out_size, "I2C 6/7:");
    if (st->i2c_count == 0) {
        snprintf(out + pos, out_size - (size_t)pos, " nenhum");
        return;
    }
    for (int i = 0; i < st->i2c_count && i < 4; ++i) {
        pos += snprintf(out + pos, out_size - (size_t)pos, " %02X", st->i2c_found[i]);
        if ((size_t)pos >= out_size) {
            break;
        }
    }
}

static int gpio_cell_hit(int x, int y, int *pin, int *segment) {
    if (y < GPIO_HEADER_H || y >= GPIO_HEADER_H + GPIO_ROWS * GPIO_ROW_H) {
        return 0;
    }
    int cell_w = GPIO_CELL_W;
    int col = x >= cell_w ? 1 : 0;
    int row = (y - GPIO_HEADER_H) / GPIO_ROW_H;
    int pin_no = row * 2 + col;
    if (pin_no >= HW_PIN_COUNT) {
        return 0;
    }

    int lx = x - col * cell_w;
    int seg = 0;
    if (lx >= 32 && lx < 58) {
        seg = 1;
    } else if (lx >= 61 && lx < 83) {
        seg = 2;
    } else if (lx >= 86 && lx < 112) {
        seg = 3;
    }
    *pin = pin_no;
    *segment = seg;
    return 1;
}

static void gpio_draw(GuiWindow *w, int cx, int cy, int cw, int ch) {
    GpioState *st = w->state;
    gfx_fill(cx, cy, cw, ch, T_PANEL);

    int mx = 0, my = 0;
    gui_mouse_get(&mx, &my);

    gfx_fill(cx, cy, cw, GPIO_HEADER_H, T_PANEL_ALT);
    gfx_text(cx + 4, cy + 3, "GPIO", T_TEXT, T_PANEL_ALT, false);

    int bx = cw - 48;
    bool i2c_hot = ui_hit(cx + bx, cy + 2, 46, 11, mx, my);
    ui_button(cx + bx, cy + 2, 46, 11, "I2C", i2c_hot, true, T_SEL);

    char buf[40];
    gpio_format_i2c(st, buf, sizeof(buf));
    gfx_text_clip(cx + 36, cy + 3, bx - 40, buf, T_TEXT_DIM, T_PANEL_ALT, false);

    for (int pin = 0; pin < HW_PIN_COUNT; ++pin) {
        int row = pin / 2;
        int col = pin % 2;
        int x0 = col * GPIO_CELL_W + 2;
        int y0 = GPIO_HEADER_H + row * GPIO_ROW_H;

        HwMode mode = hw_pin_mode(pin);
        bool level = hw_pin_get(pin);
        bool hot = ui_hit(cx + x0, cy + y0, 112, GPIO_ROW_H, mx, my);

        snprintf(buf, sizeof(buf), "P%02d", pin);
        gfx_text(cx + x0, cy + y0 + 2, buf, T_TEXT_DIM, T_PANEL, false);

        uint16_t led = T_TEXT_FAINT;
        if (mode == HW_MODE_PWM) {
            led = T_ACCENT;
        } else if (mode == HW_MODE_INPUT || mode == HW_MODE_OUTPUT) {
            led = level ? T_OK : T_TEXT_FAINT;
        }
        gfx_fill(cx + x0 + 25, cy + y0 + 4, 4, 4, led);

        const char *mode_text = "IN";
        if (mode == HW_MODE_OUTPUT) mode_text = "OUT";
        else if (mode == HW_MODE_PWM) mode_text = "PWM";
        else if (mode == HW_MODE_UNUSED) mode_text = "--";
        ui_button(cx + x0 + 32, cy + y0 + 1, 26, 10, mode_text,
                  hot && mode == HW_MODE_OUTPUT, true, T_ACCENT_DARK);

        char level_text[2] = { level ? '1' : '0', '\0' };
        bool can_write = (mode == HW_MODE_OUTPUT);
        ui_button(cx + x0 + 61, cy + y0 + 1, 22, 10, level_text,
                  can_write && level, can_write, T_SEL);

        ui_button(cx + x0 + 86, cy + y0 + 1, 26, 10, "PWM",
                  mode == HW_MODE_PWM, true, T_ACCENT_DARK);
    }
}

static bool gpio_event(GuiWindow *w, const GuiEvent *ev, int cx, int cy, int cw, int ch) {
    GpioState *st = w->state;
    (void)ch;

    if (ev->type != GUI_EV_MOUSE_DOWN) {
        return false;
    }

    if (ui_hit(cw - 48, 2, 46, 11, ev->x, ev->y)) {
        st->i2c_count = hw_i2c_scan(6, 7, st->i2c_found, 16);
        st->i2c_ran = true;
        gui_invalidate();
        return true;
    }

    int pin = 0;
    int segment = 0;
    if (!gpio_cell_hit(ev->x, ev->y, &pin, &segment)) {
        return false;
    }
    if (segment == 0) {
        return false;
    }

    HwMode mode = hw_pin_mode(pin);
    if (segment == 1) {
        if (mode == HW_MODE_PWM) {
            hw_pin_pwm_off(pin);
        } else if (mode == HW_MODE_OUTPUT) {
            hw_pin_set_mode(pin, HW_MODE_INPUT);
        } else {
            hw_pin_set_mode(pin, HW_MODE_OUTPUT);
        }
    } else if (segment == 2) {
        if (mode == HW_MODE_OUTPUT) {
            hw_pin_write(pin, !hw_pin_get(pin));
        }
    } else {
        if (mode == HW_MODE_PWM) {
            hw_pin_pwm_off(pin);
        } else {
            hw_pin_pwm(pin, 1000, 50);
        }
    }

    gui_invalidate();
    return true;
}

static void gpio_tick(GuiWindow *w) {
    GpioState *st = w->state;
    uint32_t bits = 0;
    for (int pin = 0; pin < HW_PIN_COUNT; ++pin) {
        if (hw_pin_mode(pin) == HW_MODE_INPUT && hw_pin_get(pin)) {
            bits |= 1U << pin;
        }
    }
    if (bits != st->input_bits) {
        st->input_bits = bits;
        gui_invalidate();
    }
}

static void gpio_create(GuiWindow *w, const char *arg) {
    (void)arg;
    memset(&gpio, 0, sizeof(gpio));
    w->state = &gpio;
    snprintf(w->title, sizeof(w->title), "GPIO");
}

const AppOps app_gpio_ops = {
    .name = "GPIO",
    .id = APP_GPIO,
    .icon_color = RGB565(84, 158, 255),
    .width = 310,
    .height = 202,
    .create = gpio_create,
    .destroy = NULL,
    .open_arg = NULL,
    .draw = gpio_draw,
    .event = gpio_event,
    .tick = gpio_tick,
};
