#include "app.h"

#include <stdio.h>
#include <string.h>

#include "board.h"
#include "gfx.h"
#include "input.h"
#include "theme.h"
#include "ui.h"

#define SET_TAB_H 14
#define SET_TABS 3
#define SET_THEME_BTNS 4

typedef struct {
    int tab;
    char msg[88];
    bool msg_err;
} SettingsState;

static SettingsState settings;

static const char *const settings_tabs[SET_TABS] = {"Temas", "Mouse", "Sistema"};
static const ThemeId settings_themes[SET_THEME_BTNS] = {
    THEME_BLUE_CLASSIC, THEME_DARK_CYBER, THEME_MATRIX, THEME_RETRO,
};

static void set_msg(bool err, const char *text) {
    settings.msg_err = err;
    snprintf(settings.msg, sizeof(settings.msg), "%.87s", text);
    char *nl = strchr(settings.msg, '\n');
    if (nl != NULL) {
        *nl = '\0';
    }
}

static void settings_create(GuiWindow *w, const char *arg) {
    (void)arg;
    memset(&settings, 0, sizeof(settings));
    settings.tab = 0;
    set_msg(false, "configuracoes do sistema");
    w->state = &settings;
    snprintf(w->title, sizeof(w->title), "Configuracoes");
}

static void settings_destroy(GuiWindow *w) {
    (void)w;
}

static void draw_tabs(int cx, int cy, int cw) {
    int tab_w = cw / SET_TABS;
    for (int i = 0; i < SET_TABS; ++i) {
        int x = cx + i * tab_w;
        bool active = settings.tab == i;
        uint16_t fill = active ? T_TITLE_FOCUS : T_PANEL_ALT;
        gfx_fill(x, cy, tab_w - 1, SET_TAB_H, fill);
        gfx_rect_outline(x, cy, tab_w - 1, SET_TAB_H, active ? T_ACCENT : T_BORDER);
        ui_text_center(x, cy + 3, tab_w - 1, settings_tabs[i],
                       active ? T_TEXT : T_TEXT_DIM, fill, false);
    }
}

static void draw_theme_tab(int cx, int cy, int cw, int ch) {
    int margin = 8;
    int gap = 6;
    int bw = (cw - margin * 2 - gap) / 2;
    int bh = 18;
    int y0 = cy + 24;
    int y1 = y0 + bh + 6;

    int mx, my;
    gui_mouse_get(&mx, &my);
    (void)ch;

    for (int i = 0; i < SET_THEME_BTNS; ++i) {
        int x = cx + margin + (i % 2) * (bw + gap);
        int y = (i < 2) ? y0 : y1;
        bool selected = theme_get() == settings_themes[i];
        ui_button(x, y, bw, bh, theme_name(settings_themes[i]),
                  selected || ui_hit(x, y, bw, bh, mx, my), true, T_SEL);
        if (selected) {
            gfx_rect_outline(x, y, bw, bh, T_ACCENT2);
        }
    }

    int info_y = y1 + bh + 10;
    gfx_text(cx + margin, info_y, "Tema atual:", T_TEXT_DIM, T_PANEL, false);
    gfx_text(cx + margin + 72, info_y, theme_name(theme_get()), T_ACCENT2, T_PANEL, false);
    gfx_text_clip(cx + margin, info_y + 14, cw - margin * 2,
                  "A paleta e aplicada na hora em todo o sistema.", T_TEXT_FAINT, T_PANEL, false);
}

static void draw_mouse_tab(int cx, int cy, int cw, int ch) {
    int mx, my;
    gui_mouse_get(&mx, &my);
    (void)ch;

    gfx_text(cx + 8, cy + 22, "Velocidade / DPI do cursor", T_TEXT_DIM, T_PANEL, false);

    int row_y = cy + 36;
    int minus_x = cx + 8;
    int plus_x = cx + cw - 30;
    ui_button(minus_x, row_y, 22, 16, "-", ui_hit(minus_x, row_y, 22, 16, mx, my),
              input_mouse_speed_get() > 0, T_SEL);
    ui_button(plus_x, row_y, 22, 16, "+",
              ui_hit(plus_x, row_y, 22, 16, mx, my),
              input_mouse_speed_get() + 1 < INPUT_MOUSE_SPEED_COUNT, T_SEL);

    int label_x = minus_x + 26;
    int label_w = plus_x - 4 - label_x;
    gfx_fill(label_x, row_y, label_w, 16, T_PANEL_ALT);
    gfx_rect_outline(label_x, row_y, label_w, 16, T_BORDER);
    ui_text_center(label_x, row_y + 4, label_w, input_mouse_speed_label(),
                   T_TEXT, T_PANEL_ALT, false);

    char buf[48];
    snprintf(buf, sizeof(buf), "multiplicador %s", input_mouse_speed_label());
    gfx_text_clip(cx + 8, row_y + 22, cw - 16, buf, T_TEXT_FAINT, T_PANEL, false);

    int inv_y = cy + 80;
    bool inv = input_mouse_invert_get();
    snprintf(buf, sizeof(buf), "Inverter botoes: %s", inv ? "ON" : "OFF");
    ui_button(cx + 8, inv_y, cw - 16, 18, buf,
              ui_hit(cx + 8, inv_y, cw - 16, 18, mx, my), true, T_SEL);

    gfx_text_clip(cx + 8, inv_y + 26, cw - 16,
                  "Troca esquerdo/direito. 0.5x a 2.0x.", T_TEXT_FAINT, T_PANEL, false);
}

static void draw_system_tab(int cx, int cy, int cw, int ch) {
    int mx, my;
    gui_mouse_get(&mx, &my);
    char buf[64];

    gfx_text(cx + 8, cy + 22, "Clock da CPU", T_TEXT_DIM, T_PANEL, false);
    int cpu_y = cy + 32;
    int bw = (cw - 24) / 2;
    ui_button(cx + 8, cpu_y, bw, 16, "150 MHz",
              ui_hit(cx + 8, cpu_y, bw, 16, mx, my), true, T_SEL);
    ui_button(cx + 12 + bw, cpu_y, bw, 16, "250 MHz turbo",
              ui_hit(cx + 12 + bw, cpu_y, bw, 16, mx, my), true, T_SEL);

    int info_y = cpu_y + 24;
    snprintf(buf, sizeof(buf), "CPU atual: %lu MHz x2", (unsigned long)board_cpu_mhz());
    gfx_text(cx + 8, info_y, buf, T_ACCENT2, T_PANEL, false);

    snprintf(buf, sizeof(buf), "RAM total: %lu KB", (unsigned long)board_ram_total_kb());
    gfx_text(cx + 8, info_y + 12, buf, T_TEXT, T_PANEL, false);
    snprintf(buf, sizeof(buf), "Heap usado: %lu KB / livre: %lu KB",
             (unsigned long)(board_heap_used() / 1024U),
             (unsigned long)(board_heap_free() / 1024U));
    gfx_text_clip(cx + 8, info_y + 24, cw - 16, buf, T_TEXT_DIM, T_PANEL, false);

    int btn_y = cy + ch - 42;
    ui_button(cx + 8, btn_y, (cw - 24) / 2, 18, "Reiniciar",
              ui_hit(cx + 8, btn_y, (cw - 24) / 2, 18, mx, my), true, T_WARN);
    ui_button(cx + 12 + (cw - 24) / 2, btn_y, (cw - 24) / 2, 18, "BOOTSEL",
              ui_hit(cx + 12 + (cw - 24) / 2, btn_y, (cw - 24) / 2, 18, mx, my),
              true, T_ERR);
}

static void settings_draw(GuiWindow *w, int cx, int cy, int cw, int ch) {
    (void)w;
    gfx_fill(cx, cy, cw, ch, T_PANEL);

    draw_tabs(cx, cy, cw);
    if (settings.tab == 0) {
        draw_theme_tab(cx, cy, cw, ch);
    } else if (settings.tab == 1) {
        draw_mouse_tab(cx, cy, cw, ch);
    } else {
        draw_system_tab(cx, cy, cw, ch);
    }

    gfx_hline(cx + 4, cy + ch - 16, cw - 8, T_BORDER);
    gfx_text_clip(cx + 6, cy + ch - 10, cw - 12, settings.msg,
                  settings.msg_err ? T_ERR : T_TEXT_DIM, T_PANEL, false);
}

static bool settings_event(GuiWindow *w, const GuiEvent *ev, int cx, int cy, int cw, int ch) {
    (void)w;
    (void)cx;
    (void)cy;
    if (ev->type != GUI_EV_MOUSE_DOWN) {
        return false;
    }

    if (ev->y >= 0 && ev->y < SET_TAB_H) {
        int tab = ev->x * SET_TABS / cw;
        if (tab >= 0 && tab < SET_TABS) {
            settings.tab = tab;
            gui_invalidate();
        }
        return true;
    }

    if (settings.tab == 0) {
        int margin = 8;
        int gap = 6;
        int bw = (cw - margin * 2 - gap) / 2;
        int bh = 18;
        int y0 = 24;
        int y1 = y0 + bh + 6;
        for (int i = 0; i < SET_THEME_BTNS; ++i) {
            int x = margin + (i % 2) * (bw + gap);
            int y = (i < 2) ? y0 : y1;
            if (ui_hit(x, y, bw, bh, ev->x, ev->y)) {
                theme_set(settings_themes[i]);
                set_msg(false, theme_name(settings_themes[i]));
                gui_invalidate();
                return true;
            }
        }
    } else if (settings.tab == 1) {
        int row_y = 36;
        int minus_x = 8;
        int plus_x = cw - 30;
        if (ui_hit(minus_x, row_y, 22, 16, ev->x, ev->y)) {
            uint8_t speed = input_mouse_speed_get();
            if (speed > 0) {
                input_mouse_speed_set((uint8_t)(speed - 1));
                set_msg(false, input_mouse_speed_label());
            }
            gui_invalidate();
            return true;
        }
        if (ui_hit(plus_x, row_y, 22, 16, ev->x, ev->y)) {
            uint8_t speed = input_mouse_speed_get();
            if (speed + 1 < INPUT_MOUSE_SPEED_COUNT) {
                input_mouse_speed_set((uint8_t)(speed + 1));
                set_msg(false, input_mouse_speed_label());
            }
            gui_invalidate();
            return true;
        }
        int inv_y = 80;
        if (ui_hit(8, inv_y, cw - 16, 18, ev->x, ev->y)) {
            input_mouse_invert_set(!input_mouse_invert_get());
            set_msg(false, input_mouse_invert_get() ? "botoes invertidos" : "botoes normais");
            gui_invalidate();
            return true;
        }
    } else {
        int cpu_y = 32;
        int bw = (cw - 24) / 2;
        if (ui_hit(8, cpu_y, bw, 16, ev->x, ev->y)) {
            bool ok = board_set_cpu_mhz(150);
            set_msg(!ok, ok ? "CPU em 150 MHz (DVI pode oscilar)" : "falha ao mudar clock");
            gui_invalidate();
            return true;
        }
        if (ui_hit(12 + bw, cpu_y, bw, 16, ev->x, ev->y)) {
            bool ok = board_set_cpu_mhz(252);
            set_msg(!ok, ok ? "CPU em 252 MHz turbo" : "falha ao mudar clock");
            gui_invalidate();
            return true;
        }
        int btn_y = ch - 42;
        if (ui_hit(8, btn_y, (cw - 24) / 2, 18, ev->x, ev->y)) {
            board_schedule_reset(400, false);
            set_msg(false, "reiniciando...");
            gui_invalidate();
            return true;
        }
        if (ui_hit(12 + (cw - 24) / 2, btn_y, (cw - 24) / 2, 18, ev->x, ev->y)) {
            board_schedule_reset(400, true);
            set_msg(false, "entrando em BOOTSEL...");
            gui_invalidate();
            return true;
        }
    }
    return false;
}

const AppOps app_settings_ops = {
    .name = "Configuracoes",
    .id = APP_SETTINGS,
    .icon_color = RGB565(180, 180, 190),
    .width = 286,
    .height = 192,
    .create = settings_create,
    .destroy = settings_destroy,
    .open_arg = NULL,
    .draw = settings_draw,
    .event = settings_event,
    .tick = NULL,
};
