#include "app.h"

#include <stdarg.h>
#include <stdio.h>

#include "pico/stdlib.h"
#include <string.h>

#include "gfx.h"
#include "input.h"
#include "storage.h"
#include "theme.h"
#include "ui.h"

#define ED_TOOLBAR_H 15
#define ED_STATUS_H 11

typedef struct {
    char path[128];
    char text[APP_EDITOR_MAX_BYTES];
    int len;
    int cursor;
    int top_line;
    int left_col;
    bool modified;
    uint64_t blink_us;
    bool cursor_on;
    char status[64];
    uint16_t status_color;
} EditorState;

static EditorState ed;

static void ed_status(EditorState *st, uint16_t color, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vsnprintf(st->status, sizeof(st->status), fmt, args);
    va_end(args);
    st->status_color = color;
}

static int ed_line_start(const EditorState *st, int pos) {
    if (pos > st->len) pos = st->len;
    while (pos > 0 && st->text[pos - 1] != '\n') {
        pos--;
    }
    return pos;
}

static int ed_line_end(const EditorState *st, int pos) {
    if (pos < 0) pos = 0;
    while (pos < st->len && st->text[pos] != '\n') {
        pos++;
    }
    return pos;
}

static int ed_line_number(const EditorState *st, int pos) {
    int line = 1;
    if (pos > st->len) pos = st->len;
    for (int i = 0; i < pos; ++i) {
        if (st->text[i] == '\n') {
            line++;
        }
    }
    return line;
}

static void ed_update_title(GuiWindow *w) {
    EditorState *st = w->state;
    char base[48];
    vfs_basename(st->path[0] != '\0' ? st->path : "novo.txt", base, sizeof(base));
    snprintf(w->title, sizeof(w->title), "Editor - %.24s%s", base, st->modified ? "*" : "");
}

static void ed_expand_tabs(EditorState *st) {
    int write = 0;
    for (int i = 0; i < st->len; ++i) {
        char c = st->text[i];
        if (c == '\t') {
            for (int s = 0; s < 2; ++s) {
                if (write < APP_EDITOR_MAX_BYTES - 1) {
                    st->text[write++] = ' ';
                }
            }
        } else if (write < APP_EDITOR_MAX_BYTES - 1) {
            st->text[write++] = c;
        }
    }
    st->len = write;
    st->text[st->len] = '\0';
}

static void ed_load(GuiWindow *w, const char *path) {
    EditorState *st = w->state;
    size_t got = 0;
    if (!vfs_read_file(path, st->text, sizeof(st->text), &got)) {
        ed_status(st, T_ERR, "erro ao abrir");
        return;
    }
    st->len = (int)got;
    st->text[st->len] = '\0';
    snprintf(st->path, sizeof(st->path), "%s", path);
    st->cursor = 0;
    st->top_line = 0;
    st->left_col = 0;
    st->modified = false;
    ed_expand_tabs(st);
    ed_status(st, T_TEXT_DIM, "aberto");
    ed_update_title(w);
}

static void ed_save(GuiWindow *w) {
    EditorState *st = w->state;
    char path[128];
    if (st->path[0] != '\0') {
        snprintf(path, sizeof(path), "%s", st->path);
    } else {
        snprintf(path, sizeof(path), "/flash/novo.txt");
    }

    if (vfs_write_file(path, st->text, (size_t)st->len)) {
        snprintf(st->path, sizeof(st->path), "%s", path);
        st->modified = false;
        ed_status(st, T_OK, "salvo");
    } else {
        ed_status(st, T_ERR, "falha ao salvar");
    }
    ed_update_title(w);
    gui_invalidate();
}

static void ed_new(GuiWindow *w) {
    EditorState *st = w->state;
    st->path[0] = '\0';
    st->len = 0;
    st->text[0] = '\0';
    st->cursor = 0;
    st->top_line = 0;
    st->left_col = 0;
    st->modified = false;
    ed_status(st, T_TEXT_DIM, "novo arquivo");
    ed_update_title(w);
    gui_invalidate();
}

static void ed_insert(EditorState *st, char c) {
    if (st->len >= APP_EDITOR_MAX_BYTES - 1) {
        ed_status(st, T_ERR, "limite atingido");
        return;
    }
    memmove(&st->text[st->cursor + 1], &st->text[st->cursor],
            (size_t)(st->len - st->cursor + 1));
    st->text[st->cursor] = c;
    st->cursor++;
    st->len++;
    st->modified = true;
}

static void ed_backspace(EditorState *st) {
    if (st->cursor <= 0) {
        return;
    }
    memmove(&st->text[st->cursor - 1], &st->text[st->cursor],
            (size_t)(st->len - st->cursor + 1));
    st->cursor--;
    st->len--;
    st->modified = true;
}

static void ed_delete(EditorState *st) {
    if (st->cursor >= st->len) {
        return;
    }
    memmove(&st->text[st->cursor], &st->text[st->cursor + 1],
            (size_t)(st->len - st->cursor));
    st->len--;
    st->modified = true;
}

static void ed_move_vertical(EditorState *st, int dir) {
    int start = ed_line_start(st, st->cursor);
    int col = st->cursor - start;
    if (dir < 0) {
        if (start == 0) {
            st->cursor = 0;
            return;
        }
        int prev_end = start - 1;
        int prev_start = ed_line_start(st, prev_end);
        int len = prev_end - prev_start;
        st->cursor = prev_start + (col < len ? col : len);
    } else {
        int end = ed_line_end(st, st->cursor);
        if (end >= st->len) {
            return;
        }
        int next_start = end + 1;
        int next_end = ed_line_end(st, next_start);
        int len = next_end - next_start;
        st->cursor = next_start + (col < len ? col : len);
    }
}

static void ed_click(GuiWindow *w, int cx, int cy, int cw, int ch, int x, int y) {
    EditorState *st = w->state;
    int ty = ED_TOOLBAR_H;
    int rows = (ch - ED_TOOLBAR_H - ED_STATUS_H) / 8;
    int cols = cw / 8;

    int line = st->top_line + (y - ty) / 8;
    int col = st->left_col + x / 8;
    if (line < 0) line = 0;
    if (col < 0) col = 0;

    int pos = 0;
    for (int i = 0; i < line && pos < st->len; ++i) {
        pos = ed_line_end(st, pos);
        if (pos < st->len) pos++;
    }
    int end = ed_line_end(st, pos);
    if (col > end - pos) col = end - pos;
    st->cursor = pos + col;
    st->cursor_on = true;
    st->blink_us = time_us_64();
    (void)rows;
    (void)cols;
    gui_invalidate();
}

static void ed_draw(GuiWindow *w, int cx, int cy, int cw, int ch) {
    EditorState *st = w->state;

    int mx = 0, my = 0;
    gui_mouse_get(&mx, &my);

    gfx_fill(cx, cy, cw, ch, T_TERM_BG);

    gfx_fill(cx, cy, cw, ED_TOOLBAR_H, T_PANEL_ALT);
    int salvar_x = cw - 2 - 44;
    int novo_x = salvar_x - 2 - 36;
    gfx_text_clip(cx + 4, cy + 4, novo_x - 6, st->path[0] ? st->path : "(sem titulo)",
                  T_TEXT_DIM, T_PANEL_ALT, false);
    bool save_hot = ui_hit(cx + salvar_x, cy + 2, 44, 11, mx, my);
    bool new_hot = ui_hit(cx + novo_x, cy + 2, 36, 11, mx, my);
    ui_button(cx + novo_x, cy + 2, 36, 11, "NOVO", new_hot, true, T_SEL);
    ui_button(cx + salvar_x, cy + 2, 44, 11, "SALVAR", save_hot, true, T_SEL);

    int text_y = cy + ED_TOOLBAR_H;
    int text_h = ch - ED_TOOLBAR_H - ED_STATUS_H;
    gfx_fill(cx, text_y, cw, text_h, T_TERM_BG);

    int rows = text_h / 8;
    int cols = cw / 8;
    if (rows < 1) rows = 1;
    if (cols < 1) cols = 1;

    int cline = ed_line_number(st, st->cursor) - 1;
    int cstart = ed_line_start(st, st->cursor);
    int ccol = st->cursor - cstart;

    if (cline < st->top_line) st->top_line = cline;
    if (cline >= st->top_line + rows) st->top_line = cline - rows + 1;
    if (ccol < st->left_col) st->left_col = ccol;
    if (ccol >= st->left_col + cols) st->left_col = ccol - cols + 1;
    if (st->top_line < 0) st->top_line = 0;
    if (st->left_col < 0) st->left_col = 0;

    int pos = 0;
    for (int i = 0; i < st->top_line && pos < st->len; ++i) {
        pos = ed_line_end(st, pos);
        if (pos < st->len) pos++;
    }

    for (int row = 0; row < rows; ++row) {
        if (pos >= st->len) {
            break;
        }
        int end = ed_line_end(st, pos);
        for (int c = st->left_col; c < st->left_col + cols && pos + c < end; ++c) {
            gfx_char(cx + (c - st->left_col) * 8, text_y + row * 8, st->text[pos + c],
                     T_TEXT, T_TERM_BG, true);
        }
        pos = end;
        if (pos < st->len) {
            pos++;
        }
    }

    if (st->cursor_on) {
        int crow = cline - st->top_line;
        int ccol_v = ccol - st->left_col;
        if (crow >= 0 && crow < rows && ccol_v >= 0 && ccol_v < cols) {
            gfx_fill(cx + ccol_v * 8, text_y + crow * 8, 1, 8, T_ACCENT);
        }
    }

    int status_y = cy + ch - ED_STATUS_H;
    gfx_fill(cx, status_y, cw, ED_STATUS_H, T_PANEL_ALT);
    char line_info[32];
    snprintf(line_info, sizeof(line_info), "Ln %d Col %d%s", cline + 1, ccol + 1,
             st->modified ? " *" : "");
    gfx_text(cx + 4, status_y + 2, line_info, T_TEXT_DIM, T_PANEL_ALT, false);
    gfx_text_clip(cx + 100, status_y + 2, cw - 104, st->status, st->status_color,
                  T_PANEL_ALT, false);
}

static bool ed_event(GuiWindow *w, const GuiEvent *ev, int cx, int cy, int cw, int ch) {
    EditorState *st = w->state;

    if (ev->type == GUI_EV_WHEEL) {
        st->top_line += ev->wheel > 0 ? -3 : 3;
        if (st->top_line < 0) st->top_line = 0;
        gui_invalidate();
        return true;
    }

    if (ev->type == GUI_EV_MOUSE_DOWN) {
        int salvar_x = cw - 2 - 44;
        int novo_x = salvar_x - 2 - 36;
        if (ui_hit(salvar_x, 2, 44, 11, ev->x, ev->y)) {
            ed_save(w);
            return true;
        }
        if (ui_hit(novo_x, 2, 36, 11, ev->x, ev->y)) {
            ed_new(w);
            return true;
        }
        if (ev->y < ED_TOOLBAR_H) {
            return false;
        }
        int text_h = ch - ED_TOOLBAR_H - ED_STATUS_H;
        if (ev->y >= ED_TOOLBAR_H && ev->y < ED_TOOLBAR_H + text_h) {
            ed_click(w, cx, cy, cw, ch, ev->x, ev->y);
            return true;
        }
        return false;
    }

    if (ev->type != GUI_EV_KEY || !ev->pressed) {
        return false;
    }

    if (ev->mods & INPUT_MOD_CTRL) {
        if (ev->key == 's' || ev->key == 'S') {
            ed_save(w);
            return true;
        }
        if (ev->key == 'n' || ev->key == 'N') {
            ed_new(w);
            return true;
        }
        return true;
    }

    switch (ev->key) {
        case INPUT_KEY_ENTER:
            ed_insert(st, '\n');
            break;
        case INPUT_KEY_TAB:
            ed_insert(st, ' ');
            ed_insert(st, ' ');
            break;
        case INPUT_KEY_BACKSPACE:
            ed_backspace(st);
            break;
        case INPUT_KEY_DELETE:
            ed_delete(st);
            break;
        case INPUT_KEY_LEFT:
            if (st->cursor > 0) st->cursor--;
            break;
        case INPUT_KEY_RIGHT:
            if (st->cursor < st->len) st->cursor++;
            break;
        case INPUT_KEY_UP:
            ed_move_vertical(st, -1);
            break;
        case INPUT_KEY_DOWN:
            ed_move_vertical(st, 1);
            break;
        case INPUT_KEY_HOME:
            st->cursor = ed_line_start(st, st->cursor);
            break;
        case INPUT_KEY_END:
            st->cursor = ed_line_end(st, st->cursor);
            break;
        case INPUT_KEY_PAGEUP:
            for (int i = 0; i < 18; ++i) ed_move_vertical(st, -1);
            break;
        case INPUT_KEY_PAGEDOWN:
            for (int i = 0; i < 18; ++i) ed_move_vertical(st, 1);
            break;
        default:
            if (ev->key >= 32 && ev->key < 127 && !(ev->mods & INPUT_MOD_ALT)) {
                ed_insert(st, (char)ev->key);
            }
            break;
    }

    st->cursor_on = true;
    st->blink_us = time_us_64();
    ed_update_title(w);
    gui_invalidate();
    return true;
}

static void ed_tick(GuiWindow *w) {
    EditorState *st = w->state;
    uint64_t now = time_us_64();
    if (now - st->blink_us >= 500000ULL) {
        st->blink_us = now;
        st->cursor_on = !st->cursor_on;
        gui_invalidate();
    }
}

static void ed_create(GuiWindow *w, const char *arg) {
    memset(&ed, 0, sizeof(ed));
    ed.cursor_on = true;
    ed.blink_us = time_us_64();
    ed.status_color = T_TEXT_DIM;
    ed_status(&ed, T_TEXT_DIM, "Ctrl+S salva");
    w->state = &ed;
    snprintf(w->title, sizeof(w->title), "Editor");

    if (arg != NULL && arg[0] != '\0') {
        ed_load(w, arg);
    }
}

static void ed_open_arg(GuiWindow *w, const char *arg) {
    if (arg == NULL || arg[0] == '\0') {
        return;
    }
    ed_load(w, arg);
    gui_invalidate();
}

const AppOps app_editor_ops = {
    .name = "Editor",
    .id = APP_EDITOR,
    .icon_color = RGB565(96, 220, 180),
    .width = 310,
    .height = 202,
    .create = ed_create,
    .destroy = NULL,
    .open_arg = ed_open_arg,
    .draw = ed_draw,
    .event = ed_event,
    .tick = ed_tick,
};
