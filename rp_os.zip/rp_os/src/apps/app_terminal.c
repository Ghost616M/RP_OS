#include "app.h"

#include <stdio.h>

#include "pico/stdlib.h"
#include <string.h>

#include "board.h"
#include "gfx.h"
#include "input.h"
#include "shell.h"
#include "theme.h"
#include "ui.h"

#define TERM_COLS SHELL_LINE_WIDTH
#define TERM_LINES 100
#define TERM_INPUT_MAX 96
#define TERM_HISTORY 8

typedef struct {
    Shell shell;
    char lines[TERM_LINES][TERM_COLS + 1];
    uint16_t colors[TERM_LINES];
    int head;
    int count;
    uint16_t color;
    char input[TERM_INPUT_MAX];
    int input_len;
    int input_pos;
    char history[TERM_HISTORY][TERM_INPUT_MAX];
    int history_count;
    int history_pos;
    int scroll;
    uint64_t blink_us;
    bool cursor_on;
} TermState;

static TermState term;

static int term_line_index(const TermState *st, int logical) {
    int idx = (st->head - st->count + logical) % TERM_LINES;
    if (idx < 0) {
        idx += TERM_LINES;
    }
    return idx;
}

static void term_new_line(TermState *st) {
    memset(st->lines[st->head], 0, TERM_COLS + 1);
    st->colors[st->head] = st->color;
    st->head = (st->head + 1) % TERM_LINES;
    if (st->count < TERM_LINES) {
        st->count++;
    }
    st->scroll = 0;
}

static void term_write(void *ctx, const char *text) {
    TermState *st = ctx;
    if (st == NULL || text == NULL) {
        return;
    }

    while (*text) {
        char c = *text++;
        if (c == '\f') {
            st->head = 0;
            st->count = 0;
            st->scroll = 0;
            continue;
        }
        if (c == '\r') {
            continue;
        }
        if (c == '\n') {
            term_new_line(st);
            continue;
        }
        if (st->count == 0) {
            term_new_line(st);
        }
        int idx = (st->head + TERM_LINES - 1) % TERM_LINES;
        size_t len = strlen(st->lines[idx]);
        if (len >= TERM_COLS) {
            term_new_line(st);
            idx = (st->head + TERM_LINES - 1) % TERM_LINES;
            len = 0;
        }
        st->lines[idx][len] = c;
        st->lines[idx][len + 1] = '\0';
        st->colors[idx] = st->color;
        st->scroll = 0;
    }
}

static void term_print(TermState *st, uint16_t color, const char *text) {
    st->color = color;
    term_write(st, text);
}

static void term_history_push(TermState *st) {
    if (st->input_len == 0) {
        return;
    }
    if (st->history_count > 0 &&
        strcmp(st->history[st->history_count - 1], st->input) == 0) {
        st->history_pos = st->history_count;
        return;
    }
    if (st->history_count == TERM_HISTORY) {
        memmove(st->history[0], st->history[1], (TERM_HISTORY - 1) * TERM_INPUT_MAX);
        st->history_count--;
    }
    snprintf(st->history[st->history_count], TERM_INPUT_MAX, "%s", st->input);
    st->history_count++;
    st->history_pos = st->history_count;
}

static void term_history_load(TermState *st, const char *line) {
    snprintf(st->input, sizeof(st->input), "%s", line);
    st->input_len = (int)strlen(st->input);
    st->input_pos = st->input_len;
}

static void term_submit(TermState *st) {
    st->input[st->input_len] = '\0';

    char prompt[64];
    shell_prompt(&st->shell, prompt, sizeof(prompt));
    term_print(st, T_TERM_GREEN, prompt);
    term_print(st, T_TEXT, st->input);
    term_new_line(st);

    if (st->input_len > 0) {
        term_history_push(st);
        shell_execute(&st->shell, st->input);
    }

    st->input_len = 0;
    st->input_pos = 0;
    st->scroll = 0;
    st->cursor_on = true;
    st->blink_us = time_us_64();
}

static void term_insert(TermState *st, char c) {
    if (st->input_len >= TERM_INPUT_MAX - 1) {
        return;
    }
    memmove(&st->input[st->input_pos + 1], &st->input[st->input_pos],
            (size_t)(st->input_len - st->input_pos + 1));
    st->input[st->input_pos] = c;
    st->input_len++;
    st->input_pos++;
}

static void term_clear(TermState *st) {
    st->head = 0;
    st->count = 0;
    st->scroll = 0;
}

static bool term_event(GuiWindow *w, const GuiEvent *ev, int cx, int cy, int cw, int ch) {
    TermState *st = w->state;

    if (ev->type == GUI_EV_WHEEL) {
        int step = ev->wheel > 0 ? 3 : -3;
        st->scroll += step;
        if (st->scroll > st->count) st->scroll = st->count;
        if (st->scroll < 0) st->scroll = 0;
        gui_invalidate();
        return true;
    }

    if (ev->type != GUI_EV_KEY) {
        return false;
    }
    if (!ev->pressed) {
        return true;
    }

    bool ctrl = (ev->mods & INPUT_MOD_CTRL) != 0;
    bool alt = (ev->mods & INPUT_MOD_ALT) != 0;

    if (ctrl) {
        switch (ev->key) {
            case 'l':
            case 'L':
                term_clear(st);
                gui_invalidate();
                return true;
            case 'c':
            case 'C':
                term_print(st, T_TERM_RED, "^C");
                term_new_line(st);
                st->input_len = 0;
                st->input_pos = 0;
                gui_invalidate();
                return true;
            case 'u':
            case 'U':
                st->input_len = 0;
                st->input_pos = 0;
                gui_invalidate();
                return true;
            case 'a':
            case 'A':
                st->input_pos = 0;
                gui_invalidate();
                return true;
            case 'e':
            case 'E':
                st->input_pos = st->input_len;
                gui_invalidate();
                return true;
            default:
                break;
        }
    }

    switch (ev->key) {
        case INPUT_KEY_ENTER:
            term_submit(st);
            break;
        case INPUT_KEY_BACKSPACE:
            if (st->input_pos > 0) {
                memmove(&st->input[st->input_pos - 1], &st->input[st->input_pos],
                        (size_t)(st->input_len - st->input_pos + 1));
                st->input_pos--;
                st->input_len--;
            }
            break;
        case INPUT_KEY_DELETE:
            if (st->input_pos < st->input_len) {
                memmove(&st->input[st->input_pos], &st->input[st->input_pos + 1],
                        (size_t)(st->input_len - st->input_pos));
                st->input_len--;
            }
            break;
        case INPUT_KEY_LEFT:
            if (st->input_pos > 0) st->input_pos--;
            break;
        case INPUT_KEY_RIGHT:
            if (st->input_pos < st->input_len) st->input_pos++;
            break;
        case INPUT_KEY_HOME:
            st->input_pos = 0;
            break;
        case INPUT_KEY_END:
            st->input_pos = st->input_len;
            break;
        case INPUT_KEY_UP:
            if (st->history_count > 0 && st->history_pos > 0) {
                st->history_pos--;
                term_history_load(st, st->history[st->history_pos]);
            }
            break;
        case INPUT_KEY_DOWN:
            if (st->history_pos < st->history_count - 1) {
                st->history_pos++;
                term_history_load(st, st->history[st->history_pos]);
            } else {
                st->history_pos = st->history_count;
                st->input_len = 0;
                st->input_pos = 0;
            }
            break;
        case INPUT_KEY_PAGEUP: {
            int step = ch / 8 - 2;
            if (step < 1) step = 1;
            st->scroll += step;
            if (st->scroll > st->count) st->scroll = st->count;
            break;
        }
        case INPUT_KEY_PAGEDOWN: {
            int step = ch / 8 - 2;
            if (step < 1) step = 1;
            st->scroll -= step;
            if (st->scroll < 0) st->scroll = 0;
            break;
        }
        case INPUT_KEY_TAB:
            term_insert(st, ' ');
            term_insert(st, ' ');
            break;
        default:
            if (ev->key >= 32 && ev->key < 127 && !ctrl && !alt) {
                term_insert(st, (char)ev->key);
            }
            break;
    }

    st->cursor_on = true;
    st->blink_us = time_us_64();
    gui_invalidate();
    return true;
}

static void term_draw(GuiWindow *w, int cx, int cy, int cw, int ch) {
    TermState *st = w->state;
    gfx_fill(cx, cy, cw, ch, T_TERM_BG);

    int rows = ch / 8;
    int cols = cw / 8;
    if (cols > TERM_COLS) cols = TERM_COLS;
    if (rows < 2 || cols < 8) {
        return;
    }

    char prompt[64];
    shell_prompt(&st->shell, prompt, sizeof(prompt));
    int prompt_len = (int)strlen(prompt);
    int total = prompt_len + st->input_len;

    int input_rows = total / cols + 1;
    if (input_rows > rows - 1) input_rows = rows - 1;
    if (input_rows < 1) input_rows = 1;
    int out_rows = rows - input_rows;

    int start = st->count - out_rows - st->scroll;
    if (start < 0) start = 0;
    int end = st->count - st->scroll;
    if (end > st->count) end = st->count;
    if (end < 0) end = 0;

    int shown = end - start;
    if (shown > out_rows) shown = out_rows;
    int offset = out_rows - shown;
    for (int i = 0; i < shown; ++i) {
        int idx = term_line_index(st, start + i);
        gfx_text_clip(cx, cy + (offset + i) * 8, cw, st->lines[idx], st->colors[idx], T_TERM_BG, true);
    }

    int base_y = cy + out_rows * 8;
    for (int i = 0; i < total; ++i) {
        int row = i / cols;
        int col = i % cols;
        if (row >= input_rows) {
            break;
        }
        char c = i < prompt_len ? prompt[i] : st->input[i - prompt_len];
        uint16_t color = i < prompt_len ? T_TERM_GREEN : T_TEXT;
        gfx_char(cx + col * 8, base_y + row * 8, c, color, T_TERM_BG, true);
    }

    if (st->cursor_on) {
        int cursor = prompt_len + st->input_pos;
        int row = cursor / cols;
        int col = cursor % cols;
        if (row < input_rows) {
            gfx_fill(cx + col * 8, base_y + row * 8 + 7, 6, 2, T_TERM_GREEN);
        }
    }

    if (st->scroll > 0) {
        gfx_text(cx + cw - 8, cy, "^", T_TERM_DIM, T_TERM_BG, false);
        int shown = st->scroll > 99 ? 99 : st->scroll;
        char buf[12];
        snprintf(buf, sizeof(buf), "%d", shown);
        gfx_text_right(cx + cw - 2, cy + 8, buf, T_TERM_DIM, T_TERM_BG, false);
    }
}

static void term_tick(GuiWindow *w) {
    TermState *st = w->state;
    uint64_t now = time_us_64();
    if (now - st->blink_us >= 500000ULL) {
        st->blink_us = now;
        st->cursor_on = !st->cursor_on;
        gui_invalidate();
    }
}

static void term_create(GuiWindow *w, const char *arg) {
    (void)arg;
    memset(&term, 0, sizeof(term));
    shell_init(&term.shell, term_write, &term);
    term.color = T_TEXT;
    term.cursor_on = true;
    term.blink_us = time_us_64();

    term_print(&term, T_ACCENT2, "rp_os v" BOARD_VERSION "\n");
    term_print(&term, T_TEXT, "Terminal pronto.\n");
    term_print(&term, T_TERM_DIM, "Digite 'help' para comandos.\n");
    term_new_line(&term);

    w->state = &term;
    snprintf(w->title, sizeof(w->title), "Terminal");
}

static void term_destroy(GuiWindow *w) {
    (void)w;
}

const AppOps app_terminal_ops = {
    .name = "Terminal",
    .id = APP_TERMINAL,
    .icon_color = RGB565(130, 230, 150),
    .width = 320,
    .height = 208,
    .create = term_create,
    .destroy = term_destroy,
    .open_arg = NULL,
    .draw = term_draw,
    .event = term_event,
    .tick = term_tick,
};
