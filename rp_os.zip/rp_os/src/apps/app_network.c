#include "app.h"

#include <stdio.h>
#include <string.h>

#include "gfx.h"
#include "net_stack.h"
#include "theme.h"
#include "ui.h"
#include "usb_host.h"

typedef struct {
    char msg[96];
    bool msg_err;
    int tick_count;
} NetAppState;

static NetAppState net_app;

#define NET_BTN_Y 2
#define NET_BTN_H 12
#define NET_BTN_DHCP_W 42
#define NET_BTN_FW_W 28
#define NET_BTN_TX_W 28
#define NET_BTN_VER_W 28
#define NET_BTN_GAP 4

static void net_buttons(int cw, int *dhcp_x, int *fw_x, int *tx_x, int *ref_x) {
    int x = cw - 2;
    *ref_x = x - NET_BTN_VER_W;
    x = *ref_x - NET_BTN_GAP;
    *tx_x = x - NET_BTN_TX_W;
    x = *tx_x - NET_BTN_GAP;
    *fw_x = x - NET_BTN_FW_W;
    x = *fw_x - NET_BTN_GAP;
    *dhcp_x = x - NET_BTN_DHCP_W;
}

static void net_set_msg(bool err, const char *text) {
    net_app.msg_err = err;
    snprintf(net_app.msg, sizeof(net_app.msg), "%.95s", text);
    char *nl = strchr(net_app.msg, '\n');
    if (nl != NULL) {
        *nl = '\0';
    }
}

static void net_create(GuiWindow *w, const char *arg) {
    (void)arg;
    memset(&net_app, 0, sizeof(net_app));
    net_set_msg(false, "aguardando eventos de rede");
    w->state = &net_app;
}

static void net_destroy(GuiWindow *w) {
    (void)w;
}

static void net_draw_row(int cx, int y, int cw, const char *label, const char *value, uint16_t color) {
    gfx_text(cx + 6, y, label, T_TEXT_DIM, T_PANEL, false);
    gfx_text_clip(cx + 62, y, cw - 68, value, color, T_PANEL, false);
}

static void net_draw_usb(int cx, int cy, int cw) {
    UsbDeviceInfo devices[8];
    int count = usb_devices(devices, 8);

    gfx_text(cx + 6, cy + 94, "USB no hub (VID:PID)", T_TEXT_DIM, T_PANEL, false);
    if (count == 0) {
        gfx_text(cx + 6, cy + 104, "nenhum dispositivo", T_TEXT_FAINT, T_PANEL, false);
        return;
    }

    char buf[48];
    for (int i = 0; i < count && i < 8; ++i) {
        int col = i / 4;
        int row = i % 4;
        int x = cx + 6 + col * 154;
        int y = cy + 104 + row * 10;
        const char *name = devices[i].name[0] != '\0'
                               ? devices[i].name
                               : usb_device_kind_name(devices[i].kind);
        snprintf(buf, sizeof(buf), "d%u %04X:%04X %.9s",
                 (unsigned)devices[i].addr,
                 devices[i].vid, devices[i].pid, name);
        uint16_t color = T_TEXT;
        if (devices[i].kind & USB_KIND_WIFI) color = T_WARN;
        else if (devices[i].kind & USB_KIND_NET) color = T_ACCENT2;
        else if (devices[i].kind & USB_KIND_MSC) color = T_ACCENT;
        gfx_text_clip(x, y, 148, buf, color, T_PANEL, false);
    }
}

static void net_draw(GuiWindow *w, int cx, int cy, int cw, int ch) {
    (void)w;
    gfx_fill(cx, cy, cw, ch, T_PANEL);

    int dhcp_x, fw_x, tx_x, ref_x;
    net_buttons(cw, &dhcp_x, &fw_x, &tx_x, &ref_x);
    int mx, my;
    gui_mouse_get(&mx, &my);

    ui_button(cx + dhcp_x, cy + NET_BTN_Y, NET_BTN_DHCP_W, NET_BTN_H, "DHCP",
              ui_hit(cx + dhcp_x, cy + NET_BTN_Y, NET_BTN_DHCP_W, NET_BTN_H, mx, my), true, T_SEL);
    ui_button(cx + fw_x, cy + NET_BTN_Y, NET_BTN_FW_W, NET_BTN_H, "LER",
              ui_hit(cx + fw_x, cy + NET_BTN_Y, NET_BTN_FW_W, NET_BTN_H, mx, my), true, T_SEL);
    ui_button(cx + tx_x, cy + NET_BTN_Y, NET_BTN_TX_W, NET_BTN_H, "TX",
              ui_hit(cx + tx_x, cy + NET_BTN_Y, NET_BTN_TX_W, NET_BTN_H, mx, my), true, T_SEL);
    ui_button(cx + ref_x, cy + NET_BTN_Y, NET_BTN_VER_W, NET_BTN_H, "VER",
              ui_hit(cx + ref_x, cy + NET_BTN_Y, NET_BTN_VER_W, NET_BTN_H, mx, my), true, T_SEL);

    NetStatus st;
    net_status_get(&st);

    char buf[96];
    int y = cy + 20;
    net_draw_row(cx, y, cw, "Link", st.link_up ? "ativo" : "sem link",
                 st.link_up ? T_OK : T_TEXT_FAINT);
    y += 9;
    snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
             st.mac[0], st.mac[1], st.mac[2], st.mac[3], st.mac[4], st.mac[5]);
    net_draw_row(cx, y, cw, "MAC", buf, T_TEXT);
    y += 9;
    net_draw_row(cx, y, cw, "IP", st.ip, st.dhcp_bound ? T_ACCENT2 : T_TEXT);
    y += 9;
    net_draw_row(cx, y, cw, "Mascara", st.mask, T_TEXT);
    y += 9;
    net_draw_row(cx, y, cw, "Gateway", st.gw, T_TEXT);
    y += 9;
    if (st.dhcp_bound) {
        snprintf(buf, sizeof(buf), "concluido");
    } else if (st.dhcp_running) {
        snprintf(buf, sizeof(buf), "requisitando...");
    } else {
        snprintf(buf, sizeof(buf), "parado");
    }
    net_draw_row(cx, y, cw, "DHCP", buf, st.dhcp_bound ? T_OK : T_WARN);
    y += 9;
    snprintf(buf, sizeof(buf), "rx %lu  tx %lu",
             (unsigned long)st.rx_frames, (unsigned long)st.tx_frames);
    net_draw_row(cx, y, cw, "Trafego", buf, T_TEXT_DIM);

    gfx_hline(cx + 4, cy + 90, cw - 8, T_BORDER);
    net_draw_usb(cx, cy, cw);
    gfx_hline(cx + 4, cy + 146, cw - 8, T_BORDER);

    y = cy + 150;
    if (st.wifi_present) {
        snprintf(buf, sizeof(buf), "Atheros %04X:%04X", st.wifi_vid, st.wifi_pid);
        net_draw_row(cx, y, cw, "Wi-Fi", buf, T_ACCENT);
    } else {
        net_draw_row(cx, y, cw, "Wi-Fi", "nenhum adaptador Atheros", T_TEXT_FAINT);
    }
    y += 9;
    gfx_text_clip(cx + 6, y, cw - 12, st.wifi_status, T_TEXT_DIM, T_PANEL, false);
    if (st.fw_loaded) {
        y += 9;
        snprintf(buf, sizeof(buf), "firmware: %lu bytes", (unsigned long)st.fw_size);
        gfx_text_clip(cx + 6, y, cw - 12, buf, T_TEXT_DIM, T_PANEL, false);
    }

    gfx_hline(cx + 4, cy + ch - 16, cw - 8, T_BORDER);
    gfx_text_clip(cx + 6, cy + ch - 10, cw - 12, net_app.msg,
                  net_app.msg_err ? T_ERR : T_TEXT_DIM, T_PANEL, false);
}

static bool net_event(GuiWindow *w, const GuiEvent *ev, int cx, int cy, int cw, int ch) {
    (void)w;
    (void)cy;
    (void)ch;
    if (ev->type != GUI_EV_MOUSE_DOWN) {
        return false;
    }

    int dhcp_x, fw_x, tx_x, ref_x;
    net_buttons(cw, &dhcp_x, &fw_x, &tx_x, &ref_x);
    if (ui_hit(dhcp_x, NET_BTN_Y, NET_BTN_DHCP_W, NET_BTN_H, ev->x, ev->y)) {
        net_dhcp_restart();
        net_set_msg(false, "DHCP reiniciado");
        gui_invalidate();
        return true;
    }
    if (ui_hit(fw_x, NET_BTN_Y, NET_BTN_FW_W, NET_BTN_H, ev->x, ev->y)) {
        char out[160];
        bool ok = net_wifi_load_firmware(out, sizeof(out));
        net_set_msg(!ok, out);
        gui_invalidate();
        return true;
    }
    if (ui_hit(tx_x, NET_BTN_Y, NET_BTN_TX_W, NET_BTN_H, ev->x, ev->y)) {
        char out[160];
        bool ok = net_wifi_upload_test(out, sizeof(out));
        net_set_msg(!ok, out);
        gui_invalidate();
        return true;
    }
    if (ui_hit(ref_x, NET_BTN_Y, NET_BTN_VER_W, NET_BTN_H, ev->x, ev->y)) {
        net_set_msg(false, "estado atualizado");
        gui_invalidate();
        return true;
    }
    return false;
}

static void net_tick(GuiWindow *w) {
    (void)w;
    net_app.tick_count++;
    if (net_app.tick_count >= 5) {
        net_app.tick_count = 0;
        gui_invalidate();
    }
}

const AppOps app_network_ops = {
    .name = "Rede",
    .id = APP_NETWORK,
    .icon_color = RGB565(84, 158, 255),
    .width = 310,
    .height = 208,
    .create = net_create,
    .destroy = net_destroy,
    .open_arg = NULL,
    .draw = net_draw,
    .event = net_event,
    .tick = net_tick,
};
