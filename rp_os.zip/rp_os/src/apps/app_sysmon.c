#include "app.h"

#include <stdio.h>

#include "pico/stdlib.h"
#include <string.h>

#include "board.h"
#include "gfx.h"
#include "storage.h"
#include "theme.h"
#include "ui.h"
#include "usb_host.h"

#define SYSMON_HISTORY 64

typedef struct {
    uint64_t last_update_us;
    float temp;
    float history[SYSMON_HISTORY];
    int head;
    int count;
    uint32_t heap_free;
    uint32_t uptime;
    uint32_t cpu_mhz;
    uint32_t total_kb[VFS_DRIVE_COUNT];
    uint32_t free_kb[VFS_DRIVE_COUNT];
    bool mounted[VFS_DRIVE_COUNT];
    int usb_kbd;
    int usb_mouse;
    int usb_msc;
} SysmonState;

static SysmonState sysmon;

static void sysmon_update(SysmonState *st) {
    st->temp = board_temp_c();
    st->history[st->head] = st->temp;
    st->head = (st->head + 1) % SYSMON_HISTORY;
    if (st->count < SYSMON_HISTORY) {
        st->count++;
    }

    st->heap_free = board_heap_free();
    st->uptime = board_uptime_s();
    st->cpu_mhz = board_cpu_mhz();

    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        st->mounted[i] = storage_mounted((VfsDrive)i);
        st->total_kb[i] = 0;
        st->free_kb[i] = 0;
        if (st->mounted[i]) {
            vfs_df((VfsDrive)i, &st->total_kb[i], &st->free_kb[i]);
        }
    }

    st->usb_kbd = 0;
    st->usb_mouse = 0;
    st->usb_msc = 0;
    UsbDeviceInfo devices[8];
    int count = usb_devices(devices, 8);
    for (int i = 0; i < count; ++i) {
        if (devices[i].kind & USB_KIND_KEYBOARD) st->usb_kbd++;
        if (devices[i].kind & USB_KIND_MOUSE) st->usb_mouse++;
        if (devices[i].kind & USB_KIND_MSC) st->usb_msc++;
    }

    st->last_update_us = time_us_64();
}

static void draw_usage_bar(int x, int y, int w, int h, unsigned percent) {
    gfx_fill(x, y, w, h, T_TERM_BG);
    gfx_rect_outline(x, y, w, h, T_BORDER);
    int fill_w = (w - 2) * (int)percent / 100;
    if (fill_w < 0) fill_w = 0;
    if (fill_w > w - 2) fill_w = w - 2;
    uint16_t color = T_ACCENT;
    if (percent >= 90) color = T_ERR;
    else if (percent >= 70) color = T_WARN;
    gfx_fill(x + 1, y + 1, fill_w, h - 2, color);
}

static void draw_graph(SysmonState *st, int x, int y, int w, int h) {
    gfx_fill(x, y, w, h, T_TERM_BG);
    gfx_rect_outline(x, y, w, h, T_BORDER);
    gfx_hline(x + 1, y + h / 2, w - 2, T_PANEL_ALT);

    if (st->count < 2) {
        gfx_text(x + 4, y + 4, "coletando...", T_TEXT_FAINT, T_TERM_BG, false);
        return;
    }

    int plot_w = w - 4;
    int plot_h = h - 4;
    int prev_x = 0;
    int prev_y = 0;

    for (int i = 0; i < st->count; ++i) {
        int idx = (st->head - st->count + i + SYSMON_HISTORY) % SYSMON_HISTORY;
        float t = st->history[idx];
        if (t < 10.0f) t = 10.0f;
        if (t > 70.0f) t = 70.0f;
        int px = x + 2 + plot_w * i / (st->count - 1);
        int py = y + 2 + plot_h - (int)((t - 10.0f) * (float)plot_h / 60.0f);
        if (py < y + 1) py = y + 1;
        if (py > y + h - 2) py = y + h - 2;
        if (i > 0) {
            gfx_line(prev_x, prev_y, px, py, T_ACCENT2);
        } else {
            gfx_pixel(px, py, T_ACCENT2);
        }
        prev_x = px;
        prev_y = py;
    }

    char buf[16];
    snprintf(buf, sizeof(buf), "%.1fC", (double)st->temp);
    gfx_text_right(x + w - 3, y + 2, buf, T_TEXT_DIM, T_TERM_BG, false);
}

static void sysmon_draw(GuiWindow *w, int cx, int cy, int cw, int ch) {
    SysmonState *st = w->state;
    gfx_fill(cx, cy, cw, ch, T_PANEL);

    gfx_text(cx + 6, cy + 4, "Monitor do Sistema", T_ACCENT2, T_PANEL, false);

    char buf[64];
    int y = cy + 18;
    snprintf(buf, sizeof(buf), "CPU  %lu MHz x2", (unsigned long)st->cpu_mhz);
    gfx_text(cx + 8, y, buf, T_TEXT, T_PANEL, false);

    y += 12;
    snprintf(buf, sizeof(buf), "RAM  %lu KB livres", (unsigned long)(st->heap_free / 1024U));
    gfx_text(cx + 8, y, buf, T_TEXT, T_PANEL, false);

    y += 12;
    snprintf(buf, sizeof(buf), "Temp %.1f C", (double)st->temp);
    gfx_text(cx + 8, y, buf, st->temp > 60.0f ? T_WARN : T_TEXT, T_PANEL, false);

    y += 12;
    uint32_t h = st->uptime / 3600U;
    uint32_t m = (st->uptime / 60U) % 60U;
    uint32_t s = st->uptime % 60U;
    snprintf(buf, sizeof(buf), "Uptime %02lu:%02lu:%02lu",
             (unsigned long)h, (unsigned long)m, (unsigned long)s);
    gfx_text(cx + 8, y, buf, T_TEXT, T_PANEL, false);

    y += 12;
    snprintf(buf, sizeof(buf), "USB  kbd %d  mouse %d  msc %d",
             st->usb_kbd, st->usb_mouse, st->usb_msc);
    gfx_text(cx + 8, y, buf, T_TEXT, T_PANEL, false);

    gfx_hline(cx + 6, cy + 80, cw - 12, T_BORDER);
    gfx_text(cx + 8, cy + 84, "Armazenamento", T_TEXT_DIM, T_PANEL, false);

    int bar_x = cx + 62;
    int bar_w = cw - 62 - 54;
    if (bar_w < 40) bar_w = 40;

    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        int row_y = cy + 96 + i * 15;
        const char *name = storage_drive_name((VfsDrive)i);
        gfx_text(cx + 8, row_y, name, T_TEXT_DIM, T_PANEL, false);

        if (st->mounted[i]) {
            unsigned percent = 0;
            if (st->total_kb[i] > 0) {
                uint32_t used = st->free_kb[i] < st->total_kb[i]
                                    ? st->total_kb[i] - st->free_kb[i]
                                    : 0;
                percent = (unsigned)(used * 100U / st->total_kb[i]);
            }
            draw_usage_bar(bar_x, row_y, bar_w, 8, percent);
            snprintf(buf, sizeof(buf), "%u%%", percent);
            gfx_text_right(cx + cw - 8, row_y, buf, T_TEXT_DIM, T_PANEL, false);
        } else {
            draw_usage_bar(bar_x, row_y, bar_w, 8, 0);
            gfx_text_right(cx + cw - 8, row_y, "off", T_TEXT_FAINT, T_PANEL, false);
        }
    }

    int graph_y = cy + 146;
    int graph_h = ch - 152;
    if (graph_h < 20) graph_h = 20;
    draw_graph(st, cx + 6, graph_y, cw - 12, graph_h);
}

static void sysmon_tick(GuiWindow *w) {
    SysmonState *st = w->state;
    uint64_t now = time_us_64();
    if (now - st->last_update_us >= 1000000ULL) {
        sysmon_update(st);
        gui_invalidate();
    }
}

static void sysmon_create(GuiWindow *w, const char *arg) {
    (void)arg;
    memset(&sysmon, 0, sizeof(sysmon));
    sysmon_update(&sysmon);
    w->state = &sysmon;
    snprintf(w->title, sizeof(w->title), "Sysmon");
}

const AppOps app_sysmon_ops = {
    .name = "Sysmon",
    .id = APP_SYSMON,
    .icon_color = RGB565(96, 220, 180),
    .width = 310,
    .height = 202,
    .create = sysmon_create,
    .destroy = NULL,
    .open_arg = NULL,
    .draw = sysmon_draw,
    .event = NULL,
    .tick = sysmon_tick,
};
