#include "app.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "gfx.h"
#include "input.h"
#include "storage.h"
#include "theme.h"
#include "ui.h"

#define FILES_MAX 48
#define FILES_HDR_H 14
#define FILES_BTN_H 14
#define FILES_BTN_GAP 2
#define FILES_ROW_H 14
#define FILES_STATUS_H 11
#define FILES_BUTTONS 6

static const char *const files_button_labels[FILES_BUTTONS] = {
    "FLASH", "SD", "USB", "NOVO", "APAGAR", "ABRIR",
};

typedef struct {
    char cwd[128];
    VfsEntry entries[FILES_MAX];
    int count;
    int sel;
    int top;
    char status[64];
    uint16_t status_color;
    bool prompt;
    char prompt_text[32];
    int prompt_len;
    bool confirm;
    uint32_t drive_mask;
} FilesState;

static FilesState files;

static void files_status(FilesState *st, uint16_t color, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vsnprintf(st->status, sizeof(st->status), fmt, args);
    va_end(args);
    st->status_color = color;
}

static void files_join(const char *dir, const char *name, char *out, size_t out_size) {
    if (strcmp(dir, "/") == 0) {
        snprintf(out, out_size, "/%s", name);
    } else {
        snprintf(out, out_size, "%s/%s", dir, name);
    }
}

static uint32_t files_drive_mask(void) {
    uint32_t mask = 0;
    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        if (storage_mounted((VfsDrive)i)) {
            mask |= 1U << i;
        }
    }
    return mask;
}

static void files_refresh(FilesState *st) {
    int count = vfs_list(st->cwd, st->entries, FILES_MAX);
    if (count < 0) {
        char parent[128];
        vfs_dirname(st->cwd, parent, sizeof(parent));
        snprintf(st->cwd, sizeof(st->cwd), "%s", parent);
        count = vfs_list(st->cwd, st->entries, FILES_MAX);
        if (count < 0) {
            snprintf(st->cwd, sizeof(st->cwd), "/");
            count = vfs_list(st->cwd, st->entries, FILES_MAX);
        }
        files_status(st, T_WARN, "pasta indisponivel");
    }

    if (count < 0) {
        count = 0;
    }
    st->count = count;
    if (count == 0) {
        st->sel = 0;
        st->top = 0;
    } else {
        if (st->sel >= count) st->sel = count - 1;
        if (st->sel < 0) st->sel = 0;
        if (st->top > count - 1) st->top = count > 0 ? count - 1 : 0;
    }

    if (st->status[0] == '\0' || st->status_color != T_WARN) {
        files_status(st, T_TEXT_DIM, "%d item(ns)", count);
    }
}

static void files_chdir(FilesState *st, const char *path) {
    if (!vfs_is_dir(path)) {
        files_status(st, T_ERR, "nao e uma pasta");
        return;
    }
    snprintf(st->cwd, sizeof(st->cwd), "%.127s", path);
    st->sel = 0;
    st->top = 0;
    st->status[0] = '\0';
    files_refresh(st);
}

static char *files_selected_path(FilesState *st, char *out, size_t out_size) {
    if (st->count <= 0 || st->sel < 0 || st->sel >= st->count) {
        return NULL;
    }

    VfsEntry *e = &st->entries[st->sel];
    if (strcmp(st->cwd, "/") == 0) {
        if (strcmp(e->name, "Flash") == 0) {
            snprintf(out, out_size, "/flash");
        } else if (strcmp(e->name, "SD") == 0) {
            snprintf(out, out_size, "/sd");
        } else if (strcmp(e->name, "USB") == 0) {
            snprintf(out, out_size, "/usb");
        } else {
            files_join(st->cwd, e->name, out, out_size);
        }
    } else {
        files_join(st->cwd, e->name, out, out_size);
    }
    return out;
}

static void files_open_selected(GuiWindow *w) {
    FilesState *st = w->state;
    if (st->count <= 0) {
        return;
    }

    VfsEntry *e = &st->entries[st->sel];
    char path[200];
    if (files_selected_path(st, path, sizeof(path)) == NULL) {
        return;
    }

    if (e->is_dir) {
        files_chdir(st, path);
        gui_invalidate();
        return;
    }

    if (e->size > APP_EDITOR_MAX_BYTES) {
        files_status(st, T_ERR, "arquivo grande demais");
        gui_invalidate();
        return;
    }

    app_open(APP_EDITOR, path);
}

static void files_go_up(GuiWindow *w) {
    FilesState *st = w->state;
    if (strcmp(st->cwd, "/") == 0) {
        return;
    }
    char parent[128];
    vfs_dirname(st->cwd, parent, sizeof(parent));
    files_chdir(st, parent);
    gui_invalidate();
}

static void files_delete_selected(GuiWindow *w) {
    FilesState *st = w->state;
    if (strcmp(st->cwd, "/") == 0) {
        files_status(st, T_ERR, "nao pode apagar da raiz");
        gui_invalidate();
        return;
    }

    char path[200];
    if (files_selected_path(st, path, sizeof(path)) == NULL) {
        return;
    }

    VfsEntry *e = &st->entries[st->sel];
    bool ok = e->is_dir ? vfs_remove_recursive(path) : vfs_remove(path);
    if (ok) {
        files_status(st, T_OK, "apagado");
    } else {
        files_status(st, T_ERR, "falha ao apagar");
    }
    files_refresh(st);
    gui_invalidate();
}

static void files_create_dir(GuiWindow *w) {
    FilesState *st = w->state;
    if (strcmp(st->cwd, "/") == 0) {
        files_status(st, T_ERR, "nao pode criar na raiz");
        gui_invalidate();
        return;
    }

    char path[200];
    files_join(st->cwd, st->prompt_text, path, sizeof(path));
    if (vfs_mkdir(path)) {
        files_status(st, T_OK, "pasta criada");
    } else {
        files_status(st, T_ERR, "falha ao criar");
    }
    st->prompt = false;
    files_refresh(st);
    gui_invalidate();
}

static int files_button_width(int cw) {
    int width = (cw - 4 - (FILES_BUTTONS - 1) * FILES_BTN_GAP) / FILES_BUTTONS;
    if (width < 20) {
        width = 20;
    }
    return width;
}

static int files_button_at(int cw, int x, int y) {
    int by = FILES_HDR_H + 2;
    if (y < by || y >= by + FILES_BTN_H) {
        return -1;
    }
    int bw = files_button_width(cw);
    int bx = 2;
    for (int i = 0; i < FILES_BUTTONS; ++i) {
        if (x >= bx && x < bx + bw) {
            return i;
        }
        bx += bw + FILES_BTN_GAP;
    }
    return -1;
}

static void files_activate_button(GuiWindow *w, int index) {
    FilesState *st = w->state;
    switch (index) {
        case 0: files_chdir(st, "/flash"); break;
        case 1: files_chdir(st, "/sd"); break;
        case 2: files_chdir(st, "/usb"); break;
        case 3:
            st->prompt = true;
            st->prompt_text[0] = '\0';
            st->prompt_len = 0;
            st->confirm = false;
            break;
        case 4:
            if (st->count > 0) {
                st->confirm = true;
                st->prompt = false;
            }
            break;
        case 5:
            files_open_selected(w);
            break;
        default:
            break;
    }
    gui_invalidate();
}

static int files_visible_rows(int ch) {
    int visible = (ch - FILES_HDR_H - 2 - FILES_BTN_H - 4 - FILES_STATUS_H) / FILES_ROW_H;
    if (visible < 1) {
        visible = 1;
    }
    return visible;
}

static void files_draw(GuiWindow *w, int cx, int cy, int cw, int ch) {
    FilesState *st = w->state;
    gfx_fill(cx, cy, cw, ch, T_PANEL);

    int mx = 0, my = 0;
    gui_mouse_get(&mx, &my);

    gfx_fill(cx, cy, cw, FILES_HDR_H, T_PANEL_ALT);
    gfx_text_clip(cx + 4, cy + 3, cw - 26, st->cwd, T_TEXT, T_PANEL_ALT, false);
    bool refresh_hot = ui_hit(cx + cw - 16, cy + 2, 14, 11, mx, my);
    gfx_fill(cx + cw - 16, cy + 2, 14, 11, refresh_hot ? T_SEL : T_PANEL_HI);
    gfx_rect_outline(cx + cw - 16, cy + 2, 14, 11, T_BORDER);
    gfx_text(cx + cw - 12, cy + 4, "R", T_TEXT, refresh_hot ? T_SEL : T_PANEL_HI, false);

    int bw = files_button_width(cw);
    int bx = cx + 2;
    int by = cy + FILES_HDR_H + 2;
    for (int i = 0; i < FILES_BUTTONS; ++i) {
        bool enabled = true;
        if (i == 1) enabled = storage_mounted(VFS_SD);
        if (i == 2) enabled = storage_mounted(VFS_USB);
        if (i == 4 || i == 5) enabled = st->count > 0;
        bool hot = ui_hit(bx, by, bw, FILES_BTN_H, mx, my);
        ui_button(bx, by, bw, FILES_BTN_H, files_button_labels[i], hot, enabled, T_SEL);
        bx += bw + FILES_BTN_GAP;
    }

    int list_y = by + FILES_BTN_H + 4;
    int visible = files_visible_rows(ch);
    if (st->sel < st->top) st->top = st->sel;
    if (st->sel >= st->top + visible) st->top = st->sel - visible + 1;
    if (st->top < 0) st->top = 0;
    if (st->top > st->count - 1 && st->count > 0) st->top = st->count - 1;

    if (st->count == 0) {
        gfx_text(cx + 8, list_y + 4, "(vazio)", T_TEXT_FAINT, T_PANEL, false);
    }

    for (int row = 0; row < visible; ++row) {
        int index = st->top + row;
        if (index >= st->count) {
            break;
        }
        VfsEntry *e = &st->entries[index];
        int y = list_y + row * FILES_ROW_H;
        if (index == st->sel) {
            gfx_fill(cx + 2, y - 1, cw - 4, FILES_ROW_H, T_SEL);
        }
        uint16_t bg = (index == st->sel) ? T_SEL : T_PANEL;

        if (e->is_dir) {
            gfx_fill(cx + 5, y + 2, 3, 2, T_WARN);
            gfx_fill(cx + 4, y + 3, 7, 5, T_WARN);
            gfx_hline(cx + 5, y + 5, 5, T_PANEL);
        } else {
            gfx_rect_outline(cx + 4, y + 1, 7, 9, T_TEXT_DIM);
            gfx_hline(cx + 6, y + 3, 3, T_TEXT_FAINT);
            gfx_hline(cx + 6, y + 5, 3, T_TEXT_FAINT);
        }

        int name_w = cw - 16 - (e->is_dir ? 4 : 40);
        gfx_text_clip(cx + 14, y + 2, name_w, e->name,
                      e->is_dir ? T_TEXT : T_TEXT_DIM, bg, false);

        if (!e->is_dir) {
            char size[12];
            ui_format_size(e->size, size, sizeof(size));
            gfx_text_right(cx + cw - 5, y + 2, size, T_TEXT_FAINT, bg, false);
        }
    }

    if (st->count > visible) {
        int track_y = list_y;
        int track_h = visible * FILES_ROW_H;
        int thumb_h = track_h * visible / st->count;
        if (thumb_h < 6) thumb_h = 6;
        int max_top = st->count - visible;
        int thumb_y = track_y;
        if (max_top > 0) {
            thumb_y += (track_h - thumb_h) * st->top / max_top;
        }
        gfx_fill(cx + cw - 3, track_y, 2, track_h, T_PANEL_ALT);
        gfx_fill(cx + cw - 3, thumb_y, 2, thumb_h, T_BORDER_HI);
    }

    int status_y = cy + ch - FILES_STATUS_H;
    gfx_fill(cx, status_y, cw, FILES_STATUS_H, T_PANEL_ALT);

    if (st->prompt) {
        char buf[48];
        snprintf(buf, sizeof(buf), "Nome: %s_", st->prompt_text);
        gfx_text_clip(cx + 4, status_y + 2, cw - 8, buf, T_TEXT, T_PANEL_ALT, false);
    } else if (st->confirm) {
        gfx_text_clip(cx + 4, status_y + 2, cw - 8, "Apagar? Enter=sim Esc=nao",
                      T_ERR, T_PANEL_ALT, false);
    } else {
        gfx_text_clip(cx + 4, status_y + 2, cw - 8, st->status, st->status_color,
                      T_PANEL_ALT, false);
    }
}

static bool files_event(GuiWindow *w, const GuiEvent *ev, int cx, int cy, int cw, int ch) {
    FilesState *st = w->state;

    if (ev->type == GUI_EV_WHEEL) {
        int delta = ev->wheel > 0 ? -3 : 3;
        int visible = files_visible_rows(ch);
        st->top += delta;
        int max_top = st->count - visible;
        if (max_top < 0) max_top = 0;
        if (st->top > max_top) st->top = max_top;
        if (st->top < 0) st->top = 0;
        gui_invalidate();
        return true;
    }

    if (ev->type == GUI_EV_MOUSE_DOWN) {
        if (ui_hit(cw - 16, 2, 14, 11, ev->x, ev->y)) {
            st->status[0] = '\0';
            files_refresh(st);
            gui_invalidate();
            return true;
        }

        int button = files_button_at(cw, ev->x, ev->y);
        if (button >= 0) {
            files_activate_button(w, button);
            return true;
        }

        int list_y = FILES_HDR_H + 2 + FILES_BTN_H + 4;
        if (ev->y >= list_y) {
            int row = (ev->y - list_y) / FILES_ROW_H;
            int index = st->top + row;
            if (index >= 0 && index < st->count) {
                if (index == st->sel) {
                    files_open_selected(w);
                } else {
                    st->sel = index;
                    gui_invalidate();
                }
            }
            return true;
        }
        return false;
    }

    if (ev->type != GUI_EV_KEY || !ev->pressed) {
        return false;
    }

    if (st->prompt) {
        switch (ev->key) {
            case INPUT_KEY_ENTER:
                if (st->prompt_len > 0) {
                    files_create_dir(w);
                }
                break;
            case INPUT_KEY_ESC:
                st->prompt = false;
                gui_invalidate();
                break;
            case INPUT_KEY_BACKSPACE:
                if (st->prompt_len > 0) {
                    st->prompt_text[--st->prompt_len] = '\0';
                    gui_invalidate();
                }
                break;
            default:
                if (ev->key >= 32 && ev->key < 127 && st->prompt_len < 30) {
                    st->prompt_text[st->prompt_len++] = (char)ev->key;
                    st->prompt_text[st->prompt_len] = '\0';
                    gui_invalidate();
                }
                break;
        }
        return true;
    }

    if (st->confirm) {
        if (ev->key == INPUT_KEY_ENTER) {
            st->confirm = false;
            files_delete_selected(w);
        } else if (ev->key == INPUT_KEY_ESC) {
            st->confirm = false;
            gui_invalidate();
        }
        return true;
    }

    int visible = files_visible_rows(ch);
    switch (ev->key) {
        case INPUT_KEY_UP:
            if (st->sel > 0) st->sel--;
            break;
        case INPUT_KEY_DOWN:
            if (st->sel + 1 < st->count) st->sel++;
            break;
        case INPUT_KEY_HOME:
            st->sel = 0;
            break;
        case INPUT_KEY_END:
            st->sel = st->count > 0 ? st->count - 1 : 0;
            break;
        case INPUT_KEY_PAGEUP:
            st->sel -= visible;
            if (st->sel < 0) st->sel = 0;
            break;
        case INPUT_KEY_PAGEDOWN:
            st->sel += visible;
            if (st->sel >= st->count) st->sel = st->count > 0 ? st->count - 1 : 0;
            break;
        case INPUT_KEY_ENTER:
            files_open_selected(w);
            break;
        case INPUT_KEY_BACKSPACE:
        case INPUT_KEY_LEFT:
            files_go_up(w);
            break;
        case INPUT_KEY_RIGHT:
            files_open_selected(w);
            break;
        case INPUT_KEY_DELETE:
            if (st->count > 0) {
                st->confirm = true;
            }
            break;
        case INPUT_KEY_F5:
            files_refresh(st);
            break;
        default:
            return false;
    }
    gui_invalidate();
    return true;
}

static void files_tick(GuiWindow *w) {
    FilesState *st = w->state;
    uint32_t mask = files_drive_mask();
    if (mask != st->drive_mask) {
        st->drive_mask = mask;
        files_refresh(st);
        gui_invalidate();
    }
}

static void files_create(GuiWindow *w, const char *arg) {
    memset(&files, 0, sizeof(files));
    snprintf(files.cwd, sizeof(files.cwd), "%s",
             storage_mounted(VFS_FLASH) ? "/flash" : "/");
    files.status_color = T_TEXT_DIM;
    files.drive_mask = files_drive_mask();
    files_refresh(&files);
    w->state = &files;
    snprintf(w->title, sizeof(w->title), "Arquivos");

    if (arg != NULL && arg[0] != '\0') {
        files_chdir(&files, arg);
    }
}

static void files_open_arg(GuiWindow *w, const char *arg) {
    if (arg == NULL || arg[0] == '\0') {
        return;
    }
    files_chdir(w->state, arg);
    gui_invalidate();
}

const AppOps app_files_ops = {
    .name = "Arquivos",
    .id = APP_FILES,
    .icon_color = RGB565(255, 190, 80),
    .width = 310,
    .height = 198,
    .create = files_create,
    .destroy = NULL,
    .open_arg = files_open_arg,
    .draw = files_draw,
    .event = files_event,
    .tick = files_tick,
};
