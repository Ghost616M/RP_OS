#include "storage.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "ff.h"
#include "flash_disk.h"
#include "pico/stdlib.h"
#include "sd_spi.h"
#include "usb_host.h"

#define FAT_ATTR_VOLUME 0x08

static FATFS fatfs[VFS_DRIVE_COUNT];
static bool drive_mounted[VFS_DRIVE_COUNT];
static char drive_status[VFS_DRIVE_COUNT][24];

static uint32_t df_total_kb[VFS_DRIVE_COUNT];
static uint32_t df_free_kb[VFS_DRIVE_COUNT];
static uint64_t df_stamp_us[VFS_DRIVE_COUNT];
static bool df_valid[VFS_DRIVE_COUNT];

static volatile bool usb_mount_request;
static volatile bool usb_unmount_request;
static uint8_t usb_mount_addr;

static uint64_t next_sd_attempt_us;
static uint64_t next_usb_attempt_us;
static uint8_t recursive_depth;

static const char *const mount_paths[VFS_DRIVE_COUNT] = {"/flash", "/sd", "/usb"};
static const char *const drive_names[VFS_DRIVE_COUNT] = {"Flash", "SD", "USB"};
static const char *const drive_roots[VFS_DRIVE_COUNT] = {"0:", "1:", "2:"};

void storage_refresh(void) {
    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        df_valid[i] = false;
    }
}

static void set_status(VfsDrive drive, const char *status) {
    snprintf(drive_status[drive], sizeof(drive_status[drive]), "%s", status);
}

const char *storage_mount_path(VfsDrive drive) {
    return mount_paths[drive];
}

const char *storage_drive_name(VfsDrive drive) {
    return drive_names[drive];
}

const char *storage_drive_status(VfsDrive drive) {
    return drive_status[drive];
}

bool storage_mounted(VfsDrive drive) {
    return drive < VFS_DRIVE_COUNT && drive_mounted[drive];
}

static bool path_to_drive(const char *path, VfsDrive *drive, const char **rest) {
    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        const char *mp = mount_paths[i];
        size_t len = strlen(mp);
        if (strncmp(path, mp, len) == 0 && (path[len] == '\0' || path[len] == '/')) {
            *drive = (VfsDrive)i;
            const char *r = path + len;
            while (*r == '/') r++;
            *rest = r;
            return true;
        }
    }
    return false;
}

static bool make_fat_path(const char *path, char *out, size_t out_size, VfsDrive *drive) {
    if (path == NULL || path[0] != '/' || out_size < 4) {
        return false;
    }
    const char *rest;
    if (!path_to_drive(path, drive, &rest)) {
        return false;
    }
    if (*rest == '\0') {
        snprintf(out, out_size, "%d:/", (int)*drive);
    } else {
        snprintf(out, out_size, "%d:/%s", (int)*drive, rest);
    }
    return true;
}

bool vfs_normalize(const char *cwd, const char *input, char *out, size_t out_size) {
    if (out == NULL || out_size < 2) {
        return false;
    }
    if (cwd == NULL || cwd[0] == '\0') {
        cwd = "/";
    }
    if (input == NULL || input[0] == '\0') {
        input = cwd;
    }

    char joined[256];
    if (input[0] == '/') {
        snprintf(joined, sizeof(joined), "%s", input);
    } else {
        snprintf(joined, sizeof(joined), "%s/%s", cwd, input);
    }

    out[0] = '/';
    size_t out_len = 1;
    const char *p = joined;

    while (*p) {
        while (*p == '/') p++;
        if (*p == '\0') break;
        const char *start = p;
        while (*p && *p != '/') p++;
        size_t part_len = (size_t)(p - start);

        if (part_len == 1 && start[0] == '.') {
            continue;
        }
        if (part_len == 2 && start[0] == '.' && start[1] == '.') {
            if (out_len > 1) {
                while (out_len > 1 && out[out_len - 1] != '/') out_len--;
                if (out_len > 1) out_len--;
            }
            continue;
        }

        if (out_len > 1) {
            if (out_len + 1 >= out_size) break;
            out[out_len++] = '/';
        }
        for (size_t i = 0; i < part_len && out_len + 1 < out_size; ++i) {
            out[out_len++] = start[i];
        }
    }
    out[out_len] = '\0';
    return true;
}

void vfs_basename(const char *path, char *out, size_t out_size) {
    if (out == NULL || out_size == 0) return;
    if (path == NULL || path[0] == '\0' || strcmp(path, "/") == 0) {
        snprintf(out, out_size, "/");
        return;
    }
    const char *slash = strrchr(path, '/');
    const char *name = slash ? slash + 1 : path;
    if (*name == '\0') {
        snprintf(out, out_size, "/");
        return;
    }
    snprintf(out, out_size, "%s", name);
}

void vfs_dirname(const char *path, char *out, size_t out_size) {
    if (out == NULL || out_size < 2) return;
    if (path == NULL || path[0] != '/' || strcmp(path, "/") == 0) {
        snprintf(out, out_size, "/");
        return;
    }
    const char *slash = strrchr(path, '/');
    if (slash == NULL || slash == path) {
        snprintf(out, out_size, "/");
        return;
    }
    size_t len = (size_t)(slash - path);
    if (len >= out_size) len = out_size - 1;
    memcpy(out, path, len);
    out[len] = '\0';
}

bool vfs_stat(const char *path, VfsEntry *entry) {
    if (path == NULL || entry == NULL) {
        return false;
    }
    memset(entry, 0, sizeof(*entry));

    if (strcmp(path, "/") == 0) {
        snprintf(entry->name, sizeof(entry->name), "/");
        entry->is_dir = true;
        return true;
    }

    VfsDrive drive;
    const char *rest;
    if (path_to_drive(path, &drive, &rest)) {
        vfs_basename(path, entry->name, sizeof(entry->name));
        entry->is_dir = true;
        if (*rest == '\0') {
            return drive_mounted[drive];
        }
    }

    char fatpath[256];
    if (!make_fat_path(path, fatpath, sizeof(fatpath), &drive)) {
        return false;
    }
    if (!drive_mounted[drive]) {
        return false;
    }

    FILINFO info;
    FRESULT fr = f_stat(fatpath, &info);
    if (fr != FR_OK) {
        return false;
    }

    vfs_basename(path, entry->name, sizeof(entry->name));
    entry->size = (uint32_t)info.fsize;
    entry->is_dir = (info.fattrib & AM_DIR) != 0;
    return true;
}

bool vfs_is_dir(const char *path) {
    VfsEntry entry;
    return vfs_stat(path, &entry) && entry.is_dir;
}

bool vfs_exists(const char *path) {
    VfsEntry entry;
    return vfs_stat(path, &entry);
}

static int entry_compare(const void *a, const void *b) {
    const VfsEntry *ea = (const VfsEntry *)a;
    const VfsEntry *eb = (const VfsEntry *)b;
    if (ea->is_dir != eb->is_dir) {
        return ea->is_dir ? -1 : 1;
    }
    return strcasecmp(ea->name, eb->name);
}

int vfs_list(const char *path, VfsEntry *entries, int max_entries) {
    if (path == NULL || entries == NULL || max_entries <= 0) {
        return 0;
    }

    if (strcmp(path, "/") == 0) {
        int count = VFS_DRIVE_COUNT < max_entries ? VFS_DRIVE_COUNT : max_entries;
        for (int i = 0; i < count; ++i) {
            memset(&entries[i], 0, sizeof(entries[i]));
            snprintf(entries[i].name, sizeof(entries[i].name), "%s", drive_names[i]);
            entries[i].is_dir = true;
        }
        return count;
    }

    VfsDrive drive;
    char fatpath[256];
    if (!make_fat_path(path, fatpath, sizeof(fatpath), &drive) || !drive_mounted[drive]) {
        return -1;
    }

    DIR dir;
    FRESULT fr = f_opendir(&dir, fatpath);
    if (fr != FR_OK) {
        return -1;
    }

    int count = 0;
    FILINFO info;
    while (count < max_entries) {
        fr = f_readdir(&dir, &info);
        if (fr != FR_OK || info.fname[0] == '\0') {
            break;
        }
        if (info.fattrib & FAT_ATTR_VOLUME) {
            continue;
        }
        memset(&entries[count], 0, sizeof(entries[count]));
        snprintf(entries[count].name, sizeof(entries[count].name), "%.47s", info.fname);
        entries[count].size = (uint32_t)info.fsize;
        entries[count].is_dir = (info.fattrib & AM_DIR) != 0;
        count++;
    }
    f_closedir(&dir);

    qsort(entries, (size_t)count, sizeof(VfsEntry), entry_compare);
    return count;
}

bool vfs_read_file(const char *path, char *buffer, size_t max_size, size_t *out_size) {
    if (path == NULL || buffer == NULL || max_size == 0 || out_size == NULL) {
        return false;
    }
    *out_size = 0;

    VfsDrive drive;
    char fatpath[256];
    if (!make_fat_path(path, fatpath, sizeof(fatpath), &drive) || !drive_mounted[drive]) {
        return false;
    }

    FIL file;
    FRESULT fr = f_open(&file, fatpath, FA_READ);
    if (fr != FR_OK) {
        return false;
    }

    size_t limit = max_size - 1;
    FSIZE_t file_size = f_size(&file);
    UINT to_read = (UINT)(file_size < limit ? file_size : limit);
    UINT br = 0;
    fr = f_read(&file, buffer, to_read, &br);
    f_close(&file);
    if (fr != FR_OK) {
        return false;
    }

    buffer[br] = '\0';
    *out_size = br;
    return true;
}

bool vfs_read_file_at(const char *path, uint32_t offset, char *buffer, size_t max_size, size_t *out_size) {
    if (path == NULL || buffer == NULL || max_size == 0 || out_size == NULL) {
        return false;
    }
    *out_size = 0;

    VfsDrive drive;
    char fatpath[256];
    if (!make_fat_path(path, fatpath, sizeof(fatpath), &drive) || !drive_mounted[drive]) {
        return false;
    }

    FIL file;
    FRESULT fr = f_open(&file, fatpath, FA_READ);
    if (fr != FR_OK) {
        return false;
    }

    FSIZE_t file_size = f_size(&file);
    if ((FSIZE_t)offset > file_size) {
        f_close(&file);
        return false;
    }
    fr = f_lseek(&file, (FSIZE_t)offset);
    if (fr != FR_OK) {
        f_close(&file);
        return false;
    }

    FSIZE_t remaining = file_size - (FSIZE_t)offset;
    UINT to_read = (UINT)(remaining < (FSIZE_t)max_size ? remaining : (FSIZE_t)max_size);
    UINT br = 0;
    fr = f_read(&file, buffer, to_read, &br);
    f_close(&file);
    if (fr != FR_OK) {
        return false;
    }
    *out_size = br;
    return true;
}

bool vfs_write_file(const char *path, const char *data, size_t size) {
    if (path == NULL || (data == NULL && size > 0)) {
        return false;
    }

    VfsDrive drive;
    char fatpath[256];
    if (!make_fat_path(path, fatpath, sizeof(fatpath), &drive) || !drive_mounted[drive]) {
        return false;
    }

    FIL file;
    FRESULT fr = f_open(&file, fatpath, FA_WRITE | FA_CREATE_ALWAYS);
    if (fr != FR_OK) {
        return false;
    }

    UINT bw = 0;
    fr = f_write(&file, data, (UINT)size, &bw);
    if (fr == FR_OK) {
        f_sync(&file);
    }
    f_close(&file);

    storage_refresh();
    return fr == FR_OK && bw == (UINT)size;
}

bool vfs_copy_file(const char *from, const char *to) {
    if (from == NULL || to == NULL) {
        return false;
    }

    VfsDrive from_drive;
    VfsDrive to_drive;
    char from_path[256];
    char to_path[256];
    if (!make_fat_path(from, from_path, sizeof(from_path), &from_drive) ||
        !make_fat_path(to, to_path, sizeof(to_path), &to_drive)) {
        return false;
    }
    if (!drive_mounted[from_drive] || !drive_mounted[to_drive]) {
        return false;
    }

    FIL src;
    if (f_open(&src, from_path, FA_READ) != FR_OK) {
        return false;
    }

    FIL dst;
    if (f_open(&dst, to_path, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) {
        f_close(&src);
        return false;
    }

    uint8_t buffer[512];
    bool ok = true;
    while (true) {
        UINT br = 0;
        if (f_read(&src, buffer, sizeof(buffer), &br) != FR_OK) {
            ok = false;
            break;
        }
        if (br == 0) {
            break;
        }
        UINT bw = 0;
        if (f_write(&dst, buffer, br, &bw) != FR_OK || bw != br) {
            ok = false;
            break;
        }
    }

    f_close(&dst);
    f_close(&src);
    storage_refresh();
    return ok;
}

bool vfs_mkdir(const char *path) {
    VfsDrive drive;
    char fatpath[256];
    if (path == NULL || !make_fat_path(path, fatpath, sizeof(fatpath), &drive) || !drive_mounted[drive]) {
        return false;
    }
    FRESULT fr = f_mkdir(fatpath);
    storage_refresh();
    return fr == FR_OK;
}

bool vfs_remove(const char *path) {
    VfsDrive drive;
    char fatpath[256];
    if (path == NULL || !make_fat_path(path, fatpath, sizeof(fatpath), &drive) || !drive_mounted[drive]) {
        return false;
    }
    FRESULT fr = f_unlink(fatpath);
    storage_refresh();
    return fr == FR_OK;
}

bool vfs_remove_recursive(const char *path) {
    if (recursive_depth >= 6) {
        return false;
    }
    if (!vfs_is_dir(path)) {
        return vfs_remove(path);
    }

    recursive_depth++;
    bool ok = true;
    char child[256];

    while (ok) {
        VfsEntry entries[8];
        int count = vfs_list(path, entries, 8);
        if (count < 0) {
            ok = false;
            break;
        }
        if (count == 0) {
            break;
        }
        for (int i = 0; i < count; ++i) {
            snprintf(child, sizeof(child), "%.127s%s%.127s", path, strcmp(path, "/") == 0 ? "" : "/", entries[i].name);
            if (entries[i].is_dir) {
                if (!vfs_remove_recursive(child)) {
                    ok = false;
                    break;
                }
            } else if (!vfs_remove(child)) {
                ok = false;
                break;
            }
        }
        if (count < 8) {
            break;
        }
    }

    if (ok) {
        ok = vfs_remove(path);
    }
    recursive_depth--;
    return ok;
}

bool vfs_rename(const char *from, const char *to) {
    if (from == NULL || to == NULL) {
        return false;
    }
    VfsDrive from_drive;
    VfsDrive to_drive;
    char from_path[256];
    char to_path[256];
    if (!make_fat_path(from, from_path, sizeof(from_path), &from_drive) ||
        !make_fat_path(to, to_path, sizeof(to_path), &to_drive)) {
        return false;
    }
    if (from_drive != to_drive || !drive_mounted[from_drive]) {
        return false;
    }
    FRESULT fr = f_rename(from_path, to_path);
    storage_refresh();
    return fr == FR_OK;
}

bool vfs_df(VfsDrive drive, uint32_t *total_kb, uint32_t *free_kb) {
    if (drive >= VFS_DRIVE_COUNT || !drive_mounted[drive]) {
        return false;
    }

    uint64_t now = time_us_64();
    if (!df_valid[drive] || now - df_stamp_us[drive] > 15000000ULL) {
        DWORD free_clusters = 0;
        FATFS *fs = NULL;
        FRESULT fr = f_getfree(drive_roots[drive], &free_clusters, &fs);
        if (fr != FR_OK || fs == NULL) {
            return false;
        }
        uint32_t cluster_sectors = fs->csize;
        uint32_t total_clusters = fs->n_fatent - 2;
        df_total_kb[drive] = total_clusters * cluster_sectors / 2;
        df_free_kb[drive] = free_clusters * cluster_sectors / 2;
        df_stamp_us[drive] = now;
        df_valid[drive] = true;
    }

    if (total_kb) *total_kb = df_total_kb[drive];
    if (free_kb) *free_kb = df_free_kb[drive];
    return true;
}

void storage_info(VfsDrive drive, VfsDriveInfo *info) {
    if (info == NULL) {
        return;
    }
    memset(info, 0, sizeof(*info));
    info->mounted = drive_mounted[drive];
    snprintf(info->status, sizeof(info->status), "%s", drive_status[drive]);
    if (info->mounted) {
        vfs_df(drive, &info->total_kb, &info->free_kb);
    }
}

void storage_usb_mounted(uint8_t dev_addr) {
    usb_mount_addr = dev_addr;
    usb_mount_request = true;
    usb_unmount_request = false;
}

void storage_usb_unmounted(uint8_t dev_addr) {
    if (usb_mount_addr != 0 && dev_addr != usb_mount_addr) {
        return;
    }
    usb_mount_addr = 0;
    usb_unmount_request = true;
    usb_mount_request = false;
}

static void format_or_mount_flash(void) {
    if (!flash_disk_has_fs()) {
        static uint8_t work[512] __attribute__((aligned(4)));
        MKFS_PARM options = {
            .fmt = FM_FAT,
            .n_fat = 1,
            .align = 0,
            .n_root = 64,
            .au_size = 0,
        };
        f_mkfs("0:", &options, work, sizeof(work));
        flash_disk_flush();
    }

    FRESULT fr = f_mount(&fatfs[VFS_FLASH], "0:", 1);
    if (fr == FR_OK) {
        drive_mounted[VFS_FLASH] = true;
        set_status(VFS_FLASH, "montado");
        flash_disk_flush();

        if (!vfs_exists("/flash/readme.txt")) {
            static const char readme[] =
                "rp_os - armazenamento interno\n"
                "\n"
                "Este volume FAT fica na flash do RP2350.\n"
                "Use o Terminal para navegar e editar.\n"
                "Comandos: help, ls, cd, cat, df, sysinfo\n";
            vfs_write_file("/flash/readme.txt", readme, sizeof(readme) - 1);
        }
    } else {
        drive_mounted[VFS_FLASH] = false;
        set_status(VFS_FLASH, "erro de montagem");
    }
}

void storage_init(void) {
    for (int i = 0; i < VFS_DRIVE_COUNT; ++i) {
        drive_mounted[i] = false;
        df_valid[i] = false;
        set_status((VfsDrive)i, "nao montado");
    }

    flash_disk_init();
    usb_mount_request = false;
    usb_unmount_request = false;
    usb_mount_addr = 0;
    next_sd_attempt_us = time_us_64() + 300000ULL;
    next_usb_attempt_us = time_us_64() + 500000ULL;
    recursive_depth = 0;

    format_or_mount_flash();
}

void storage_task(void) {
    uint64_t now = time_us_64();

    if (usb_unmount_request) {
        usb_unmount_request = false;
        if (drive_mounted[VFS_USB]) {
            f_mount(NULL, "2:", 0);
            drive_mounted[VFS_USB] = false;
            set_status(VFS_USB, "desconectado");
            df_valid[VFS_USB] = false;
            storage_refresh();
        }
        next_usb_attempt_us = now;
    }

    if (usb_mount_request) {
        usb_mount_request = false;
        if (drive_mounted[VFS_USB]) {
            f_mount(NULL, "2:", 0);
            drive_mounted[VFS_USB] = false;
            set_status(VFS_USB, "remontando");
            df_valid[VFS_USB] = false;
            storage_refresh();
        }
        next_usb_attempt_us = now;
    }

    if (!drive_mounted[VFS_USB] && now >= next_usb_attempt_us) {
        next_usb_attempt_us = now + 2000000ULL;
        if (usb_msc_probe()) {
            FRESULT fr = f_mount(&fatfs[VFS_USB], "2:", 1);
            if (fr == FR_OK) {
                drive_mounted[VFS_USB] = true;
                set_status(VFS_USB, "montado");
            } else {
                f_mount(NULL, "2:", 0);
                set_status(VFS_USB, "sem FAT");
                next_usb_attempt_us = now + 5000000ULL;
            }
            df_valid[VFS_USB] = false;
            storage_refresh();
        }
    }

    if (!drive_mounted[VFS_SD] && now >= next_sd_attempt_us) {
        next_sd_attempt_us = now + 5000000ULL;
        if (sd_init()) {
            FRESULT fr = f_mount(&fatfs[VFS_SD], "1:", 1);
            if (fr == FR_OK) {
                drive_mounted[VFS_SD] = true;
                set_status(VFS_SD, "montado");
            } else {
                f_mount(NULL, "1:", 0);
                set_status(VFS_SD, "sem FAT");
                next_sd_attempt_us = now + 30000000ULL;
            }
            df_valid[VFS_SD] = false;
        } else {
            set_status(VFS_SD, "sem cartao");
        }
    }
}
