#include "net_stack.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ath9k_wifi.h"
#include "lwip/dhcp.h"
#include "lwip/etharp.h"
#include "lwip/icmp.h"
#include "lwip/init.h"
#include "lwip/inet_chksum.h"
#include "lwip/ip4_addr.h"
#include "lwip/netif.h"
#include "lwip/pbuf.h"
#include "lwip/raw.h"
#include "lwip/timeouts.h"
#include "netif/ethernet.h"
#include "pico/stdlib.h"
#include "storage.h"
#include "usb_host.h"
#include "usb_net.h"

#define ATHEROS_VID 0x0cf3U
#define WIFI_FW_PATH "/sd/firmware/ath9k.fw"

static struct netif netif_usb;
static bool netif_added;
static bool link_up;
static uint8_t net_mac[6];
static uint32_t rx_frames;
static uint32_t tx_frames;
static bool ping_ready;

static struct netif netif_wifi;
static bool wifi_netif_added;
static bool wifi_link_up;
static uint8_t wifi_mac[6];
static char wifi_ssid[33];
static uint32_t wifi_rx_frames;
static uint32_t wifi_tx_frames;

static bool wifi_present;
static uint8_t wifi_addr;
static uint16_t wifi_vid;
static uint16_t wifi_pid;
static char wifi_status[72] = "nenhum adaptador Atheros";
static bool fw_loaded;
static uint32_t fw_size;

uint32_t sys_now(void) {
    return (uint32_t)(time_us_64() / 1000ULL);
}

static err_t linkoutput_cb(struct netif *n, struct pbuf *p) {
    (void)n;
    if (p == NULL || p->tot_len == 0 || p->tot_len > 1514) {
        return ERR_IF;
    }
    uint8_t frame[1514];
    uint16_t len = (uint16_t)p->tot_len;
    pbuf_copy_partial(p, frame, len, 0);
    if (!usb_net_send(frame, len)) {
        return ERR_IF;
    }
    tx_frames++;
    return ERR_OK;
}

static err_t wifi_linkoutput_cb(struct netif *n, struct pbuf *p) {
    (void)n;
    if (p == NULL || p->tot_len == 0 || p->tot_len > 1514) {
        return ERR_IF;
    }
    uint8_t frame[1514];
    uint16_t len = (uint16_t)p->tot_len;
    pbuf_copy_partial(p, frame, len, 0);
    if (!ath9k_wifi_send(frame, len)) {
        return ERR_IF;
    }
    wifi_tx_frames++;
    return ERR_OK;
}

static err_t netif_init_cb(struct netif *n) {
    n->mtu = 1500;
    n->hwaddr_len = 6;
    memcpy(n->hwaddr, net_mac, 6);
    n->flags = NETIF_FLAG_BROADCAST | NETIF_FLAG_ETHARP;
    n->hostname = "rp_os";
    n->output = etharp_output;
    n->linkoutput = linkoutput_cb;
    return ERR_OK;
}

static err_t wifi_netif_init_cb(struct netif *n) {
    n->mtu = 1500;
    n->hwaddr_len = 6;
    memcpy(n->hwaddr, wifi_mac, 6);
    n->flags = NETIF_FLAG_BROADCAST | NETIF_FLAG_ETHARP;
    n->hostname = "rp_os";
    n->output = etharp_output;
    n->linkoutput = wifi_linkoutput_cb;
    return ERR_OK;
}

static struct netif *active_netif(void) {
    if (wifi_link_up && wifi_netif_added) {
        return &netif_wifi;
    }
    if (netif_added) {
        return &netif_usb;
    }
    return NULL;
}

void net_stack_init(void) {
    lwip_init();
    netif_added = false;
    link_up = false;
    rx_frames = 0;
    tx_frames = 0;
    memset(net_mac, 0, sizeof(net_mac));
    ping_ready = false;
    wifi_netif_added = false;
    wifi_link_up = false;
    memset(wifi_mac, 0, sizeof(wifi_mac));
    memset(wifi_ssid, 0, sizeof(wifi_ssid));
    wifi_rx_frames = 0;
    wifi_tx_frames = 0;
    ath9k_wifi_init();
    ath9k_wifi_set_rx_cb(net_wifi_input);
}

static void copy_ip(char *out, size_t out_size, const ip4_addr_t *addr) {
    if (ip4_addr_isany(addr)) {
        snprintf(out, out_size, "-");
    } else {
        ip4addr_ntoa_r(addr, out, (int)out_size);
    }
}

void net_usb_link_up(const uint8_t mac[6]) {
    bool was_up = link_up;
    bool mac_changed = memcmp(net_mac, mac, 6) != 0;
    memcpy(net_mac, mac, 6);

    if (!netif_added) {
        ip4_addr_t ip, mask, gw;
        ip4_addr_set_zero(&ip);
        ip4_addr_set_zero(&mask);
        ip4_addr_set_zero(&gw);
        if (netif_add(&netif_usb, &ip, &mask, &gw, NULL, netif_init_cb, ethernet_input) == NULL) {
            return;
        }
        netif_set_default(&netif_usb);
        netif_added = true;
    } else if (mac_changed) {
        dhcp_stop(&netif_usb);
        memcpy(netif_usb.hwaddr, net_mac, 6);
    }

    netif_set_up(&netif_usb);
    netif_set_link_up(&netif_usb);
    if (!was_up || !dhcp_supplied_address(&netif_usb) || mac_changed) {
        dhcp_start(&netif_usb);
    }
    link_up = true;
}

void net_dhcp_restart(void) {
    struct netif *n = active_netif();
    if (n == NULL) {
        return;
    }
    dhcp_stop(n);
    dhcp_start(n);
}

void net_usb_link_down(void) {
    if (netif_added) {
        dhcp_stop(&netif_usb);
        netif_set_link_down(&netif_usb);
    }
    link_up = false;
}

void net_usb_input(const uint8_t *frame, uint16_t len) {
    if (!netif_added || len < 14) {
        return;
    }
    struct pbuf *p = pbuf_alloc(PBUF_RAW, len, PBUF_POOL);
    if (p == NULL) {
        return;
    }
    if (pbuf_take(p, frame, len) != ERR_OK) {
        pbuf_free(p);
        return;
    }
    if (netif_usb.input(p, &netif_usb) != ERR_OK) {
        pbuf_free(p);
    }
    rx_frames++;
}

void net_stack_task(void) {
    ath9k_wifi_task();
    usb_net_task();

    AthWifiInfo info;
    ath9k_wifi_info(&info);
    if (info.connected && info.mac_valid && !wifi_link_up) {
        net_wifi_link_up(info.mac, info.ssid);
    } else if (!info.connected && wifi_link_up) {
        net_wifi_link_down();
    }

    if (netif_added || wifi_netif_added) {
        sys_check_timeouts();
    }
}

void net_status_get(NetStatus *status) {
    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));

    AthWifiInfo winfo;
    ath9k_wifi_info(&winfo);

    struct netif *n = active_netif();
    if (n == &netif_wifi) {
        status->link_up = wifi_link_up;
        snprintf(status->ifname, sizeof(status->ifname), "wlan0");
        status->rx_frames = wifi_rx_frames;
        status->tx_frames = wifi_tx_frames;
        memcpy(status->mac, wifi_mac, 6);
    } else {
        status->link_up = link_up;
        snprintf(status->ifname, sizeof(status->ifname), "ecm0");
        status->rx_frames = rx_frames;
        status->tx_frames = tx_frames;
        memcpy(status->mac, net_mac, 6);
    }

    if (n != NULL) {
        status->dhcp_running = netif_dhcp_data(n) != NULL;
        status->dhcp_bound = dhcp_supplied_address(n) != 0;
        copy_ip(status->ip, sizeof(status->ip), netif_ip4_addr(n));
        copy_ip(status->mask, sizeof(status->mask), netif_ip4_netmask(n));
        copy_ip(status->gw, sizeof(status->gw), netif_ip4_gw(n));
    } else {
        snprintf(status->ip, sizeof(status->ip), "-");
        snprintf(status->mask, sizeof(status->mask), "-");
        snprintf(status->gw, sizeof(status->gw), "-");
    }

    status->wifi_present = wifi_present || winfo.present;
    status->wifi_booted = winfo.booted;
    status->wifi_connected = winfo.connected;
    status->wifi_mac_valid = winfo.mac_valid;
    memcpy(status->wifi_mac, winfo.mac, 6);
    snprintf(status->wifi_ssid, sizeof(status->wifi_ssid), "%s", winfo.ssid);
    status->wifi_addr = wifi_addr;
    status->wifi_vid = wifi_vid;
    status->wifi_pid = wifi_pid;
    status->fw_loaded = fw_loaded;
    status->fw_size = fw_size;
    snprintf(status->wifi_status, sizeof(status->wifi_status), "%.71s",
             winfo.status[0] != '\0' ? winfo.status : wifi_status);

    UsbDeviceInfo devices[8];
    int count = usb_devices(devices, 8);
    status->usb_dev_count = 0;
    for (int i = 0; i < count && status->usb_dev_count < 8; ++i) {
        NetUsbDev *dev = &status->usb_devs[status->usb_dev_count++];
        dev->addr = devices[i].addr;
        dev->vid = devices[i].vid;
        dev->pid = devices[i].pid;
    }
}

void net_wifi_usb_mounted(uint8_t addr, uint16_t vid, uint16_t pid) {
    if (vid != ATHEROS_VID) {
        return;
    }
    ath9k_wifi_mounted(addr, vid, pid);
    wifi_present = true;
    wifi_addr = addr;
    wifi_vid = vid;
    wifi_pid = pid;
    snprintf(wifi_status, sizeof(wifi_status),
             "Atheros %04x:%04x detectado (wifi load)", vid, pid);
}

void net_wifi_usb_unmounted(uint8_t addr) {
    ath9k_wifi_unmounted(addr);
    if (wifi_present && wifi_addr == addr) {
        wifi_present = false;
        wifi_addr = 0;
        fw_loaded = false;
        fw_size = 0;
    }
    if (wifi_link_up) {
        net_wifi_link_down();
    }
    snprintf(wifi_status, sizeof(wifi_status), "adaptador removido");
}

bool net_wifi_load_firmware(char *out, size_t out_size) {
    if (out == NULL || out_size == 0) {
        return false;
    }
    out[0] = '\0';
    if (!wifi_present) {
        snprintf(out, out_size, "nenhum adaptador Atheros conectado\n");
        return false;
    }
    if (!ath9k_wifi_boot(out, out_size)) {
        snprintf(wifi_status, sizeof(wifi_status), "%s", out);
        return false;
    }

    AthWifiInfo info;
    ath9k_wifi_info(&info);
    fw_loaded = true;
    fw_size = info.fw_size;
    snprintf(wifi_status, sizeof(wifi_status), "%.71s", info.status);
    return true;
}

void net_wifi_link_up(const uint8_t mac[6], const char *ssid) {
    if (mac == NULL) {
        return;
    }
    bool mac_changed = memcmp(wifi_mac, mac, 6) != 0;
    memcpy(wifi_mac, mac, 6);
    if (ssid != NULL) {
        snprintf(wifi_ssid, sizeof(wifi_ssid), "%s", ssid);
    }

    if (!wifi_netif_added) {
        ip4_addr_t ip, mask, gw;
        ip4_addr_set_zero(&ip);
        ip4_addr_set_zero(&mask);
        ip4_addr_set_zero(&gw);
        if (netif_add(&netif_wifi, &ip, &mask, &gw, NULL, wifi_netif_init_cb, ethernet_input) == NULL) {
            return;
        }
        wifi_netif_added = true;
    } else if (mac_changed) {
        dhcp_stop(&netif_wifi);
        memcpy(netif_wifi.hwaddr, wifi_mac, 6);
    }

    netif_set_default(&netif_wifi);
    netif_set_up(&netif_wifi);
    netif_set_link_up(&netif_wifi);
    if (!wifi_link_up || !dhcp_supplied_address(&netif_wifi) || mac_changed) {
        dhcp_start(&netif_wifi);
    }
    wifi_link_up = true;
    snprintf(wifi_status, sizeof(wifi_status), "conectado a %s", wifi_ssid);
}

void net_wifi_link_down(void) {
    if (wifi_netif_added) {
        dhcp_stop(&netif_wifi);
        netif_set_link_down(&netif_wifi);
    }
    if (netif_added) {
        netif_set_default(&netif_usb);
    }
    wifi_link_up = false;
    memset(wifi_ssid, 0, sizeof(wifi_ssid));
    snprintf(wifi_status, sizeof(wifi_status), "desconectado");
}

void net_wifi_input(const uint8_t *frame, uint16_t len) {
    if (frame == NULL || len < 14 || !wifi_netif_added || !wifi_link_up) {
        return;
    }
    struct pbuf *p = pbuf_alloc(PBUF_RAW, len, PBUF_POOL);
    if (p == NULL) {
        return;
    }
    if (pbuf_take(p, frame, len) != ERR_OK) {
        pbuf_free(p);
        return;
    }
    if (netif_wifi.input(p, &netif_wifi) != ERR_OK) {
        pbuf_free(p);
    }
    wifi_rx_frames++;
}

bool net_wifi_scan(NetWifiNetwork *out, int max, int *count, char *msg, size_t msg_size) {
    AthWifiNetwork nets[16];
    int found = 0;
    int limit = max;
    if (limit < 0) {
        limit = 0;
    }
    if (limit > 16) {
        limit = 16;
    }
    bool ok = ath9k_wifi_scan(nets, limit, &found, msg, msg_size);
    if (count != NULL) {
        *count = found;
    }
    if (ok && out != NULL) {
        for (int i = 0; i < found && i < limit; ++i) {
            snprintf(out[i].ssid, sizeof(out[i].ssid), "%.32s", nets[i].ssid);
            out[i].rssi = nets[i].rssi;
            out[i].channel = nets[i].channel;
            out[i].secure = nets[i].secure;
        }
    }
    return ok;
}

bool net_wifi_connect(const char *ssid, const char *password, char *out, size_t out_size) {
    bool ok = ath9k_wifi_connect(ssid, password, out, out_size);
    if (ok) {
        AthWifiInfo info;
        ath9k_wifi_info(&info);
        if (info.mac_valid) {
            net_wifi_link_up(info.mac, ssid);
        }
    }
    return ok;
}

bool net_wifi_upload_test(char *out, size_t out_size) {
    if (out == NULL || out_size == 0) {
        return false;
    }
    out[0] = '\0';
    if (!wifi_present) {
        snprintf(out, out_size, "nenhum adaptador Atheros conectado\n");
        return false;
    }
    if (!storage_mounted(VFS_SD)) {
        snprintf(out, out_size, "cartao SD ausente (esperado %s)\n", WIFI_FW_PATH);
        return false;
    }

    VfsEntry entry;
    if (!vfs_stat(WIFI_FW_PATH, &entry) || entry.is_dir || entry.size == 0) {
        snprintf(out, out_size, "arquivo %s nao encontrado\n", WIFI_FW_PATH);
        return false;
    }
    if (entry.size > 512U * 1024U) {
        snprintf(out, out_size, "firmware grande demais (%lu bytes)\n", (unsigned long)entry.size);
        return false;
    }

    uint8_t head[256];
    size_t read = 0;
    if (!vfs_read_file_at(WIFI_FW_PATH, 0, (char *)head, sizeof(head), &read) || read == 0) {
        snprintf(out, out_size, "falha lendo %s\n", WIFI_FW_PATH);
        return false;
    }

    fw_loaded = true;
    fw_size = entry.size;
    char probe[96];
    bool sent = usb_wifi_fw_test(head, read, probe, sizeof(probe));

    if (sent) {
        snprintf(wifi_status, sizeof(wifi_status), "primeiro bloco de %lu bytes enviado", (unsigned long)read);
        snprintf(out, out_size, "%s\nfirmware completo: %lu bytes\n", probe, (unsigned long)entry.size);
    } else {
        snprintf(wifi_status, sizeof(wifi_status), "teste de envio falhou");
        snprintf(out, out_size, "%s\n", probe);
    }
    return sent;
}

#define PING_ID 0x5250U
#define PING_PAYLOAD 16
#define PING_TIMEOUT_MS 1000U

static struct raw_pcb *ping_pcb;
static uint16_t ping_seq;
static volatile bool ping_got;
static volatile uint16_t ping_wait_seq;

static u8_t ping_recv_cb(void *arg, struct raw_pcb *pcb, struct pbuf *p, const ip_addr_t *addr) {
    (void)arg;
    (void)pcb;
    (void)addr;
    uint8_t buf[64];
    uint16_t n = p->tot_len > sizeof(buf) ? (uint16_t)sizeof(buf) : (uint16_t)p->tot_len;
    pbuf_copy_partial(p, buf, n, 0);
    pbuf_free(p);

    if (n < 28 || buf[9] != 1) {
        return 1;
    }
    uint16_t ihl = (uint16_t)(buf[0] & 0x0fU) * 4U;
    if (ihl + 8U > n) {
        return 1;
    }
    const struct icmp_echo_hdr *ie = (const struct icmp_echo_hdr *)(buf + ihl);
    if (ICMPH_TYPE(ie) != ICMP_ER) {
        return 1;
    }
    if (lwip_ntohs(ie->id) == PING_ID && lwip_ntohs(ie->seqno) == ping_wait_seq) {
        ping_got = true;
    }
    return 1;
}

static void append(char *out, size_t out_size, size_t *used, const char *fmt, ...) {
    if (*used >= out_size) {
        return;
    }
    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(out + *used, out_size - *used, fmt, args);
    va_end(args);
    if (n > 0) {
        *used += (size_t)n;
        if (*used > out_size) {
            *used = out_size;
        }
    }
}

bool net_ping(const char *target, int count, char *out, size_t out_size) {
    size_t used = 0;
    if (out != NULL && out_size > 0) {
        out[0] = '\0';
    }
    struct netif *n = active_netif();
    if (n == NULL || ip4_addr_isany(netif_ip4_addr(n))) {
        append(out, out_size, &used, "ping: rede sem link ou sem IP (use ifconfig)\n");
        return false;
    }

    ip4_addr_t dst;
    if (target == NULL || !ip4addr_aton(target, &dst)) {
        append(out, out_size, &used, "ping: IP invalido: %s\n", target ? target : "(nulo)");
        return false;
    }
    if (count <= 0) {
        count = 4;
    }
    if (count > 10) {
        count = 10;
    }

    if (!ping_ready) {
        ping_pcb = raw_new(IP_PROTO_ICMP);
        if (ping_pcb == NULL) {
            append(out, out_size, &used, "ping: sem memoria para ICMP\n");
            return false;
        }
        raw_recv(ping_pcb, ping_recv_cb, NULL);
        ping_ready = true;
    }

    append(out, out_size, &used, "PING %s (%d tentativas)\n", ip4addr_ntoa(&dst), count);
    int replies = 0;
    uint32_t total_ms = 0;
    for (int i = 0; i < count; ++i) {
        uint8_t pkt[sizeof(struct icmp_echo_hdr) + PING_PAYLOAD];
        memset(pkt, 0, sizeof(pkt));
        struct icmp_echo_hdr *ie = (struct icmp_echo_hdr *)pkt;
        ICMPH_TYPE_SET(ie, ICMP_ECHO);
        ICMPH_CODE_SET(ie, 0);
        ie->id = lwip_htons(PING_ID);
        ping_seq++;
        ping_wait_seq = ping_seq;
        ie->seqno = lwip_htons(ping_seq);
        for (int b = 0; b < PING_PAYLOAD; ++b) {
            pkt[sizeof(struct icmp_echo_hdr) + b] = (uint8_t)('a' + (b % 26));
        }
        ie->chksum = inet_chksum(ie, sizeof(pkt));

        struct pbuf *p = pbuf_alloc(PBUF_IP, sizeof(pkt), PBUF_RAM);
        if (p == NULL) {
            append(out, out_size, &used, "ping: pbuf falhou\n");
            break;
        }
        pbuf_take(p, pkt, sizeof(pkt));
        ping_got = false;
        uint32_t start = sys_now();
        err_t err = raw_sendto(ping_pcb, p, ip_2_ip4(&dst));
        pbuf_free(p);
        if (err != ERR_OK) {
            append(out, out_size, &used, "seq=%u erro ao enviar (%d)\n", ping_seq, (int)err);
            continue;
        }

        while (!ping_got && (sys_now() - start) < PING_TIMEOUT_MS) {
            net_stack_task();
            usb_task();
            sleep_ms(1);
        }
        if (ping_got) {
            uint32_t rtt = sys_now() - start;
            replies++;
            total_ms += rtt;
            append(out, out_size, &used, "64 bytes de %s: seq=%u tempo=%lums\n",
                   ip4addr_ntoa(&dst), ping_seq, (unsigned long)rtt);
        } else {
            append(out, out_size, &used, "seq=%u tempo esgotado\n", ping_seq);
        }
        sleep_ms(150);
    }

    if (replies > 0) {
        append(out, out_size, &used, "--- %d/%d respostas, media %lums ---\n",
               replies, count, (unsigned long)(total_ms / (uint32_t)replies));
    } else {
        append(out, out_size, &used, "--- sem resposta de %s ---\n", ip4addr_ntoa(&dst));
    }
    return replies > 0;
}
