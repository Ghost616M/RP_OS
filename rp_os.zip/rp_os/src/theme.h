#ifndef RP_OS_THEME_H
#define RP_OS_THEME_H

#include <stdint.h>

#include "gfx.h"

typedef enum {
    THEME_BLUE_CLASSIC = 0,
    THEME_DARK_CYBER,
    THEME_MATRIX,
    THEME_RETRO,
    THEME_COUNT
} ThemeId;

typedef struct {
    uint16_t bg;
    uint16_t bg_band;
    uint16_t bg_glow;
    uint16_t panel;
    uint16_t panel_alt;
    uint16_t panel_hi;
    uint16_t border;
    uint16_t border_hi;
    uint16_t text;
    uint16_t text_dim;
    uint16_t text_faint;
    uint16_t accent;
    uint16_t accent_dark;
    uint16_t accent2;
    uint16_t warn;
    uint16_t err;
    uint16_t ok;
    uint16_t taskbar;
    uint16_t taskbar_hi;
    uint16_t title;
    uint16_t title_focus;
    uint16_t sel;
    uint16_t sel_soft;
    uint16_t shadow;
    uint16_t desk_icon_bg;
    uint16_t desk_icon_sel;
    uint16_t term_bg;
    uint16_t term_green;
    uint16_t term_cyan;
    uint16_t term_yellow;
    uint16_t term_red;
    uint16_t term_dim;
} ThemePalette;

extern ThemePalette g_theme;

void theme_init(void);
void theme_set(ThemeId id);
ThemeId theme_get(void);
const char *theme_name(ThemeId id);

#define T_BG (g_theme.bg)
#define T_BG_BAND (g_theme.bg_band)
#define T_BG_GLOW (g_theme.bg_glow)
#define T_PANEL (g_theme.panel)
#define T_PANEL_ALT (g_theme.panel_alt)
#define T_PANEL_HI (g_theme.panel_hi)
#define T_BORDER (g_theme.border)
#define T_BORDER_HI (g_theme.border_hi)
#define T_TEXT (g_theme.text)
#define T_TEXT_DIM (g_theme.text_dim)
#define T_TEXT_FAINT (g_theme.text_faint)
#define T_ACCENT (g_theme.accent)
#define T_ACCENT_DARK (g_theme.accent_dark)
#define T_ACCENT2 (g_theme.accent2)
#define T_WARN (g_theme.warn)
#define T_ERR (g_theme.err)
#define T_OK (g_theme.ok)
#define T_TASKBAR (g_theme.taskbar)
#define T_TASKBAR_HI (g_theme.taskbar_hi)
#define T_TITLE (g_theme.title)
#define T_TITLE_FOCUS (g_theme.title_focus)
#define T_SEL (g_theme.sel)
#define T_SEL_SOFT (g_theme.sel_soft)
#define T_SHADOW (g_theme.shadow)
#define T_DESK_ICON_BG (g_theme.desk_icon_bg)
#define T_DESK_ICON_SEL (g_theme.desk_icon_sel)

#define T_TERM_BG (g_theme.term_bg)
#define T_TERM_GREEN (g_theme.term_green)
#define T_TERM_CYAN (g_theme.term_cyan)
#define T_TERM_YELLOW (g_theme.term_yellow)
#define T_TERM_RED (g_theme.term_red)
#define T_TERM_DIM (g_theme.term_dim)

#define WM_TITLE_H 16
#define WM_BORDER 1
#define WM_TASKBAR_H 22
#define WM_MAX_WINDOWS 6

#endif
