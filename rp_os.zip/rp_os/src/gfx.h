#ifndef RP_OS_GFX_H
#define RP_OS_GFX_H

#include <stdbool.h>
#include <stdint.h>

#define GFX_W 320
#define GFX_H 240

#define RGB565(r, g, b) ((uint16_t)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | (((b) & 0xF8) >> 3)))

#define C_BLACK 0x0000
#define C_WHITE 0xFFFF

typedef struct {
    int x, y, w, h;
} GfxRect;

static inline bool gfx_rect_contains(const GfxRect *r, int px, int py) {
    return px >= r->x && py >= r->y && px < r->x + r->w && py < r->y + r->h;
}

static inline GfxRect gfx_rect(int x, int y, int w, int h) {
    GfxRect r = {x, y, w, h};
    return r;
}

void gfx_init(uint16_t *buffer, int width, int height);
void gfx_set_target(uint16_t *buffer, int width, int height);
void gfx_set_clip(int x, int y, int w, int h);
void gfx_reset_clip(void);
uint16_t *gfx_target(void);

void gfx_clear(uint16_t color);
void gfx_pixel(int x, int y, uint16_t color);
void gfx_fill(int x, int y, int w, int h, uint16_t color);
void gfx_hline(int x, int y, int w, uint16_t color);
void gfx_vline(int x, int y, int h, uint16_t color);
void gfx_rect_outline(int x, int y, int w, int h, uint16_t color);
void gfx_line(int x0, int y0, int x1, int y1, uint16_t color);

void gfx_char(int x, int y, char ch, uint16_t fg, uint16_t bg, bool opaque);
void gfx_text(int x, int y, const char *text, uint16_t fg, uint16_t bg, bool opaque);
void gfx_text_clip(int x, int y, int max_width, const char *text, uint16_t fg, uint16_t bg, bool opaque);
void gfx_text_right(int x_right, int y, const char *text, uint16_t fg, uint16_t bg, bool opaque);
int gfx_text_width(const char *text);

#endif
