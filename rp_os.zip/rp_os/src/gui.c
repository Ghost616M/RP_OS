#include "app.h"

#include <stdio.h>

#include "pico/stdlib.h"
#include <string.h>

#include "board.h"
#include "display.h"
#include "gfx.h"
#include "input.h"
#include "storage.h"
#include "theme.h"
#include "ui.h"
#include "usb_host.h"

#define SCREEN_W GFX_W
#define SCREEN_H GFX_H
#define DESKTOP_H (SCREEN_H - WM_TASKBAR_H)
#define TASKBAR_Y DESKTOP_H

#define DESKTOP_ICON_X 8
#define DESKTOP_ICON_Y 4
#define DESKTOP_ICON_W 72
#define DESKTOP_ICON_H 32
#define DESKTOP_ICON_STEP 29
#define DESKTOP_ICONS 7

#define START_BTN_X 2
#define START_BTN_Y (TASKBAR_Y + 2)
#define START_BTN_W 52
#define START_BTN_H 18

#define TABS_X 60
#define TABS_RIGHT 226

#define MENU_W 148
#define MENU_HEADER_H 18
#define MENU_ITEM_H 16
#define MENU_SEP_H 6
#define MENU_ITEMS 9
#define MENU_APPS 7
#define MENU_H (MENU_HEADER_H + MENU_APPS * MENU_ITEM_H + MENU_SEP_H + 2 * MENU_ITEM_H + 6)
#define MENU_X 2
#define MENU_Y (DESKTOP_H - MENU_H)

static const AppId menu_apps[MENU_APPS] = {
    APP_TERMINAL, APP_FILES, APP_GPIO, APP_EDITOR, APP_SYSMON, APP_NETWORK, APP_SETTINGS,
};

static const char *const menu_labels[MENU_ITEMS] = {
    "Terminal", "Arquivos", "GPIO", "Editor", "Sysmon", "Rede", "Config",
    "Reiniciar", "BOOTSEL",
};

static bool start_open;
static int start_sel;
static int desktop_sel = -1;
static int last_icon = -1;
static uint64_t last_icon_us;
static GuiWindow *press_window;
static int mouse_x = 160;
static int mouse_y = 120;
static uint8_t mouse_buttons;
static bool redraw_pending = true;
static uint64_t last_tick_us;
static uint64_t last_env_us;
static uint32_t last_env_bits;
static int last_clock_min = -1;

const AppOps *app_ops(AppId id) {
    switch (id) {
        case APP_TERMINAL: return &app_terminal_ops;
        case APP_FILES: return &app_files_ops;
        case APP_GPIO: return &app_gpio_ops;
        case APP_EDITOR: return &app_editor_ops;
        case APP_SYSMON: return &app_sysmon_ops;
        case APP_NETWORK: return &app_network_ops;
        case APP_SETTINGS: return &app_settings_ops;
        default: return NULL;
    }
}

void gui_invalidate(void) {
    redraw_pending = true;
}

void gui_close_start_menu(void) {
    start_open = false;
    redraw_pending = true;
}

void gui_mouse_get(int *x, int *y) {
    if (x) *x = mouse_x;
    if (y) *y = mouse_y;
}

static int menu_item_y(int index) {
    if (index < MENU_APPS) {
        return MENU_Y + MENU_HEADER_H + index * MENU_ITEM_H;
    }
    return MENU_Y + MENU_HEADER_H + MENU_APPS * MENU_ITEM_H + MENU_SEP_H +
           (index - MENU_APPS) * MENU_ITEM_H;
}

static int menu_hit(int px, int py) {
    for (int i = 0; i < MENU_ITEMS; ++i) {
        int y = menu_item_y(i);
        if (ui_hit(MENU_X + 3, y, MENU_W - 6, MENU_ITEM_H, px, py)) {
            return i;
        }
    }
    return -1;
}

static void menu_activate(int index) {
    start_open = false;
    redraw_pending = true;
    if (index < MENU_APPS) {
        app_open(menu_apps[index], NULL);
    } else if (index == MENU_APPS) {
        board_schedule_reset(400, false);
    } else {
        board_schedule_reset(400, true);
    }
}

static void draw_app_icon(int app, int x, int y, int s) {
    switch (app) {
        case APP_TERMINAL:
            gfx_fill(x, y, s, s, T_TERM_BG);
            gfx_rect_outline(x, y, s, s, T_BORDER_HI);
            gfx_line(x + s / 5, y + s / 4, x + s / 3, y + s / 2, T_TERM_GREEN);
            gfx_line(x + s / 5, y + 3 * s / 4, x + s / 3, y + s / 2, T_TERM_GREEN);
            gfx_hline(x + s / 2, y + 3 * s / 4, s / 3, T_TERM_GREEN);
            break;
        case APP_FILES:
            gfx_fill(x + s / 6, y + s / 4, s / 3, s / 6, T_WARN);
            gfx_fill(x + s / 8, y + 3 * s / 8, s * 3 / 4, s / 2, T_WARN);
            gfx_hline(x + s / 5, y + 3 * s / 5, s / 2, T_PANEL);
            break;
        case APP_GPIO:
            gfx_fill(x + s / 4, y + s / 4, s / 2, s / 2, T_ACCENT_DARK);
            gfx_rect_outline(x + s / 4, y + s / 4, s / 2, s / 2, T_ACCENT);
            for (int i = 1; i <= 3; ++i) {
                int yy = y + s / 4 + i * s / 8;
                gfx_hline(x + s / 8, yy, s / 8, T_TEXT_DIM);
                gfx_hline(x + 3 * s / 4, yy, s / 8, T_TEXT_DIM);
            }
            break;
        case APP_EDITOR:
            gfx_fill(x + s / 5, y + s / 6, s * 3 / 5, s * 2 / 3, T_TEXT);
            for (int i = 0; i < 4; ++i) {
                gfx_hline(x + s / 4, y + s / 4 + i * s / 9, s / 3, T_PANEL_ALT);
            }
            gfx_line(x + s / 2, y + s / 2 + s / 8, x + 4 * s / 5, y + 4 * s / 5, T_ACCENT);
            break;
        case APP_SYSMON: {
            gfx_rect_outline(x + s / 6, y + s / 6, s * 2 / 3, s * 2 / 3, T_BORDER_HI);
            int bw = s / 8;
            gfx_fill(x + s / 5, y + s / 2, bw, s / 3, T_ACCENT);
            gfx_fill(x + 2 * s / 5, y + 2 * s / 5, bw, s / 2, T_ACCENT2);
            gfx_fill(x + 3 * s / 5, y + s / 3, bw, s * 3 / 5, T_WARN);
            break;
        }
        case APP_NETWORK: {
            gfx_rect_outline(x, y, s, s, T_ACCENT);
            gfx_hline(x, y + s / 2, s, T_ACCENT_DARK);
            gfx_vline(x + s / 2, y, s, T_ACCENT_DARK);
            gfx_rect_outline(x + s / 4, y + s / 4, s / 2, s / 2, T_ACCENT2);
            break;
        }
        case APP_SETTINGS: {
            int c = s / 2;
            int r = s / 3;
            gfx_fill(x + c - r, y + 1, r * 2, 3, T_TEXT_DIM);
            gfx_fill(x + c - r, y + s - 4, r * 2, 3, T_TEXT_DIM);
            gfx_fill(x + 1, y + c - r, 3, r * 2, T_TEXT_DIM);
            gfx_fill(x + s - 4, y + c - r, 3, r * 2, T_TEXT_DIM);
            gfx_fill(x + c - r, y + c - r, r * 2, r * 2, T_PANEL_HI);
            gfx_rect_outline(x + c - r, y + c - r, r * 2, r * 2, T_ACCENT2);
            gfx_fill(x + c - r / 2, y + c - r / 2, r, r, T_TERM_BG);
            break;
        }
        default:
            gfx_fill(x, y, s, s, T_PANEL_HI);
            break;
    }
}

static GfxRect icon_rect(int index) {
    return gfx_rect(DESKTOP_ICON_X, DESKTOP_ICON_Y + index * DESKTOP_ICON_STEP,
                    DESKTOP_ICON_W, DESKTOP_ICON_H);
}

static int desktop_hit(int px, int py) {
    for (int i = 0; i < DESKTOP_ICONS; ++i) {
        GfxRect r = icon_rect(i);
        if (gfx_rect_contains(&r, px, py)) {
            return i;
        }
    }
    return -1;
}

static void draw_desktop(void) {
    gfx_clear(T_BG);
    gfx_fill(0, 0, SCREEN_W, 64, T_BG_BAND);
    gfx_hline(0, 64, SCREEN_W, T_BG_GLOW);
    gfx_text_right(SCREEN_W - 8, DESKTOP_H - 14, "rp_os v" BOARD_VERSION,
                   T_ACCENT_DARK, T_BG, false);

    for (int i = 0; i < DESKTOP_ICONS; ++i) {
        GfxRect r = icon_rect(i);
        if (i == desktop_sel) {
            gfx_fill(r.x - 2, r.y - 2, r.w + 4, r.h + 4, T_DESK_ICON_SEL);
            gfx_rect_outline(r.x - 2, r.y - 2, r.w + 4, r.h + 4, T_BORDER_HI);
        }
        draw_app_icon(menu_apps[i], r.x + (r.w - 20) / 2, r.y + 1, 20);
        const char *label = menu_labels[i];
        int tw = gfx_text_width(label);
        int lx = r.x + (r.w - tw) / 2;
        if (lx < r.x) lx = r.x;
        gfx_text_clip(lx, r.y + 21, r.w, label, T_TEXT, T_BG, false);
    }
}

static int tabs_build(GuiWindow **out) {
    int count = 0;
    int slots = gui_wm_window_count();
    for (int i = 0; i < slots; ++i) {
        GuiWindow *w = gui_wm_window_at(i);
        if (w != NULL && w->open) {
            out[count++] = w;
        }
    }
    return count;
}

static int tab_width(int count) {
    int avail = TABS_RIGHT - TABS_X;
    int width = avail / count;
    if (width > 78) width = 78;
    if (width < 24) width = 24;
    return width;
}

static void draw_sd_icon(int x, int y, bool on) {
    uint16_t color = on ? T_OK : T_TEXT_FAINT;
    gfx_rect_outline(x, y, 8, 10, color);
    gfx_line(x + 5, y, x + 7, y + 2, color);
    gfx_hline(x + 2, y + 3, 4, color);
    gfx_fill(x + 2, y + 6, 1, 2, color);
    gfx_fill(x + 4, y + 6, 1, 2, color);
}

static void draw_usb_icon(int x, int y, bool on) {
    uint16_t color = on ? T_ACCENT : T_TEXT_FAINT;
    gfx_rect_outline(x, y + 4, 7, 5, color);
    gfx_fill(x + 2, y + 1, 3, 3, color);
    gfx_hline(x + 1, y + 6, 2, color);
    gfx_hline(x + 4, y + 6, 2, color);
}

static void draw_start_button(void) {
    bool pressed = start_open;
    gfx_fill(START_BTN_X, START_BTN_Y, START_BTN_W, START_BTN_H, pressed ? T_PANEL_HI : T_TASKBAR_HI);
    gfx_rect_outline(START_BTN_X, START_BTN_Y, START_BTN_W, START_BTN_H, T_BORDER);

    int lx = START_BTN_X + 4;
    int ly = START_BTN_Y + 4;
    gfx_fill(lx, ly, 4, 4, T_ACCENT);
    gfx_fill(lx + 5, ly, 4, 4, T_ACCENT2);
    gfx_fill(lx, ly + 5, 4, 4, T_WARN);
    gfx_fill(lx + 5, ly + 5, 4, 4, T_ERR);
    gfx_text(START_BTN_X + 16, START_BTN_Y + 5, "Menu", T_TEXT, pressed ? T_PANEL_HI : T_TASKBAR_HI, false);
}

static void draw_taskbar(void) {
    gfx_fill(0, TASKBAR_Y, SCREEN_W, WM_TASKBAR_H, T_TASKBAR);
    gfx_hline(0, TASKBAR_Y, SCREEN_W, T_BORDER);
    draw_start_button();

    GuiWindow *tabs[WM_MAX_WINDOWS];
    int count = tabs_build(tabs);
    if (count > 0) {
        int tw = tab_width(count);
        for (int i = 0; i < count; ++i) {
            GuiWindow *w = tabs[i];
            int tx = TABS_X + i * tw;
            bool focused = (gui_wm_top() == w);
            uint16_t fill = focused ? T_TITLE_FOCUS : T_PANEL;
            if (w->minimized) fill = T_TASKBAR_HI;
            gfx_fill(tx, START_BTN_Y, tw - 1, START_BTN_H, fill);
            gfx_rect_outline(tx, START_BTN_Y, tw - 1, START_BTN_H, focused ? T_ACCENT : T_BORDER);
            uint16_t icon_color = T_ACCENT;
            const AppOps *ops = app_ops((AppId)w->app_id);
            if (ops != NULL) icon_color = ops->icon_color;
            gfx_fill(tx + 3, START_BTN_Y + 7, 6, 6, icon_color);
            gfx_text_clip(tx + 12, START_BTN_Y + 5, tw - 15, w->title,
                          w->minimized ? T_TEXT_FAINT : T_TEXT, fill, false);
        }
    }

    bool sd = storage_mounted(VFS_SD);
    bool usb = storage_mounted(VFS_USB) || usb_keyboard_count() > 0 || usb_mouse_count() > 0;
    draw_sd_icon(228, TASKBAR_Y + 6, sd);
    draw_usb_icon(240, TASKBAR_Y + 6, usb);

    char buf[16];
    int temp = (int)(board_temp_c() + 0.5f);
    snprintf(buf, sizeof(buf), "%dC", temp);
    gfx_text_right(274, TASKBAR_Y + 7, buf, T_TEXT_DIM, T_TASKBAR, false);

    uint32_t seconds = board_uptime_s();
    unsigned hours = (seconds / 3600U) % 24U;
    unsigned minutes = (seconds / 60U) % 60U;
    snprintf(buf, sizeof(buf), "%02u:%02u", hours, minutes);
    gfx_text_right(316, TASKBAR_Y + 7, buf, T_TEXT, T_TASKBAR, false);
}

static void draw_start_menu(void) {
    gfx_fill(MENU_X + 3, MENU_Y + 3, MENU_W, MENU_H, T_SHADOW);
    gfx_fill(MENU_X, MENU_Y, MENU_W, MENU_H, T_PANEL);
    gfx_rect_outline(MENU_X, MENU_Y, MENU_W, MENU_H, T_BORDER_HI);
    gfx_fill(MENU_X + 1, MENU_Y + 1, MENU_W - 2, MENU_HEADER_H - 1, T_TITLE_FOCUS);
    gfx_text(MENU_X + 6, MENU_Y + 5, "rp_os", T_TEXT, T_TITLE_FOCUS, false);
    gfx_text_right(MENU_X + MENU_W - 6, MENU_Y + 5, "v" BOARD_VERSION, T_TEXT_DIM, T_TITLE_FOCUS, false);

    for (int i = 0; i < MENU_ITEMS; ++i) {
        int y = menu_item_y(i);
        bool selected = (i == start_sel);
        if (selected) {
            gfx_fill(MENU_X + 3, y, MENU_W - 6, MENU_ITEM_H, T_SEL);
        }
        uint16_t bg = selected ? T_SEL : T_PANEL;
        if (i < MENU_APPS) {
            draw_app_icon(menu_apps[i], MENU_X + 7, y + 2, 12);
        } else {
            uint16_t color = (i == MENU_APPS) ? T_WARN : T_ERR;
            gfx_fill(MENU_X + 8, y + 3, 8, 8, color);
            gfx_rect_outline(MENU_X + 8, y + 3, 8, 8, T_TEXT_DIM);
        }
        gfx_text(MENU_X + 24, y + 4, menu_labels[i], T_TEXT, bg, false);
    }

    int sep_y = MENU_Y + MENU_HEADER_H + MENU_APPS * MENU_ITEM_H + MENU_SEP_H / 2;
    gfx_hline(MENU_X + 6, sep_y, MENU_W - 12, T_BORDER);
}

static void close_rect(GuiWindow *w, GfxRect *out) {
    *out = gfx_rect(w->x + w->w - 1 - 13, w->y + 3, 12, 11);
}

static void min_rect(GuiWindow *w, GfxRect *out) {
    *out = gfx_rect(w->x + w->w - 1 - 13 - 14, w->y + 3, 12, 11);
}

static void resize_rect(GuiWindow *w, GfxRect *out) {
    *out = gfx_rect(w->x + w->w - 14, w->y + w->h - 14, 13, 13);
}

static void draw_window(GuiWindow *w) {
    bool focused = (gui_wm_top() == w);
    const AppOps *ops = app_ops((AppId)w->app_id);

    gfx_fill(w->x + 3, w->y + 3, w->w, w->h, T_SHADOW);
    gfx_fill(w->x, w->y, w->w, w->h, focused ? T_BORDER_HI : T_BORDER);
    gfx_fill(w->x + 1, w->y + 1, w->w - 2, w->h - 2, T_PANEL);
    gfx_fill(w->x + 1, w->y + 1, w->w - 2, WM_TITLE_H - 1, focused ? T_TITLE_FOCUS : T_TITLE);
    gfx_hline(w->x + 1, w->y + 1, w->w - 2, focused ? T_ACCENT : T_BORDER);

    int title_w = w->w - 2 - 5 - 2 * 14 - 6;
    gfx_text_clip(w->x + 5, w->y + 4, title_w > 0 ? title_w : 0, w->title,
                  T_TEXT, focused ? T_TITLE_FOCUS : T_TITLE, false);

    GfxRect close = {0}, min = {0};
    close_rect(w, &close);
    min_rect(w, &min);

    bool close_hot = ui_hit(close.x, close.y, close.w, close.h, mouse_x, mouse_y);
    gfx_fill(close.x, close.y, close.w, close.h, close_hot ? T_ERR : T_PANEL_HI);
    gfx_rect_outline(close.x, close.y, close.w, close.h, T_BORDER);
    gfx_line(close.x + 3, close.y + 3, close.x + 8, close.y + 7, T_TEXT);
    gfx_line(close.x + 8, close.y + 3, close.x + 3, close.y + 7, T_TEXT);

    bool min_hot = ui_hit(min.x, min.y, min.w, min.h, mouse_x, mouse_y);
    gfx_fill(min.x, min.y, min.w, min.h, min_hot ? T_SEL : T_PANEL_HI);
    gfx_rect_outline(min.x, min.y, min.w, min.h, T_BORDER);
    gfx_hline(min.x + 3, min.y + 7, 6, T_TEXT);

    int cx, cy, cw, ch;
    gui_wm_content_rect(w, &cx, &cy, &cw, &ch);
    gfx_set_clip(cx, cy, cw, ch);
    if (ops != NULL && ops->draw != NULL) {
        ops->draw(w, cx, cy, cw, ch);
    } else {
        gfx_fill(cx, cy, cw, ch, T_PANEL_ALT);
    }
    gfx_reset_clip();

    GfxRect grip = {0};
    resize_rect(w, &grip);
    bool grip_hot = ui_hit(grip.x, grip.y, grip.w, grip.h, mouse_x, mouse_y);
    gfx_fill(grip.x, grip.y, grip.w, grip.h, grip_hot ? T_SEL : T_PANEL_ALT);
    gfx_rect_outline(grip.x, grip.y, grip.w, grip.h, grip_hot ? T_ACCENT : T_BORDER);
    for (int i = 3; i <= 7; i += 2) {
        gfx_line(grip.x + i, grip.y + grip.h - 3, grip.x + grip.w - 3, grip.y + i,
                 grip_hot ? T_TEXT : T_TEXT_FAINT);
    }
}

static void draw_cursor(void) {
    int x = mouse_x;
    int y = mouse_y;
    gfx_line(x + 1, y + 1, x + 1, y + 12, C_BLACK);
    gfx_line(x + 1, y + 1, x + 8, y + 8, C_BLACK);
    gfx_line(x + 1, y + 1, x, y + 11, C_WHITE);
    gfx_line(x, y + 1, x + 7, y + 7, C_WHITE);
    gfx_line(x + 3, y + 7, x + 5, y + 13, C_WHITE);
    gfx_line(x + 3, y + 7, x + 6, y + 7, C_WHITE);
    gfx_line(x + 4, y + 7, x + 7, y + 12, C_WHITE);
    gfx_line(x + 5, y + 13, x + 7, y + 12, C_WHITE);
}

static void forward_event(GuiWindow *w, const GuiEvent *ev, int abs_x, int abs_y) {
    const AppOps *ops = app_ops((AppId)w->app_id);
    if (ops == NULL || ops->event == NULL) {
        return;
    }
    int cx, cy, cw, ch;
    gui_wm_content_rect(w, &cx, &cy, &cw, &ch);
    GuiEvent local = *ev;
    local.x = abs_x - cx;
    local.y = abs_y - cy;
    ops->event(w, &local, cx, cy, cw, ch);
}

static void taskbar_click(int x, int y) {
    if (ui_hit(START_BTN_X, START_BTN_Y, START_BTN_W, START_BTN_H, x, y)) {
        start_open = !start_open;
        start_sel = 0;
        redraw_pending = true;
        return;
    }

    GuiWindow *tabs[WM_MAX_WINDOWS];
    int count = tabs_build(tabs);
    if (count > 0) {
        int tw = tab_width(count);
        for (int i = 0; i < count; ++i) {
            int tx = TABS_X + i * tw;
            if (ui_hit(tx, START_BTN_Y, tw - 1, START_BTN_H, x, y)) {
                GuiWindow *w = tabs[i];
                if (w->minimized) {
                    gui_wm_restore(w);
                    gui_wm_raise(w);
                } else if (gui_wm_top() == w) {
                    gui_wm_minimize(w);
                } else {
                    gui_wm_raise(w);
                }
                redraw_pending = true;
                return;
            }
        }
    }

    if (x >= 220) {
        app_open(APP_SYSMON, NULL);
        redraw_pending = true;
    }
}

static void handle_mouse_down(const InputEvent *ev) {
    int x = ev->x;
    int y = ev->y;

    if (start_open) {
        if (ui_hit(START_BTN_X, START_BTN_Y, START_BTN_W, START_BTN_H, x, y)) {
            start_open = false;
            redraw_pending = true;
            return;
        }
        if (ui_hit(MENU_X, MENU_Y, MENU_W, MENU_H, x, y)) {
            int item = menu_hit(x, y);
            if (item >= 0) {
                menu_activate(item);
            }
            return;
        }
        start_open = false;
    }

    if (y >= TASKBAR_Y) {
        taskbar_click(x, y);
        return;
    }

    for (int i = gui_wm_z_count() - 1; i >= 0; --i) {
        GuiWindow *w = gui_wm_z_at(i);
        if (w == NULL || !w->open || w->minimized) {
            continue;
        }
        if (!ui_hit(w->x, w->y, w->w, w->h, x, y)) {
            continue;
        }

        gui_wm_focus(w);
        redraw_pending = true;

        GfxRect close = {0}, min = {0};
        close_rect(w, &close);
        min_rect(w, &min);
        if (ui_hit(close.x, close.y, close.w, close.h, x, y)) {
            gui_wm_close(w);
            return;
        }
        if (ui_hit(min.x, min.y, min.w, min.h, x, y)) {
            gui_wm_minimize(w);
            return;
        }
        GfxRect grip = {0};
        resize_rect(w, &grip);
        if (ui_hit(grip.x, grip.y, grip.w, grip.h, x, y)) {
            gui_wm_begin_resize(w, x, y);
            return;
        }
        if (y < w->y + WM_TITLE_H) {
            gui_wm_begin_drag(w, x, y);
            return;
        }

        press_window = w;
        GuiEvent gev = {
            .type = GUI_EV_MOUSE_DOWN,
            .x = x,
            .y = y,
            .button = 0,
            .pressed = true,
        };
        forward_event(w, &gev, x, y);
        return;
    }

    int icon = desktop_hit(x, y);
    if (icon >= 0) {
        bool double_click = (icon == last_icon) &&
                            (time_us_64() - last_icon_us < 400000ULL);
        desktop_sel = icon;
        last_icon = icon;
        last_icon_us = time_us_64();
        redraw_pending = true;
        if (double_click) {
            app_open(menu_apps[icon], NULL);
        }
    } else {
        desktop_sel = -1;
        redraw_pending = true;
    }
}

static void handle_mouse_up(const InputEvent *ev) {
    for (int i = 0; i < gui_wm_window_count(); ++i) {
        GuiWindow *w = gui_wm_window_at(i);
        if (w != NULL) {
            w->dragging = false;
            w->resizing = false;
        }
    }

    if (press_window != NULL) {
        GuiEvent gev = {
            .type = GUI_EV_MOUSE_UP,
            .x = ev->x,
            .y = ev->y,
            .button = 0,
            .pressed = false,
        };
        forward_event(press_window, &gev, ev->x, ev->y);
        press_window = NULL;
    }
    redraw_pending = true;
}

static void handle_wheel(const InputEvent *ev) {
    for (int i = gui_wm_z_count() - 1; i >= 0; --i) {
        GuiWindow *w = gui_wm_z_at(i);
        if (w == NULL || !w->open || w->minimized) {
            continue;
        }
        int cx, cy, cw, ch;
        gui_wm_content_rect(w, &cx, &cy, &cw, &ch);
        if (ui_hit(cx, cy, cw, ch, ev->x, ev->y)) {
            GuiEvent gev = {
                .type = GUI_EV_WHEEL,
                .x = ev->x,
                .y = ev->y,
                .wheel = ev->wheel,
            };
            forward_event(w, &gev, ev->x, ev->y);
            redraw_pending = true;
            return;
        }
    }
}

static void handle_key(const InputEvent *ev) {
    if (start_open && ev->pressed) {
        switch (ev->key) {
            case INPUT_KEY_ESC:
                start_open = false;
                break;
            case INPUT_KEY_UP:
                start_sel = (start_sel + MENU_ITEMS - 1) % MENU_ITEMS;
                break;
            case INPUT_KEY_DOWN:
                start_sel = (start_sel + 1) % MENU_ITEMS;
                break;
            case INPUT_KEY_HOME:
                start_sel = 0;
                break;
            case INPUT_KEY_END:
                start_sel = MENU_ITEMS - 1;
                break;
            case INPUT_KEY_ENTER:
                menu_activate(start_sel);
                return;
            default:
                break;
        }
        redraw_pending = true;
        return;
    }

    if (ev->pressed && (ev->mods & INPUT_MOD_CTRL) && ev->key == INPUT_KEY_ESC) {
        start_open = true;
        start_sel = 0;
        redraw_pending = true;
        return;
    }

    GuiWindow *w = gui_wm_top();
    if (w == NULL) {
        return;
    }
    GuiEvent gev = {
        .type = GUI_EV_KEY,
        .key = ev->key,
        .mods = ev->mods,
        .pressed = ev->pressed,
        .repeat = ev->repeat,
    };
    forward_event(w, &gev, mouse_x, mouse_y);
    redraw_pending = true;
}

void gui_init(void) {
    start_open = false;
    start_sel = 0;
    desktop_sel = -1;
    last_icon = -1;
    last_icon_us = 0;
    press_window = NULL;
    redraw_pending = true;
    last_tick_us = time_us_64();
    last_env_us = 0;
    last_env_bits = 0xFFFFFFFFU;
    last_clock_min = -1;

    input_set_mouse_limits(SCREEN_W, SCREEN_H);
    input_get_mouse(&mouse_x, &mouse_y, &mouse_buttons);

    GuiWindow *term = app_open(APP_TERMINAL, NULL);
    if (term != NULL) {
        gui_wm_resize(term, 220, 140);
        gui_wm_move(term, SCREEN_W - term->w - 4, 8);
    }
}

void gui_task(void) {
    input_task();
    input_get_mouse(&mouse_x, &mouse_y, &mouse_buttons);

    InputEvent ev;
    while (input_poll(&ev)) {
        switch (ev.type) {
            case INPUT_EV_MOUSE_BUTTON:
                if (ev.pressed) {
                    handle_mouse_down(&ev);
                } else {
                    handle_mouse_up(&ev);
                }
                break;
            case INPUT_EV_WHEEL:
                handle_wheel(&ev);
                break;
            case INPUT_EV_KEY:
                handle_key(&ev);
                break;
            default:
                break;
        }
        input_get_mouse(&mouse_x, &mouse_y, &mouse_buttons);
    }

    if (input_take_moved()) {
        for (int i = 0; i < gui_wm_window_count(); ++i) {
            GuiWindow *w = gui_wm_window_at(i);
            if (w != NULL && w->open && w->dragging) {
                gui_wm_drag_to(w, mouse_x, mouse_y);
                redraw_pending = true;
            } else if (w != NULL && w->open && w->resizing) {
                gui_wm_resize_to(w, mouse_x, mouse_y);
                redraw_pending = true;
            }
        }
        redraw_pending = true;
        if (start_open) {
            int item = menu_hit(mouse_x, mouse_y);
            if (item >= 0) {
                start_sel = item;
            }
        }
    }

    uint64_t now = time_us_64();
    if (now - last_tick_us >= 200000ULL) {
        last_tick_us = now;
        for (int i = 0; i < gui_wm_window_count(); ++i) {
            GuiWindow *w = gui_wm_window_at(i);
            if (w == NULL || !w->open) {
                continue;
            }
            const AppOps *ops = app_ops((AppId)w->app_id);
            if (ops != NULL && ops->tick != NULL) {
                ops->tick(w);
            }
        }
    }

    if (now - last_env_us >= 1000000ULL) {
        last_env_us = now;
        uint32_t bits = 0;
        if (storage_mounted(VFS_FLASH)) bits |= 1U;
        if (storage_mounted(VFS_SD)) bits |= 2U;
        if (storage_mounted(VFS_USB)) bits |= 4U;
        if (usb_keyboard_count() > 0) bits |= 8U;
        if (usb_mouse_count() > 0) bits |= 16U;
        if (bits != last_env_bits) {
            last_env_bits = bits;
            redraw_pending = true;
        }
    }

    int clock_min = (int)(board_uptime_s() / 60U);
    if (clock_min != last_clock_min) {
        last_clock_min = clock_min;
        redraw_pending = true;
    }

    if (!redraw_pending) {
        return;
    }
    redraw_pending = false;

    gfx_set_target(display_backbuffer(), SCREEN_W, SCREEN_H);
    draw_desktop();
    for (int i = 0; i < gui_wm_z_count(); ++i) {
        GuiWindow *w = gui_wm_z_at(i);
        if (w != NULL && w->open && !w->minimized) {
            draw_window(w);
        }
    }
    draw_taskbar();
    if (start_open) {
        draw_start_menu();
    }
    draw_cursor();
    display_present();
}
