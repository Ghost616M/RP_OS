#include "input.h"

#include <string.h>

#include "hardware/sync.h"
#include "pico/stdlib.h"

#define EVENT_QUEUE_SIZE 48

static InputEvent event_queue[EVENT_QUEUE_SIZE];
static volatile uint8_t queue_head;
static volatile uint8_t queue_tail;

static int mouse_x = 160;
static int mouse_y = 120;
static int mouse_limit_w = 320;
static int mouse_limit_h = 240;
static uint8_t mouse_buttons;
static volatile bool mouse_moved;
static uint8_t mouse_speed_index = 1;
static bool mouse_invert_buttons;
static int32_t mouse_acc_x;
static int32_t mouse_acc_y;

static const char *const mouse_speed_labels[INPUT_MOUSE_SPEED_COUNT] = {
    "0.5x", "1.0x", "1.5x", "2.0x",
};
static const uint8_t mouse_speed_num[INPUT_MOUSE_SPEED_COUNT] = {1, 1, 3, 2};
static const uint8_t mouse_speed_den[INPUT_MOUSE_SPEED_COUNT] = {2, 1, 2, 1};

static uint16_t repeat_key;
static uint8_t repeat_mods;
static uint64_t repeat_next_us;
static uint64_t repeat_start_us;

static void queue_push(const InputEvent *event) {
    uint8_t next = (uint8_t)((queue_head + 1U) % EVENT_QUEUE_SIZE);
    if (next == queue_tail) {
        return;
    }
    event_queue[queue_head] = *event;
    __dmb();
    queue_head = next;
}

bool input_poll(InputEvent *event) {
    if (queue_tail == queue_head) {
        return false;
    }
    *event = event_queue[queue_tail];
    __dmb();
    queue_tail = (uint8_t)((queue_tail + 1U) % EVENT_QUEUE_SIZE);
    return true;
}

bool input_take_moved(void) {
    bool moved = mouse_moved;
    mouse_moved = false;
    return moved;
}

void input_init(void) {
    queue_head = 0;
    queue_tail = 0;
    mouse_x = 160;
    mouse_y = 120;
    mouse_buttons = 0;
    mouse_moved = false;
    mouse_speed_index = 1;
    mouse_invert_buttons = false;
    mouse_acc_x = 0;
    mouse_acc_y = 0;
    repeat_key = 0;
    repeat_start_us = 0;
    repeat_next_us = 0;
}

void input_set_mouse_limits(int width, int height) {
    mouse_limit_w = width;
    mouse_limit_h = height;
    if (mouse_x >= width) mouse_x = width - 1;
    if (mouse_y >= height) mouse_y = height - 1;
}

void input_mouse_move(int dx, int dy) {
    if (dx == 0 && dy == 0) {
        return;
    }
    uint8_t num = mouse_speed_num[mouse_speed_index];
    uint8_t den = mouse_speed_den[mouse_speed_index];
    mouse_acc_x += (int32_t)dx * num;
    mouse_acc_y += (int32_t)dy * num;
    int step_x = (int)(mouse_acc_x / den);
    int step_y = (int)(mouse_acc_y / den);
    mouse_acc_x -= (int32_t)step_x * den;
    mouse_acc_y -= (int32_t)step_y * den;
    if (step_x == 0 && step_y == 0) {
        return;
    }
    mouse_x += step_x;
    mouse_y += step_y;
    if (mouse_x < 0) mouse_x = 0;
    if (mouse_y < 0) mouse_y = 0;
    if (mouse_x >= mouse_limit_w) mouse_x = mouse_limit_w - 1;
    if (mouse_y >= mouse_limit_h) mouse_y = mouse_limit_h - 1;
    mouse_moved = true;
}

void input_mouse_buttons(uint8_t buttons) {
    if (mouse_invert_buttons) {
        uint8_t left = (buttons & 0x01U) << 1;
        uint8_t right = (buttons & 0x02U) >> 1;
        buttons = (uint8_t)((buttons & ~0x03U) | left | right);
    }
    uint8_t changed = buttons ^ mouse_buttons;
    mouse_buttons = buttons;
    if (changed == 0) {
        return;
    }

    for (int bit = 0; bit < 3; ++bit) {
        uint8_t mask = (uint8_t)(1U << bit);
        if (changed & mask) {
            InputEvent ev = {
                .type = INPUT_EV_MOUSE_BUTTON,
                .x = mouse_x,
                .y = mouse_y,
                .buttons = buttons,
                .pressed = (buttons & mask) != 0,
            };
            queue_push(&ev);
        }
    }
}

void input_mouse_wheel(int8_t wheel) {
    if (wheel == 0) {
        return;
    }
    InputEvent ev = {
        .type = INPUT_EV_WHEEL,
        .x = mouse_x,
        .y = mouse_y,
        .wheel = wheel,
    };
    queue_push(&ev);
}

void input_get_mouse(int *x, int *y, uint8_t *buttons) {
    if (x) *x = mouse_x;
    if (y) *y = mouse_y;
    if (buttons) *buttons = mouse_buttons;
}

uint8_t input_mouse_speed_get(void) {
    return mouse_speed_index;
}

void input_mouse_speed_set(uint8_t index) {
    if (index >= INPUT_MOUSE_SPEED_COUNT) {
        index = 1;
    }
    mouse_speed_index = index;
    mouse_acc_x = 0;
    mouse_acc_y = 0;
}

const char *input_mouse_speed_label(void) {
    return mouse_speed_labels[mouse_speed_index];
}

bool input_mouse_invert_get(void) {
    return mouse_invert_buttons;
}

void input_mouse_invert_set(bool invert) {
    mouse_invert_buttons = invert;
}

static bool key_repeatable(uint16_t key) {
    if (key >= 32 && key < 127) return true;
    switch (key) {
        case INPUT_KEY_BACKSPACE:
        case INPUT_KEY_DELETE:
        case INPUT_KEY_UP:
        case INPUT_KEY_DOWN:
        case INPUT_KEY_LEFT:
        case INPUT_KEY_RIGHT:
        case INPUT_KEY_HOME:
        case INPUT_KEY_END:
        case INPUT_KEY_PAGEUP:
        case INPUT_KEY_PAGEDOWN:
            return true;
        default:
            return false;
    }
}

void input_key(uint16_t key, uint8_t mods, bool pressed) {
    if (key == 0) {
        return;
    }

    InputEvent ev = {
        .type = INPUT_EV_KEY,
        .key = key,
        .mods = mods,
        .pressed = pressed,
    };
    queue_push(&ev);

    if (pressed) {
        if (key_repeatable(key)) {
            repeat_key = key;
            repeat_mods = mods;
            repeat_start_us = time_us_64();
            repeat_next_us = repeat_start_us + 450000ULL;
        }
    } else if (key == repeat_key) {
        repeat_key = 0;
    }
}

void input_task(void) {
    if (repeat_key == 0) {
        return;
    }
    uint64_t now = time_us_64();
    if (now < repeat_next_us) {
        return;
    }
    if (now - repeat_start_us > 15000000ULL) {
        repeat_key = 0;
        return;
    }

    InputEvent ev = {
        .type = INPUT_EV_KEY,
        .key = repeat_key,
        .mods = repeat_mods,
        .pressed = true,
        .repeat = true,
    };
    queue_push(&ev);
    repeat_next_us = now + 50000ULL;
}
