#ifndef RP_OS_STORAGE_H
#define RP_OS_STORAGE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef enum {
    VFS_FLASH = 0,
    VFS_SD = 1,
    VFS_USB = 2,
    VFS_DRIVE_COUNT
} VfsDrive;

typedef struct {
    char name[48];
    uint32_t size;
    bool is_dir;
} VfsEntry;

typedef struct {
    bool mounted;
    uint32_t total_kb;
    uint32_t free_kb;
    char status[24];
} VfsDriveInfo;

void storage_init(void);
void storage_task(void);
void storage_refresh(void);

bool storage_mounted(VfsDrive drive);
const char *storage_mount_path(VfsDrive drive);
const char *storage_drive_name(VfsDrive drive);
const char *storage_drive_status(VfsDrive drive);
void storage_info(VfsDrive drive, VfsDriveInfo *info);

bool vfs_normalize(const char *cwd, const char *input, char *out, size_t out_size);
bool vfs_stat(const char *path, VfsEntry *entry);
bool vfs_is_dir(const char *path);
bool vfs_exists(const char *path);
int vfs_list(const char *path, VfsEntry *entries, int max_entries);
bool vfs_read_file(const char *path, char *buffer, size_t max_size, size_t *out_size);
bool vfs_read_file_at(const char *path, uint32_t offset, char *buffer, size_t max_size, size_t *out_size);
bool vfs_write_file(const char *path, const char *data, size_t size);
bool vfs_copy_file(const char *from, const char *to);
bool vfs_mkdir(const char *path);
bool vfs_remove(const char *path);
bool vfs_remove_recursive(const char *path);
bool vfs_rename(const char *from, const char *to);
bool vfs_df(VfsDrive drive, uint32_t *total_kb, uint32_t *free_kb);
void vfs_basename(const char *path, char *out, size_t out_size);
void vfs_dirname(const char *path, char *out, size_t out_size);

void storage_usb_mounted(uint8_t dev_addr);
void storage_usb_unmounted(uint8_t dev_addr);

#endif
