#ifndef RP_OS_UI_H
#define RP_OS_UI_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include "gfx.h"
#include "theme.h"

static inline void ui_text_center(int x, int y, int w, const char *text, uint16_t fg, uint16_t bg, bool opaque) {
    int tw = gfx_text_width(text);
    int tx = x + (w - tw) / 2;
    if (tx < x) {
        tx = x;
    }
    gfx_text_clip(tx, y, w, text, fg, bg, opaque);
}

static inline void ui_button(int x, int y, int w, int h, const char *label, bool highlighted, bool enabled, uint16_t highlight_color) {
    uint16_t fill = !enabled ? T_PANEL : (highlighted ? highlight_color : T_PANEL_HI);
    uint16_t fg = enabled ? T_TEXT : T_TEXT_FAINT;
    gfx_fill(x, y, w, h, fill);
    gfx_rect_outline(x, y, w, h, enabled ? T_BORDER_HI : T_BORDER);
    ui_text_center(x, y + (h - 8) / 2, w, label, fg, fill, false);
}

static inline void ui_format_size(uint32_t bytes, char *out, size_t out_size) {
    if (bytes < 1024U) {
        snprintf(out, out_size, "%luB", (unsigned long)bytes);
    } else if (bytes < 1024U * 1024U) {
        snprintf(out, out_size, "%luK", (unsigned long)(bytes / 1024U));
    } else {
        snprintf(out, out_size, "%.1fM", (double)bytes / (1024.0 * 1024.0));
    }
}

static inline bool ui_hit(int x, int y, int w, int h, int px, int py) {
    return px >= x && py >= y && px < x + w && py < y + h;
}

#endif
