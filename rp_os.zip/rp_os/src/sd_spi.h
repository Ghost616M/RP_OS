#ifndef RP_OS_SD_SPI_H
#define RP_OS_SD_SPI_H

#include <stdbool.h>
#include <stdint.h>

bool sd_init(void);
bool sd_ready(void);
uint32_t sd_sector_count(void);
bool sd_read_blocks(uint32_t lba, uint8_t *buffer, uint32_t count);
bool sd_write_blocks(uint32_t lba, const uint8_t *buffer, uint32_t count);

#endif
