#ifndef RP_OS_HW_H
#define RP_OS_HW_H

#include <stdbool.h>
#include <stdint.h>

#define HW_PIN_FIRST 0
#define HW_PIN_LAST 27
#define HW_PIN_COUNT (HW_PIN_LAST - HW_PIN_FIRST + 1)

typedef enum {
    HW_MODE_UNUSED = 0,
    HW_MODE_INPUT,
    HW_MODE_OUTPUT,
    HW_MODE_PWM,
} HwMode;

void hw_init(void);
bool hw_pin_valid(int pin);
HwMode hw_pin_mode(int pin);
const char *hw_mode_name(HwMode mode);

bool hw_pin_get(int pin);
void hw_pin_set_mode(int pin, HwMode mode);
void hw_pin_write(int pin, bool level);
void hw_pin_toggle(int pin);
void hw_pin_pwm(int pin, uint32_t freq_hz, uint8_t duty_percent);
void hw_pin_pwm_off(int pin);

int hw_i2c_scan(uint8_t sda, uint8_t scl, uint8_t *found, int max_found);

#endif
