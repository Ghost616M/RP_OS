#include "board.h"

#include <malloc.h>

#include "hardware/adc.h"
#include "hardware/clocks.h"
#include "hardware/vreg.h"
#include "hardware/watchdog.h"
#include "pico/bootrom.h"
#include "pico/stdlib.h"

#define SYSTEM_CLOCK_KHZ 252000

static uint64_t reset_at_us;
static bool reset_bootsel;

void board_init(void) {
    vreg_set_voltage(VREG_VOLTAGE_1_20);
    sleep_ms(10);
    set_sys_clock_khz(SYSTEM_CLOCK_KHZ, true);

    adc_init();
    adc_set_temp_sensor_enabled(true);
    adc_select_input(ADC_TEMPERATURE_CHANNEL_NUM);

    reset_at_us = 0;
    reset_bootsel = false;
}

float board_temp_c(void) {
    adc_select_input(ADC_TEMPERATURE_CHANNEL_NUM);
    uint16_t raw = adc_read();
    float voltage = (float)raw * 3.3f / 4095.0f;
    return 27.0f - (voltage - 0.706f) / 0.001721f;
}

uint32_t board_uptime_s(void) {
    return (uint32_t)(time_us_64() / 1000000ULL);
}

uint64_t board_uptime_ms(void) {
    return time_us_64() / 1000ULL;
}

uint32_t board_cpu_mhz(void) {
    return (uint32_t)(clock_get_hz(clk_sys) / 1000000U);
}

uint32_t board_heap_free(void) {
    struct mallinfo info = mallinfo();
    return (uint32_t)info.fordblks;
}

uint32_t board_heap_used(void) {
    struct mallinfo info = mallinfo();
    return (uint32_t)info.uordblks;
}

uint32_t board_ram_total_kb(void) {
    return 520;
}

bool board_set_cpu_mhz(uint32_t mhz) {
    if (mhz == 150) {
        return set_sys_clock_khz(150000, true);
    }
    if (mhz == 250 || mhz == 252) {
        return set_sys_clock_khz(252000, true);
    }
    return false;
}

const char *board_name(void) {
    return "Waveshare RP2350-PiZero";
}

const char *board_version(void) {
    return BOARD_VERSION;
}

void board_schedule_reset(uint32_t delay_ms, bool bootsel) {
    reset_at_us = time_us_64() + (uint64_t)delay_ms * 1000ULL;
    reset_bootsel = bootsel;
}

void board_poll_reset(void) {
    if (reset_at_us == 0) {
        return;
    }
    if (time_us_64() < reset_at_us) {
        return;
    }

    if (reset_bootsel) {
        reset_usb_boot(0, 0);
    } else {
        watchdog_reboot(0, 0, 0);
    }
    while (true) {
        tight_loop_contents();
    }
}
