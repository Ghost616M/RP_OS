#ifndef RP_OS_BOARD_H
#define RP_OS_BOARD_H

#include <stdbool.h>
#include <stdint.h>

#define BOARD_VERSION "1.0"

void board_init(void);
float board_temp_c(void);
uint32_t board_uptime_s(void);
uint64_t board_uptime_ms(void);
uint32_t board_heap_free(void);
uint32_t board_heap_used(void);
uint32_t board_ram_total_kb(void);
uint32_t board_cpu_mhz(void);
bool board_set_cpu_mhz(uint32_t mhz);

const char *board_name(void);
const char *board_version(void);

void board_schedule_reset(uint32_t delay_ms, bool bootsel);
void board_poll_reset(void);

#endif
