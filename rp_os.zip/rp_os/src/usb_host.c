#include "usb_host.h"

#include <stdio.h>
#include <string.h>

#include "class/hid/hid.h"
#include "class/msc/msc_host.h"
#include "input.h"
#include "net_stack.h"
#include "pico/stdlib.h"
#include "pio_usb.h"
#include "storage.h"
#include "tusb.h"
#include "host/usbh_pvt.h"
#include "usb_net.h"
#include "ath9k_wifi.h"

#define DEV_ADDR_MAX (CFG_TUH_DEVICE_MAX + CFG_TUH_HUB + 1)
#define HID_ITF_MAX CFG_TUH_HID

typedef enum {
    HID_KIND_NONE = 0,
    HID_KIND_KEYBOARD,
    HID_KIND_MOUSE,
} HidKind;

static HidKind hid_kinds[DEV_ADDR_MAX][HID_ITF_MAX];
static hid_keyboard_report_t kbd_last[DEV_ADDR_MAX][HID_ITF_MAX];
static uint8_t hid_protocol[DEV_ADDR_MAX][HID_ITF_MAX];

static uint8_t keyboard_count;
static uint8_t mouse_count;

static UsbDeviceInfo device_table[CFG_TUH_DEVICE_MAX];
static uint8_t device_count;

static uint8_t msc_dev_addr;
static bool msc_probed;

static volatile bool msc_done;
static volatile uint8_t msc_status;

static const uint8_t keycode2ascii[128][2] = {HID_KEYCODE_TO_ASCII};

static bool msc_probe_cb(uint8_t dev_addr, tuh_msc_complete_data_t const *cb_data) {
    (void)dev_addr;
    msc_status = (cb_data != NULL && cb_data->csw != NULL) ? cb_data->csw->status : 1;
    msc_done = true;
    return true;
}

static UsbDeviceInfo *device_find(uint8_t addr) {
    for (uint8_t i = 0; i < device_count; ++i) {
        if (device_table[i].addr == addr) {
            return &device_table[i];
        }
    }
    return NULL;
}

static UsbDeviceInfo *device_add(uint8_t addr, uint16_t vid, uint16_t pid) {
    UsbDeviceInfo *existing = device_find(addr);
    if (existing != NULL) {
        return existing;
    }
    if (device_count >= CFG_TUH_DEVICE_MAX) {
        return NULL;
    }
    UsbDeviceInfo *info = &device_table[device_count++];
    memset(info, 0, sizeof(*info));
    info->addr = addr;
    info->vid = vid;
    info->pid = pid;
    return info;
}

static void device_remove(uint8_t addr) {
    for (uint8_t i = 0; i < device_count; ++i) {
        if (device_table[i].addr == addr) {
            for (uint8_t j = i; j + 1 < device_count; ++j) {
                device_table[j] = device_table[j + 1];
            }
            device_count--;
            return;
        }
    }
}

static void utf16_to_ascii(const uint16_t *src, uint8_t chars, char *out, size_t out_size) {
    size_t written = 0;
    for (uint8_t i = 0; i < chars && written + 1 < out_size; ++i) {
        uint16_t c = src[i];
        if (c >= 0x20 && c < 0x7F) {
            out[written++] = (char)c;
        } else if (c != 0) {
            out[written++] = '?';
        }
    }
    out[written] = '\0';
}

static void read_product_name(uint8_t addr, char *out, size_t out_size) {
    out[0] = '\0';
    uint16_t buf[32];
    uint8_t result = tuh_descriptor_get_product_string_sync(addr, 0x0409, buf, sizeof(buf));
    if (result != XFER_RESULT_SUCCESS) {
        return;
    }
    uint8_t len = (uint8_t)(buf[0] & 0xFF);
    if (len < 4) {
        return;
    }
    uint8_t chars = (uint8_t)((len - 2) / 2);
    if (chars > 31) {
        chars = 31;
    }
    utf16_to_ascii(&buf[1], chars, out, out_size);
}

const char *usb_chip_hint(uint16_t vid, uint16_t pid) {
    switch (vid) {
        case 0x0B95:
            switch (pid) {
                case 0x7720: return "ASIX AX88772";
                case 0x772B: return "ASIX AX88772B";
                case 0x1790: return "ASIX AX88179";
                case 0x178A: return "ASIX AX88178A";
                default: return "ASIX Ethernet";
            }
        case 0x0BDA:
            switch (pid) {
                case 0x8152: return "Realtek RTL8152";
                case 0x8153: return "Realtek RTL8153";
                case 0x8155: return "Realtek RTL8155";
                case 0x8156: return "Realtek RTL8156";
                case 0x5411: return "Realtek Hub";
                default: return "Realtek";
            }
        case 0x0424:
            if (pid == 0xEC00) return "SMSC LAN9514";
            if (pid == 0x7800) return "SMSC Hub";
            return "SMSC/Microchip";
        case 0x0CF3:
            switch (pid) {
                case 0x9271: return "Atheros AR9271";
                case 0x7015: return "Atheros AR7010";
                case 0x9374: return "Atheros AR9374";
                default: return "Atheros Wi-Fi";
            }
        case 0x04E8:
            return "Samsung";
        case 0x05E3:
            return "Genesys Logic Hub";
        case 0x2109:
            return "VIA Labs Hub";
        case 0x1A40:
            return "Terminus Hub";
        case 0x1D6B:
            return "Linux Foundation";
        default:
            return NULL;
    }
}

const char *usb_device_kind_name(uint8_t kind) {
    if (kind & USB_KIND_WIFI) return "wifi Atheros";
    if (kind & USB_KIND_NET) return "ethernet";
    if (kind & USB_KIND_MSC) return "pendrive";
    if (kind & USB_KIND_KEYBOARD) return "teclado";
    if (kind & USB_KIND_MOUSE) return "mouse";
    if (kind & USB_KIND_HUB) return "hub";
    return "dispositivo";
}

static uint8_t classify_descriptors(uint8_t addr) {
    static uint8_t config[512];
    uint8_t result = tuh_descriptor_get_configuration_sync(addr, 0, config, sizeof(config));
    if (result != XFER_RESULT_SUCCESS) {
        return USB_KIND_OTHER;
    }

    uint16_t total = (uint16_t)(config[2] | (config[3] << 8));
    if (total < 9 || total > sizeof(config)) {
        total = sizeof(config);
    }

    uint8_t kind = 0;
    uint16_t pos = 0;
    while (pos + 2 <= total) {
        uint8_t blen = config[pos];
        uint8_t btype = config[pos + 1];
        if (blen < 2 || pos + blen > total) {
            break;
        }
        if (btype == TUSB_DESC_INTERFACE && blen >= (uint8_t)sizeof(tusb_desc_interface_t)) {
            const tusb_desc_interface_t *itf = (const tusb_desc_interface_t *)(config + pos);
            switch (itf->bInterfaceClass) {
                case TUSB_CLASS_HID:
                    if (itf->bInterfaceProtocol == HID_ITF_PROTOCOL_KEYBOARD) {
                        kind |= USB_KIND_KEYBOARD;
                    } else if (itf->bInterfaceProtocol == HID_ITF_PROTOCOL_MOUSE) {
                        kind |= USB_KIND_MOUSE;
                    } else {
                        kind |= USB_KIND_OTHER;
                    }
                    break;
                case TUSB_CLASS_MSC:
                    kind |= USB_KIND_MSC;
                    break;
                case TUSB_CLASS_CDC: {
                    uint8_t sub = itf->bInterfaceSubClass;
                    if (sub == 0x06 || sub == 0x0D) {
                        kind |= USB_KIND_NET;
                    } else {
                        kind |= USB_KIND_OTHER;
                    }
                    break;
                }
                case TUSB_CLASS_WIRELESS_CONTROLLER:
                    kind |= USB_KIND_NET;
                    break;
                case TUSB_CLASS_HUB:
                    kind |= USB_KIND_HUB;
                    break;
                case TUSB_CLASS_VENDOR_SPECIFIC:
                    kind |= USB_KIND_OTHER;
                    break;
                default:
                    kind |= USB_KIND_OTHER;
                    break;
            }
        }
        pos = (uint16_t)(pos + blen);
    }
    return kind == 0 ? USB_KIND_OTHER : kind;
}

void tuh_mount_cb(uint8_t dev_addr) {
    uint16_t vid = 0;
    uint16_t pid = 0;
    if (tuh_vid_pid_get(dev_addr, &vid, &pid)) {
        UsbDeviceInfo *info = device_add(dev_addr, vid, pid);
        if (info != NULL) {
            uint8_t kind = classify_descriptors(dev_addr);
            if (vid == 0x0CF3) {
                kind |= USB_KIND_WIFI;
            }
            info->kind = kind;
            read_product_name(dev_addr, info->name, sizeof(info->name));
            if (info->name[0] == '\0') {
                const char *hint = usb_chip_hint(vid, pid);
                snprintf(info->name, sizeof(info->name), "%s", hint != NULL ? hint : "USB");
            }
        }
        if (vid == 0x0CF3) {
            net_wifi_usb_mounted(dev_addr, vid, pid);
        }
    }
}

void tuh_umount_cb(uint8_t dev_addr) {
    net_wifi_usb_unmounted(dev_addr);
    device_remove(dev_addr);
}

uint8_t usb_keyboard_count(void) {
    return keyboard_count;
}

uint8_t usb_mouse_count(void) {
    return mouse_count;
}

int usb_devices(UsbDeviceInfo *out, int max_devices) {
    if (out == NULL || max_devices <= 0) {
        return 0;
    }
    int count = device_count < max_devices ? device_count : max_devices;
    for (int i = 0; i < count; ++i) {
        out[i] = device_table[i];
    }
    return count;
}

bool usb_cdc_connected(void) {
    return tud_cdc_connected();
}

void usb_cdc_write(const char *text) {
    if (text == NULL || !tud_cdc_connected()) {
        return;
    }
    size_t len = strlen(text);
    size_t sent = 0;
    uint32_t idle = 0;
    while (sent < len && tud_cdc_connected()) {
        uint32_t available = tud_cdc_write_available();
        if (available == 0) {
            tud_cdc_write_flush();
            tud_task();
            if (++idle > 4096U) {
                break;
            }
            continue;
        }
        idle = 0;
        size_t chunk = len - sent;
        if (chunk > available) {
            chunk = available;
        }
        uint32_t written = tud_cdc_write(text + sent, (uint32_t)chunk);
        if (written == 0) {
            break;
        }
        sent += written;
        tud_cdc_write_flush();
    }
    tud_cdc_write_flush();
}

void tud_cdc_rx_cb(uint8_t itf) {
    (void)itf;
    uint8_t buffer[64];
    while (tud_cdc_read(buffer, sizeof(buffer)) > 0) {
    }
}

static uint16_t key_to_input(uint8_t keycode, uint8_t modifier) {
    bool shift = (modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT)) != 0;
    bool ctrl = (modifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL)) != 0;

    switch (keycode) {
        case HID_KEY_ENTER:
        case HID_KEY_KEYPAD_ENTER:
            return '\r';
        case HID_KEY_BACKSPACE:
            return INPUT_KEY_BACKSPACE;
        case HID_KEY_TAB:
            return '\t';
        case HID_KEY_ESCAPE:
            return INPUT_KEY_ESC;
        case HID_KEY_DELETE:
            return INPUT_KEY_DELETE;
        case HID_KEY_ARROW_UP:
            return INPUT_KEY_UP;
        case HID_KEY_ARROW_DOWN:
            return INPUT_KEY_DOWN;
        case HID_KEY_ARROW_LEFT:
            return INPUT_KEY_LEFT;
        case HID_KEY_ARROW_RIGHT:
            return INPUT_KEY_RIGHT;
        case HID_KEY_HOME:
            return INPUT_KEY_HOME;
        case HID_KEY_END:
            return INPUT_KEY_END;
        case HID_KEY_PAGE_UP:
            return INPUT_KEY_PAGEUP;
        case HID_KEY_PAGE_DOWN:
            return INPUT_KEY_PAGEDOWN;
        case HID_KEY_F1:
            return INPUT_KEY_F1;
        case HID_KEY_F2:
            return INPUT_KEY_F2;
        case HID_KEY_F5:
            return INPUT_KEY_F5;
        case HID_KEY_F10:
            return INPUT_KEY_F10;
        case HID_KEY_F12:
            return INPUT_KEY_F12;
        default:
            break;
    }

    if (keycode < 128) {
        uint8_t base = keycode2ascii[keycode][0];
        if (ctrl && base >= 'a' && base <= 'z') {
            return (uint16_t)(base - 'a' + 1);
        }
        return keycode2ascii[keycode][shift ? 1 : 0];
    }
    return 0;
}

static void process_keyboard(uint8_t dev_addr, uint8_t instance, const hid_keyboard_report_t *report) {
    if (dev_addr >= DEV_ADDR_MAX || instance >= HID_ITF_MAX) {
        return;
    }
    hid_keyboard_report_t *previous = &kbd_last[dev_addr][instance];
    uint8_t mods = report->modifier;
    if (mods & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL)) {
        mods = INPUT_MOD_CTRL;
    } else {
        mods = 0;
    }
    if (report->modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT)) {
        mods |= INPUT_MOD_SHIFT;
    }
    if (report->modifier & (KEYBOARD_MODIFIER_LEFTALT | KEYBOARD_MODIFIER_RIGHTALT)) {
        mods |= INPUT_MOD_ALT;
    }

    for (uint8_t i = 0; i < 6; ++i) {
        uint8_t keycode = report->keycode[i];
        if (keycode == 0) {
            continue;
        }
        bool was_down = false;
        for (uint8_t j = 0; j < 6; ++j) {
            if (previous->keycode[j] == keycode) {
                was_down = true;
                break;
            }
        }
        if (!was_down) {
            uint16_t out = key_to_input(keycode, report->modifier);
            if (out != 0) {
                input_key(out, mods, true);
            }
        }
    }

    for (uint8_t i = 0; i < 6; ++i) {
        uint8_t keycode = previous->keycode[i];
        if (keycode == 0) {
            continue;
        }
        bool still_down = false;
        for (uint8_t j = 0; j < 6; ++j) {
            if (report->keycode[j] == keycode) {
                still_down = true;
                break;
            }
        }
        if (!still_down) {
            uint16_t out = key_to_input(keycode, previous->modifier);
            if (out != 0) {
                input_key(out, mods, false);
            }
        }
    }

    *previous = *report;
}

static void process_mouse(const uint8_t *report, uint16_t len) {
    if (len < 3) {
        return;
    }
    uint8_t buttons = report[0] & 0x07;
    int8_t dx = (int8_t)report[1];
    int8_t dy = (int8_t)report[2];
    int8_t wheel = (len >= 4) ? (int8_t)report[3] : 0;

    input_mouse_move(dx, dy);
    input_mouse_buttons(buttons);
    if (wheel != 0) {
        input_mouse_wheel(wheel);
    }
}

void tuh_hid_mount_cb(uint8_t dev_addr, uint8_t instance, uint8_t const *desc_report, uint16_t desc_len) {
    (void)desc_report;
    (void)desc_len;
    if (dev_addr >= DEV_ADDR_MAX || instance >= HID_ITF_MAX) {
        return;
    }

    uint8_t protocol = (uint8_t)tuh_hid_interface_protocol(dev_addr, instance);
    hid_protocol[dev_addr][instance] = protocol;
    memset(&kbd_last[dev_addr][instance], 0, sizeof(hid_keyboard_report_t));

    if (protocol == HID_ITF_PROTOCOL_NONE && desc_report != NULL) {
        for (uint16_t i = 0; i + 2 < desc_len; ++i) {
            if (desc_report[i] == 0x05 && desc_report[i + 1] == 0x01) {
                for (uint16_t j = i + 2; j + 1 < desc_len && j < i + 12; ++j) {
                    if (desc_report[j] == 0x09 && desc_report[j + 1] == 0x02) {
                        protocol = HID_ITF_PROTOCOL_MOUSE;
                        break;
                    }
                    if (desc_report[j] == 0x09 && desc_report[j + 1] == 0x06) {
                        protocol = HID_ITF_PROTOCOL_KEYBOARD;
                        break;
                    }
                }
            }
            if (protocol != HID_ITF_PROTOCOL_NONE) {
                break;
            }
        }
        if (protocol != HID_ITF_PROTOCOL_NONE) {
            tuh_hid_set_protocol(dev_addr, instance, HID_PROTOCOL_BOOT);
        }
    }

    if (protocol == HID_ITF_PROTOCOL_KEYBOARD) {
        hid_kinds[dev_addr][instance] = HID_KIND_KEYBOARD;
        if (keyboard_count < 255) {
            keyboard_count++;
        }
        UsbDeviceInfo *info = device_find(dev_addr);
        if (info != NULL) {
            info->kind |= USB_KIND_KEYBOARD;
        }
        usb_cdc_write("[USB] teclado montado\r\n");
    } else if (protocol == HID_ITF_PROTOCOL_MOUSE) {
        hid_kinds[dev_addr][instance] = HID_KIND_MOUSE;
        if (mouse_count < 255) {
            mouse_count++;
        }
        tuh_hid_set_protocol(dev_addr, instance, HID_PROTOCOL_BOOT);
        UsbDeviceInfo *info = device_find(dev_addr);
        if (info != NULL) {
            info->kind |= USB_KIND_MOUSE;
        }
        usb_cdc_write("[USB] mouse montado\r\n");
    } else {
        hid_kinds[dev_addr][instance] = HID_KIND_NONE;
    }

    tuh_hid_receive_report(dev_addr, instance);
}

void tuh_hid_umount_cb(uint8_t dev_addr, uint8_t instance) {
    if (dev_addr >= DEV_ADDR_MAX || instance >= HID_ITF_MAX) {
        return;
    }
    HidKind kind = hid_kinds[dev_addr][instance];
    if (kind == HID_KIND_KEYBOARD && keyboard_count > 0) {
        keyboard_count--;
    } else if (kind == HID_KIND_MOUSE && mouse_count > 0) {
        mouse_count--;
    }
    hid_kinds[dev_addr][instance] = HID_KIND_NONE;
    hid_protocol[dev_addr][instance] = HID_ITF_PROTOCOL_NONE;
    memset(&kbd_last[dev_addr][instance], 0, sizeof(hid_keyboard_report_t));
}

void tuh_hid_report_received_cb(uint8_t dev_addr, uint8_t instance,
                                uint8_t const *report, uint16_t len) {
    if (dev_addr < DEV_ADDR_MAX && instance < HID_ITF_MAX) {
        HidKind kind = hid_kinds[dev_addr][instance];
        if (kind == HID_KIND_KEYBOARD && len >= sizeof(hid_keyboard_report_t)) {
            process_keyboard(dev_addr, instance, (const hid_keyboard_report_t *)report);
        } else if (kind == HID_KIND_MOUSE) {
            process_mouse(report, len);
        }
    }
    tuh_hid_receive_report(dev_addr, instance);
}

void tuh_msc_mount_cb(uint8_t dev_addr) {
    msc_dev_addr = dev_addr;
    msc_probed = true;
    storage_usb_mounted(dev_addr);
    usb_cdc_write("[USB] pendrive montado\r\n");
}

void tuh_msc_umount_cb(uint8_t dev_addr) {
    if (msc_dev_addr == dev_addr) {
        msc_dev_addr = 0;
        msc_probed = false;
    }
    storage_usb_unmounted(dev_addr);
    usb_cdc_write("[USB] pendrive removido\r\n");
}

bool usb_msc_probe(void) {
    if (msc_dev_addr == 0 || !tuh_msc_mounted(msc_dev_addr)) {
        msc_probed = false;
        return false;
    }

    uint64_t timeout = time_us_64() + 3000000ULL;
    while (!tuh_msc_ready(msc_dev_addr) && time_us_64() < timeout) {
        tuh_task();
    }
    if (!tuh_msc_ready(msc_dev_addr)) {
        msc_probed = false;
        return false;
    }

    uint32_t block_size = tuh_msc_get_block_size(msc_dev_addr, 0);
    uint32_t block_count = tuh_msc_get_block_count(msc_dev_addr, 0);
    if (block_size != 512 || block_count == 0) {
        msc_probed = false;
        return false;
    }

    msc_probed = true;
    return true;
}

bool usb_msc_ready(void) {
    if (msc_dev_addr == 0 || !tuh_msc_mounted(msc_dev_addr)) {
        msc_probed = false;
        return false;
    }
    return msc_probed && tuh_msc_get_block_size(msc_dev_addr, 0) == 512;
}

uint32_t usb_msc_block_count(void) {
    return usb_msc_ready() ? tuh_msc_get_block_count(msc_dev_addr, 0) : 0;
}

uint32_t usb_msc_block_size(void) {
    return usb_msc_ready() ? tuh_msc_get_block_size(msc_dev_addr, 0) : 0;
}

static bool msc_wait_transfer(void) {
    uint64_t deadline = time_us_64() + 5000000ULL;
    while (!msc_done) {
        tuh_task();
        if (!tuh_msc_mounted(msc_dev_addr)) {
            return false;
        }
        if (time_us_64() > deadline) {
            return false;
        }
    }
    return msc_status == 0;
}

static bool msc_read(uint32_t lba, uint8_t *buffer, uint32_t count) {
    uint64_t start_deadline = time_us_64() + 5000000ULL;
    while (count > 0) {
        uint16_t chunk = count > 64 ? 64 : (uint16_t)count;
        msc_done = false;
        msc_status = 1;
        if (!tuh_msc_read10(msc_dev_addr, 0, buffer, lba, chunk, msc_probe_cb, 0)) {
            if (time_us_64() > start_deadline || !tuh_msc_mounted(msc_dev_addr)) {
                return false;
            }
            tuh_task();
            sleep_ms(1);
            continue;
        }
        if (!msc_wait_transfer()) {
            return false;
        }
        buffer += (size_t)chunk * 512U;
        lba += chunk;
        count -= chunk;
    }
    return true;
}

static bool msc_write(uint32_t lba, const uint8_t *buffer, uint32_t count) {
    uint64_t start_deadline = time_us_64() + 5000000ULL;
    while (count > 0) {
        uint16_t chunk = count > 64 ? 64 : (uint16_t)count;
        msc_done = false;
        msc_status = 1;
        if (!tuh_msc_write10(msc_dev_addr, 0, buffer, lba, chunk, msc_probe_cb, 0)) {
            if (time_us_64() > start_deadline || !tuh_msc_mounted(msc_dev_addr)) {
                return false;
            }
            tuh_task();
            sleep_ms(1);
            continue;
        }
        if (!msc_wait_transfer()) {
            return false;
        }
        buffer += (size_t)chunk * 512U;
        lba += chunk;
        count -= chunk;
    }
    return true;
}

bool usb_msc_read(uint32_t lba, uint8_t *buffer, uint32_t count) {
    if (!usb_msc_ready() || buffer == NULL) {
        return false;
    }
    return msc_read(lba, buffer, count);
}

bool usb_msc_write(uint32_t lba, const uint8_t *buffer, uint32_t count) {
    if (!usb_msc_ready() || buffer == NULL) {
        return false;
    }
    return msc_write(lba, buffer, count);
}

static volatile bool wifi_bulk_done;
static volatile xfer_result_t wifi_bulk_result;

static void wifi_bulk_cb(tuh_xfer_t *xfer) {
    wifi_bulk_result = xfer->result;
    wifi_bulk_done = true;
}

static bool find_bulk_out(uint8_t addr, tusb_desc_endpoint_t *out_ep) {
    static uint8_t config[512];
    uint8_t result = tuh_descriptor_get_configuration_sync(addr, 0, config, sizeof(config));
    if (result != XFER_RESULT_SUCCESS) {
        return false;
    }
    uint16_t total = (uint16_t)(config[2] | (config[3] << 8));
    if (total < 9 || total > sizeof(config)) {
        total = sizeof(config);
    }
    uint16_t pos = 0;
    while (pos + 2 <= total) {
        uint8_t blen = config[pos];
        uint8_t btype = config[pos + 1];
        if (blen < 2 || pos + blen > total) {
            break;
        }
        if (btype == TUSB_DESC_ENDPOINT && blen >= sizeof(tusb_desc_endpoint_t)) {
            const tusb_desc_endpoint_t *ep = (const tusb_desc_endpoint_t *)(config + pos);
            if (ep->bmAttributes.xfer == TUSB_XFER_BULK &&
                (ep->bEndpointAddress & TUSB_DIR_IN_MASK) == 0) {
                *out_ep = *ep;
                return true;
            }
        }
        pos = (uint16_t)(pos + blen);
    }
    return false;
}

bool usb_wifi_fw_test(const uint8_t *data, size_t len, char *out, size_t out_size) {
    if (out == NULL || out_size == 0) {
        return false;
    }
    out[0] = '\0';

    uint8_t addr = 0;
    uint16_t vid = 0;
    uint16_t pid = 0;
    for (uint8_t i = 0; i < device_count; ++i) {
        if ((device_table[i].kind & USB_KIND_WIFI) != 0) {
            addr = device_table[i].addr;
            vid = device_table[i].vid;
            pid = device_table[i].pid;
            break;
        }
    }
    if (addr == 0) {
        snprintf(out, out_size, "nenhum Atheros USB encontrado");
        return false;
    }
    if (data == NULL || len == 0) {
        snprintf(out, out_size, "firmware vazio");
        return false;
    }

    size_t chunk = len > 64 ? 64 : len;
    tusb_control_request_t req = {
        .bmRequestType = 0x40,
        .bRequest = 0x30,
        .wValue = 0,
        .wIndex = 0,
        .wLength = (uint16_t)chunk,
    };
    tuh_xfer_t xfer = {
        .daddr = addr,
        .ep_addr = 0,
        .setup = &req,
        .buffer = (void *)(uintptr_t)data,
    };
    bool ok = tuh_control_xfer(&xfer) && xfer.result == XFER_RESULT_SUCCESS;

    if (ok) {
        snprintf(out, out_size,
                 "%04X:%04X controle 0x30 OK (%u bytes de %lu)",
                 vid, pid, (unsigned)chunk, (unsigned long)len);
        return true;
    }

    tusb_desc_endpoint_t ep;
    if (find_bulk_out(addr, &ep) && tuh_edpt_open(addr, &ep)) {
        tuh_xfer_t bulk = {
            .daddr = addr,
            .ep_addr = ep.bEndpointAddress,
            .buffer = (void *)(uintptr_t)data,
            .buflen = (uint32_t)chunk,
            .complete_cb = wifi_bulk_cb,
        };
        wifi_bulk_done = false;
        wifi_bulk_result = XFER_RESULT_INVALID;
        if (tuh_edpt_xfer(&bulk)) {
            uint64_t deadline = time_us_64() + 1000000ULL;
            while (!wifi_bulk_done && time_us_64() < deadline) {
                tuh_task();
            }
        }
        if (wifi_bulk_done && wifi_bulk_result == XFER_RESULT_SUCCESS) {
            snprintf(out, out_size,
                     "%04X:%04X bulk %02X OK (%u bytes de %lu)",
                     vid, pid, ep.bEndpointAddress, (unsigned)chunk, (unsigned long)len);
            return true;
        }
    }

    snprintf(out, out_size, "%04X:%04X sem resposta do endpoint", vid, pid);
    return false;
}

void usb_init(void) {
    tud_init(0);

    pio_usb_configuration_t config = {
        .pin_dp = 28,
        .pio_tx_num = 1,
        .sm_tx = 0,
        .tx_ch = 6,
        .pio_rx_num = 1,
        .sm_rx = 1,
        .sm_eop = 2,
        .alarm_pool = NULL,
        .debug_pin_rx = -1,
        .debug_pin_eop = -1,
        .skip_alarm_pool = false,
        .pinout = PIO_USB_PINOUT_DPDM,
    };
    tuh_configure(1, TUH_CFGID_RPI_PIO_USB_CONFIGURATION, &config);
    tuh_init(1);

    keyboard_count = 0;
    mouse_count = 0;
    device_count = 0;
    msc_dev_addr = 0;
    msc_probed = false;
    memset(hid_kinds, 0, sizeof(hid_kinds));
    memset(hid_protocol, 0, sizeof(hid_protocol));
    memset(kbd_last, 0, sizeof(kbd_last));
}

void usb_task(void) {
    tud_task();
    tuh_task();
    tud_cdc_write_flush();
}

usbh_class_driver_t const *usbh_app_driver_get_cb(uint8_t *driver_count) {
    static usbh_class_driver_t app_drivers[2];
    static bool inited = false;
    if (!inited) {
        usbh_class_driver_t const *net_drv = usb_net_get_driver();
        usbh_class_driver_t const *wifi_drv = ath9k_wifi_get_driver();
        if (net_drv != NULL) {
            memcpy(&app_drivers[0], net_drv, sizeof(usbh_class_driver_t));
        }
        if (wifi_drv != NULL) {
            memcpy(&app_drivers[1], wifi_drv, sizeof(usbh_class_driver_t));
        }
        inited = true;
    }
    *driver_count = 2;
    return app_drivers;
}
