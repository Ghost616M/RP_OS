#ifndef RP_OS_APP_H
#define RP_OS_APP_H

#include <stdbool.h>

#include "gui.h"

#define APP_EDITOR_MAX_BYTES 24576

typedef enum {
    APP_TERMINAL = 0,
    APP_FILES,
    APP_GPIO,
    APP_EDITOR,
    APP_SYSMON,
    APP_NETWORK,
    APP_SETTINGS,
    APP_COUNT
} AppId;

typedef struct {
    const char *name;
    AppId id;
    uint16_t icon_color;
    int width;
    int height;
    void (*create)(GuiWindow *w, const char *arg);
    void (*destroy)(GuiWindow *w);
    void (*open_arg)(GuiWindow *w, const char *arg);
    void (*draw)(GuiWindow *w, int cx, int cy, int cw, int ch);
    bool (*event)(GuiWindow *w, const GuiEvent *ev, int cx, int cy, int cw, int ch);
    void (*tick)(GuiWindow *w);
} AppOps;

extern const AppOps app_terminal_ops;
extern const AppOps app_files_ops;
extern const AppOps app_gpio_ops;
extern const AppOps app_editor_ops;
extern const AppOps app_sysmon_ops;
extern const AppOps app_network_ops;
extern const AppOps app_settings_ops;

const AppOps *app_ops(AppId id);
GuiWindow *app_open(AppId id, const char *arg);

GuiWindow *gui_wm_create(AppId id, const char *arg);
GuiWindow *gui_wm_find(AppId id);
void gui_wm_focus(GuiWindow *w);
void gui_wm_raise(GuiWindow *w);
void gui_wm_close(GuiWindow *w);
void gui_wm_minimize(GuiWindow *w);
void gui_wm_restore(GuiWindow *w);
void gui_wm_begin_drag(GuiWindow *w, int mouse_x, int mouse_y);
void gui_wm_drag_to(GuiWindow *w, int mouse_x, int mouse_y);
void gui_wm_begin_resize(GuiWindow *w, int mouse_x, int mouse_y);
void gui_wm_resize_to(GuiWindow *w, int mouse_x, int mouse_y);
void gui_wm_resize(GuiWindow *w, int width, int height);
void gui_wm_move(GuiWindow *w, int x, int y);
void gui_wm_content_rect(GuiWindow *w, int *cx, int *cy, int *cw, int *ch);
GuiWindow *gui_wm_top(void);
GuiWindow *gui_wm_z_at(int index);
int gui_wm_z_count(void);
int gui_wm_open_count(void);
int gui_wm_window_count(void);
GuiWindow *gui_wm_window_at(int index);

#endif
