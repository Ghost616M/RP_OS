#ifndef RP_OS_ATH9K_WIFI_H
#define RP_OS_ATH9K_WIFI_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "tusb.h"
#include "host/usbh_pvt.h"

#define ATH9K_WIFI_SSID_MAX 32

typedef struct {
    char ssid[ATH9K_WIFI_SSID_MAX + 1];
    uint8_t bssid[6];
    int8_t rssi;
    uint8_t channel;
    bool secure;
} AthWifiNetwork;

typedef struct {
    bool present;
    bool booted;
    bool ready;
    bool mac_valid;
    uint8_t mac[6];
    uint16_t fw_major;
    uint16_t fw_minor;
    uint32_t fw_size;
    bool associated;
    bool connected;
    bool secure;
    bool wpa_done;
    uint8_t bssid[6];
    char ssid[ATH9K_WIFI_SSID_MAX + 1];
    int8_t rssi;
    uint8_t channel;
    char status[80];
} AthWifiInfo;

usbh_class_driver_t const *ath9k_wifi_get_driver(void);

void ath9k_wifi_init(void);
void ath9k_wifi_task(void);

void ath9k_wifi_mounted(uint8_t addr, uint16_t vid, uint16_t pid);
void ath9k_wifi_unmounted(uint8_t addr);

bool ath9k_wifi_present(void);
bool ath9k_wifi_boot(char *out, size_t out_size);
bool ath9k_wifi_scan(AthWifiNetwork *out, int max, int *count, char *msg, size_t msg_size);
bool ath9k_wifi_connect(const char *ssid, const char *password, char *out, size_t out_size);
bool ath9k_wifi_disconnect(char *out, size_t out_size);
bool ath9k_wifi_send(const uint8_t *frame, uint16_t len);
void ath9k_wifi_set_rx_cb(void (*cb)(const uint8_t *frame, uint16_t len));
void ath9k_wifi_info(AthWifiInfo *info);

#endif
